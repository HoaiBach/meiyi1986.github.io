
#include "MA.h"

void MAOpt(vector<individual> & pop, individual *bfSolution, int maxGen, minSpanTree *thisMST, problem *thisProb, char *outFileName, char *logFileName, char *resFileName)
{
	vector<int>::size_type popsize = pop.size();
	int offsize = 1; // steady-state MA
	//int offsize = (int)popsize;
	double lsProb = 1.0/offsize; // averagely 1 local search per generation
	int immiGen = 50; // the generations to include immigrant

	double lsDuration = 0;

	ofstream outfile;

	int gen = 0; // generations without improvement
	//for (int gen = 0; gen < maxGen; gen++)
	while (1)
	{
		//cout << gen << ": " << bfSolution->tourLength << " " << bfSolution->itemWeight << " " << bfSolution->itemProfit << " " << bfSolution->profit << endl;

		//if (gen > immiGen)
		//{
		//	// randomly generate an immigrant
		//	// Initialize the tour of indi
		//	MSTTour(&immigrant, thisMST, thisProb);

		//	//cout << "length = " << tmpIndi.tourLength << endl;
		//	//system("pause");

		//	// Initialize the picking plan of indi
		//	RandPickPlan(&immigrant, thisProb);

		//	IndiReEvaluate(&immigrant, thisProb); // evaluate the individual
		//}

		double profit1 = bfSolution->profit;

		clock_t currT = clock();
		double duration = (double)(currT-startT)/CLOCKS_PER_SEC;

		//cout << duration << " " << lsDuration << " " << MAX_RUNTIME-elapsedTime-lsDuration << endl;

		if (duration > MAX_RUNTIME-elapsedTime-lsDuration || gen > 2000)
		{
			OutputLog(bfSolution, logFileName);
			OutputRes(bfSolution, outFileName);
			break;
		}

		//outfile.open(outFileName, fstream::app);
		//outfile << "gen " << gen << endl;
		//for (vector<individual>::size_type i = 0; i != pop.size(); i++)
		//{
		//	outfile << i << " " << pop[i].tourLength << " " << pop[i].itemWeight << " " << pop[i].itemProfit << " " << pop[i].profit << endl;
		//}
		//outfile.close();

		//cout << "gen " << gen << endl;
		//for (vector<individual>::size_type i = 0; i != pop.size(); i++)
		//{
		//	cout << i << " " << pop[i].tourLength << " " << pop[i].itemWeight << " " << pop[i].itemProfit << " " << pop[i].profit << endl;
		//}
		//system("PAUSE");

		individual parent1, parent2;
		individual xchild, lschild, child;
		for (int trial = 0; trial < offsize; trial++)
		{
			child.profit = -INF;

			//// randomly pick two parents
			//int PID1, PID2; // the index of the two parents
			//PID1 = RandChoose(0, (int)popsize-1);
			//PID2 = RandChoose(0, (int)popsize-2);
			//if (PID2 >= PID1)
			//	PID2 ++;

			////cout << PID1 << " " << PID2 << endl;

			//IndiCopy(&parent1, &pop[PID1]);
			//IndiCopy(&parent2, &pop[PID2]);

			RandSelectParents(&parent1, &parent2, pop, popsize);
			//TournamentSelectParents(&parent1, &parent2, pop, popsize);

			//if (gen > immiGen)
			//{
			//	IndiCopy(&parent2, &immigrant);

			//	cout << parent1.tourLength << " " << parent2.tourLength << endl;
			//}

			// ordered crossover for tour + single point crossover for picking plan

			TourOXover(&xchild, &parent1, &parent2, thisProb);
			//TourERXOver(&xchild, &parent1, &parent2, thisProb);
			PickPlanSPXover(&xchild, &parent1, &parent2, thisProb);
			//PickPlanUniXover(&xchild, &parent1, &parent2, thisProb);
			IndiReEvaluate(&xchild, thisProb);

			/*double profit1 = xchild.profit;
			IndiEvaluate(&xchild, thisProb);
			if (xchild.profit != profit1)
			{
				cout << "xover, profit1 = " << profit1 << ", profit2 = " << xchild.profit << endl;
			}*/

			//if (gen == 3)
			//{
			// PrintIndi(&xchild);
			//system("PAUSE");
			//}

			//// test tour
			//for (int i = 0; i != parent1.tour.size(); i++)
			//{
			//	cout << parent1.tour[i] << " ";
			//}
			//cout << endl;
			//for (int i = 0; i != parent2.tour.size(); i++)
			//{
			//	cout << parent2.tour[i] << " ";
			//}
			//cout << endl;
			//for (int i = 0; i != xchild.tour.size(); i++)
			//{
			//	cout << xchild.tour[i] << " ";
			//}
			//cout << endl;
			//sort(xchild.tour.begin(), xchild.tour.end());
			//cout << "after sorting" << endl;
			//for (int i = 0; i != xchild.tour.size(); i++)
			//{
			//	cout << xchild.tour[i] << " ";
			//}
			//cout << endl;
			//system("PAUSE");

			//// test pickplan
			//for (int i = 0; i != parent1.pickPlan.size(); i++)
			//{
			//	cout << parent1.pickPlan[i] << " ";
			//}
			//cout << endl;
			//for (int i = 0; i != parent2.pickPlan.size(); i++)
			//{
			//	cout << parent2.pickPlan[i] << " ";
			//}
			//cout << endl;
			//for (int i = 0; i != xchild.pickPlan.size(); i++)
			//{
			//	cout << xchild.pickPlan[i] << " ";
			//}
			//cout << endl;
			//system("PAUSE");

			// check if it is identical
			int xidentical = 1;
			for (int i = 0; i != pop.size(); i++)
			{
				if (pop[i].tourLength == xchild.tourLength || pop[i].itemProfit == xchild.itemProfit) // either tour or picking plan is identical
				{
					xidentical = 0;
					break;
				}
			}

			if (xidentical)
			{
				IndiCopy(&child, &xchild);
			}

			// local search with probability of lsProb
			IndiCopy(&lschild, &xchild);
			double r = 1.0*rand()/RAND_MAX;
			if (r < lsProb)
			{
				//if (gen == 23)
				//{
				//	PrintIndi(&lschild);
				//}

				MALocalSearch(&lschild, bfSolution, thisProb, outFileName, logFileName, lsDuration);

				// check if it is identical
				int lsidentical = 1;
				for (int i = 0; i != pop.size(); i++)
				{
					if (pop[i].tourLength == lschild.tourLength || pop[i].itemProfit == lschild.itemProfit) // either tour or picking plan is identical
					{
						lsidentical = 0;
						break;
					}
				}

				if (lsidentical)
				{
					IndiCopy(&child, &lschild);
				}
			}

			if (child.profit != -INF) // identical child successfully generated
			{
				pop.push_back(child);
			}
		}

		//// conduct local search on the best offspring
		//lschild.profit = -INF;
		//int worstID, worstProfit = INF;
		//for (vector<individual>::size_type i = popsize; i < pop.size(); i++)
		//{
		//	if (pop[i].profit > lschild.profit)
		//	{
		//		IndiCopy(&lschild, &pop[i]);
		//		//cout << i << " " << pop[i].profit << lschild.profit << endl;
		//	}

		//	if (pop[i].profit < worstProfit)
		//	{
		//		worstID = (int)i;
		//		worstProfit = pop[i].profit;
		//	}
		//}

		//cout << worstID << "/" << pop.size() << " profit = " << worstProfit << endl;

		//if (lschild.profit != -INF) // local search for the selected individual
		//{
		//	//cout << "start ls" << endl;
		//	MALocalSearch(&lschild, thisProb);
		//	//cout << "finish ls" << endl;
		//	// check if it is identical
		//	int lsidentical = 1;
		//	for (vector<individual>::size_type i = 0; i != pop.size(); i++)
		//	{
		//		if (pop[i].tourLength == lschild.tourLength && pop[i].itemProfit == lschild.itemProfit && pop[i].profit == lschild.profit) // not identical
		//		{
		//			lsidentical = 0;
		//			break;
		//		}
		//	}

		//	if (lsidentical)
		//	{
		//		IndiCopy(&pop[worstID], &lschild); // replace the worst individual
		//	}
		//}

		// sort the population from best to worst
		sort(pop.begin(), pop.end(), indiFitnessBetter());
		// truncate selection
		pop.resize(popsize);
		//IndiCopy(bfSolution, &pop[0]);

		if (bfSolution->profit > profit1) // improved
		{
			gen = 0;
		}
		gen ++;
	}

	// output result file
	cout << "begin final" << endl;
	OutputFinal(bfSolution, resFileName);
	cout << "finish final" << endl;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Initialize the population of MA
void MAPopInit(vector<individual> & pop, minSpanTree *thisMST, problem *thisProb, char *ConcordeOutputFileName)
{
	pop.clear(); // initially no individual
	while (pop.size() < MA_POPSIZE)
	{
		int identical;
		individual tmpIndi;
		for (int trial = 0; trial < MAX_INIT_TRIALS; trial++)
		{
			clock_t t1 = clock();
			//cout << "trial = " << trial << endl;

			identical = 0;
			if (pop.size() < concordeRuns)
			{
				char currOutputFileName[500], tmpString[500];
				strcpy(currOutputFileName, ConcordeOutputFileName);
				strcat(currOutputFileName, itoa(pop.size()+1, tmpString, 10));

				// Initialize by Chained LK Heuristic
				ChainedLinKernTour(&tmpIndi, thisProb, currOutputFileName);
				// check whether the tour is identical
				identical = 1;
				for (vector<individual>::size_type j = 0; j != pop.size(); j++)
				{
					if (pop[j].tourLength == tmpIndi.tourLength)
					{
						identical = 0;
						break;
					}
				}

				//cout << tmpIndi.tourLength << endl;
				//system("pause");
			}

			if (!identical)
			{
				// Initialize the tour of indi
				//RandTour(&tmpIndi, thisProb);
				//RandDTNeighborTour(&tmpIndi, 1, thisProb);
				MSTTour(&tmpIndi, thisMST, thisProb);
				//RandChristofidesTour(&tmpIndi, thisMST, thisProb);

				//cout << "length = " << tmpIndi.tourLength << endl;
				//system("pause");
			}

			clock_t t2 = clock();

			// Initialize the picking plan of indi
			RandPickPlan(&tmpIndi, thisProb);
			//RandKBestAValuePickPlan(&tmpIndi, 1, thisProb);
			//BestAvwRatioInsertPickPlan(&tmpIndi, thisProb);

			clock_t t3 = clock();

			//cout << t2-t1 << " " << t3-t2 << endl;

			//cout << pop.size() << endl;

			IndiReEvaluate(&tmpIndi, thisProb); // evaluate the individual

			//cout << tmpIndi.tourLength << " " << tmpIndi.itemWeight << " " << tmpIndi.itemProfit << " " << tmpIndi.profit << endl;
			//IndiEvaluate(&tmpIndi, thisProb);
			//cout << tmpIndi.tourLength << " " << tmpIndi.itemWeight << " " << tmpIndi.itemProfit << " " << tmpIndi.profit << endl;
			//system("pause");

			//cout << "finish eval" << endl;

			// check if it is identical
			identical = 1;
			for (vector<individual>::size_type j = 0; j != pop.size(); j++)
			{
				if (pop[j].tourLength == tmpIndi.tourLength || pop[j].itemProfit == tmpIndi.itemProfit) // either tour or picking plan is identical
				{
					identical = 0;
					break;
				}
			}

			if (identical)
				break;
		}

		if (!identical)
			break;

		//cout << "indi " << pop.size() << ", tour" << endl;
		//PrintIndi(&tmpIndi);
		//system("PAUSE");

		//double profit1 = tmpIndi.profit;
		//IndiEvaluate(&tmpIndi, thisProb);
		//if (tmpIndi.profit != profit1)
		//{
		//	cout << "init, profit1 = " << profit1 << ", profit2 = " << tmpIndi.profit << endl;
		//}
		//system("PAUSE");

		//if (!ValidTour(&tmpIndi, thisProb))
		//{
		//	PrintIntVec(tmpIndi.tour);
		//	system("PAUSE");
		//}

		pop.push_back(tmpIndi); // add individual
	}
}

void MALocalSearch(individual *indi, individual *bfSolution, problem *thisProb, char *outFileName, char *logFileName, double & lsDuration)
{
	//cout << "start local search" << endl;
	clock_t lsStartT = clock();

	individual twoOptBestNeighbor, sfBestNeighbor, exBestNeighbor;
	tourTwoOptMove nextTwoOptMove;
	singleFlipMove nextSingleFlipMove;
	exchangeMove nextExchangeMove;
	bool imp = true;

	//PrintIntVec(indi->tour);
	//cout << "before length = " << indi->tourLength << endl;

	/***************************** optimize the tour **********************************/
	while (imp)
	{
		//// check if the fitness is correct
		//individual tmpIndi;
		//IndiCopy(&tmpIndi, indi);
		//IndiEvaluate(indi, thisProb);
		//if (indi->profit != tmpIndi.profit)
		//{
		//	cout << "first before" << endl;
		//	PrintIndi(&tmpIndi);
		//	cout << "first after" << endl;
		//	PrintIndi(indi);
		//	system("PAUSE");
		//}

		//cout << "finish checking correctness" << endl;

		imp = false;

		//GetFirstImpTwoOptNeighbor(&twoOptBestNeighbor, &nextTwoOptMove, indi, thisProb);
		//GetBestTwoOptNeighbor(&twoOptBestNeighbor, &nextTwoOptMove, indi, thisProb);
		GetBestTwoOptTSPNeighbor(&twoOptBestNeighbor, &nextTwoOptMove, indi, thisProb);
		//cout << "pos1 = " << nextTwoOptMove.headPos << ", pos2 = " << nextTwoOptMove.tailPos << ", profit = " << nextTwoOptMove.moveProfit << endl;

		if (twoOptBestNeighbor.tourLength < indi->tourLength)
		//if (twoOptBestNeighbor.profit > indi->profit)
		{
			IndiCopy(indi, &twoOptBestNeighbor);
			imp = true;
		}

		//IndiCopy(&tmpIndi, indi);
		//IndiEvaluate(indi, thisProb);
		//if (indi->profit != tmpIndi.profit)
		//{
		//	cout << "middle first before" << endl;
		//	PrintIndi(&tmpIndi);
		//	cout << "middle first after" << endl;
		//	PrintIndi(indi);
		//	system("PAUSE");
		//}

		//if (!ValidTour(indi, thisProb))
		//{
		//	PrintIntVec(tmpIndi.tour);
		//	cout << "reverse city" << nextTwoOptMove.headCity << " at " << nextTwoOptMove.headPos << " and " << nextTwoOptMove.tailCity << " at " << nextTwoOptMove.tailPos << endl;
		//	PrintIntVec(indi->tour);
		//	system("PAUSE");
		//}

		//if (indi->profit > 200000)
		//{
		//	PrintIndi(&tmpIndi);
		//	cout << "reverse city" << nextTwoOptMove.headCity << " at " << nextTwoOptMove.headPos << " and " << nextTwoOptMove.tailCity << " at " << nextTwoOptMove.tailPos << endl;
		//	PrintIndi(indi);
		//	IndiEvaluate(indi, thisProb);
		//	PrintIndi(indi);
		//	system("PAUSE");
		//}

		//if (imp == true)
		//{
		//	//cout << "2-opt improve the profit to " << indi->profit << endl;
		//	//cout << "2-opt improve the distance to " << indi->tourLength << endl;
		//	//continue;
		//}
	}

	//cout << "after length = " << indi->tourLength << endl;

	/***************************** optimize the picking plan under the tour **********************************/

	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//IndiEvaluate(indi, thisProb);
	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//system("pause");

	if (indi->profit > bfSolution->profit)
		IndiCopy(bfSolution, indi);

	// calculate the gain of each item in an empty tour, the actual gain cannot be larger than this
	vector<double> itemGainEmptyTour(thisProb->numItems+1);
	GetItemGainEmptyTour(itemGainEmptyTour, indi, thisProb);

	//// calculate the gain of each item in the best full tour, the actual gain cannot be larger than this in any full tour
	//vector<double> itemGainFullTour(thisProb->numItems+1);
	//GetItemGainFullTour(itemGainFullTour, indi, thisProb);

	//// calculate the gain of each item in the worst full tour, the actual gain cannot be smaller than this
	//vector<double> itemGainWorstTour(thisProb->numItems+1);
	//GetItemGainWorstTour(itemGainWorstTour, indi, thisProb);

	vector<itemGain> itemGainList;
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		itemGain tmpIG;
		tmpIG.item = i;
		//tmpIG.gain = tmpIG.leftTerm+0.5*tmpIG.rightTerm;
		tmpIG.gain = itemGainEmptyTour[i]/thisProb->items[i].weight;
		itemGainList.push_back(tmpIG);
	}

	sort(itemGainList.begin()+1, itemGainList.end(), itemGainLarger());

	//for (vector<itemGain>::iterator it = itemGainList.begin()+1; it != itemGainList.end(); ++it)
	//{
	//	cout << it->item << ": " << thisProb->items[it->item].profit << " " << thisProb->items[it->item].weight << " " << indi->cityBackDist[thisProb->items[it->item].inCity] <<
	//		" " << itemGainEmptyTour[it->item] << " " << itemGainWorstTour[it->item] << " " << it->gain << endl;
	//	system("pause");
	//}

	//// get the picked item list
	//vector<int> pickedItemList;
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemGainWorstTour[i] > 0)
	//	{
	//		pickedItemList.push_back(i);
	//	}
	//}

	//// get the unpicked item list
	//vector<int> unpickedItemList;
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemGainEmptyTour[i] < 0)
	//	{
	//		unpickedItemList.push_back(i);
	//	}
	//}

	//// calculate the gain of each item in the best expected tour, not necessarily full
	//vector<double> itemGainExpectedTour(thisProb->numItems+1);
	//// get the most proper expected weight and the core item set (solve the problem sumWeight = expectedWeight)
	//int ewUB = thisProb->capacity;
	//int ewLB = 0;
	//int expectedWeight = ewUB;
	//while (1)
	//{
	//	int sumWeight = 0;
	//	GetItemGainExpectedTour(itemGainExpectedTour, expectedWeight, indi, thisProb);

	//	for (int i = 1; i <= thisProb->numItems; i++)
	//	{
	//		if (itemGainExpectedTour[i] < 0)
	//			continue;

	//		sumWeight += thisProb->items[i].weight;
	//		//cout << i << ": " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << indi->cityBackDist[thisProb->items[i].inCity] << " " << itemGainExpectedTour[i] << endl;
	//	}

	//	if (sumWeight > expectedWeight)
	//	{
	//		// increase
	//		ewLB = expectedWeight;
	//		expectedWeight += (int)(0.5*(ewUB-expectedWeight));
	//	}
	//	else
	//	{
	//		// decrease
	//		ewUB = expectedWeight;
	//		expectedWeight -= (int)(0.5*(expectedWeight-ewLB));
	//	}

	//	if (ewLB >= 0.99*ewUB)
	//		break;

	//	cout << sumWeight << " " << expectedWeight << " " << ewLB << " " << ewUB << endl;
	//}


	//for (vector<double>::size_type i = 1; i < itemGainEmptyTour.size(); i++)
	//{
	//	cout << i << " gain 1 = " << itemGainEmptyTour[i] << ", gain 2 = " << itemGainFullTour[i] << ", gain 3 = " << itemGainExpectedTour[i] << endl;
	//	system("pause");
	//}

	//cout << "old profit = " << indi->profit << endl;

	//// get the core item list
	//vector<int> coreItemList;
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemGainExpectedTour[i] < 0)
	//		continue;

	//	coreItemList.push_back(i);
	//}

	//int sumProfit = 0;
	//int sumWeight = 0;
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemGainExpectedTour[i] < 0)
	//		continue;

	//	sumProfit += thisProb->items[i].profit;
	//	sumWeight += thisProb->items[i].weight;
	//	//cout << i << ": " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << indi->cityBackDist[thisProb->items[i].inCity] << " " << itemGainExpectedTour[i] << endl;
	//}
	//cout << sumProfit << " " << sumWeight << " " << coreItemList.size() << endl;

	//// the number of core items
	//int coreSize = 1000;
	//if (coreSize > thisProb->numItems-1) // cannot exceed the number of items
	//	coreSize = thisProb->numItems-1;

	//// get the core item list based on itemGainList and itemGainFullTour
	vector<int> coreItemList;
	GetCoreItemList(coreItemList, itemGainList, indi, thisProb);

	//cout << coreItemList.size() << endl;

	// generate a new picking plan
	CoreItemPickPlan(indi, coreItemList, itemGainEmptyTour, thisProb);
	//ItemGainPickPlan(indi, itemGainList, coreItemList, coreSize, thisProb); // return an iterator pointing to the break item

	IndiReEvaluate(indi, thisProb);

	//cout << breakIter->item << ": " << thisProb->items[breakIter->item].profit << " " << thisProb->items[breakIter->item].weight << " " << indi->cityBackDist[thisProb->items[breakIter->item].inCity] <<
	//	" " << itemGainEmptyTour[breakIter->item] << " " << itemGainWorstTour[breakIter->item] << " " << breakIter->gain << endl;

	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//IndiEvaluate(indi, thisProb);
	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//system("pause");

	//cout << "new profit = " << indi->profit << endl;
	//system("pause");

	imp = true;
	while (imp)
	{
		//// check if the fitness is correct
		//individual tmpIndi;
		//IndiCopy(&tmpIndi, indi);
		//IndiEvaluate(indi, thisProb);
		//if (indi->profit != tmpIndi.profit)
		//{
		//	cout << "first before" << endl;
		//	PrintIndi(&tmpIndi);
		//	cout << "first after" << endl;
		//	PrintIndi(indi);
		//	system("PAUSE");
		//}

		imp = false;

		//GetFirstImpSingleFlipNeighbor(&sfBestNeighbor, &nextSingleFlipMove, indi, thisProb);
		//GetBestSingleFlipNeighbor(&sfBestNeighbor, &nextSingleFlipMove, indi, thisProb);
		//GetBestGainSingleFlipNeighbor(&sfBestNeighbor, &nextSingleFlipMove, itemGainEmptyTour, itemGainExpectedTour, indi, thisProb);
		GetBestGainSingleFlipCoreNeighbor(&sfBestNeighbor, &nextSingleFlipMove, coreItemList, itemGainEmptyTour, indi, thisProb);

		if ((sfBestNeighbor.profit-indi->profit) > 0.01*abs(indi->profit))
		//if (sfBestNeighbor.profit > indi->profit)
		{
			IndiCopy(indi, &sfBestNeighbor);
			imp = true;
		}

		//if (sfBestNeighbor.profit > indi->profit)
		//{
		//	IndiCopy(indi, &sfBestNeighbor);
		//	imp = true;
		//}

		//IndiCopy(&tmpIndi, indi);
		//IndiEvaluate(indi, thisProb);
		//if (indi->profit != tmpIndi.profit)
		//{
		//	cout << "last before" << endl;
		//	PrintIndi(&tmpIndi);
		//	cout << "last after" << endl;
		//	PrintIndi(indi);
		//	system("PAUSE");
		//}

		//cout << "finish flip" << endl;

		//int tmpWeight = indi->itemWeight;
		//IndiEvaluate(indi, thisProb);
		//if (indi->tourLength == 4750)
		//{
		//	PrintIndi(indi);
		//	cout << "flip " << nextSingleFlipMove.item << " from status " << nextSingleFlipMove.fromStatus << " to " << nextSingleFlipMove.toStatus << endl;
		//	cout << "weight1 = " << tmpWeight << ", weight2 = " << indi->itemWeight << endl;
		//	system("PAUSE");
		//}

		//if (imp == true)
		//{
		//	cout << "single flip improve the profit to " << indi->profit << endl;
		//	continue;
		//}

		//GetFirstImpExchangeNeighbor(&exBestNeighbor, &nextExchangeMove, indi, thisProb);
		////GetBestExchangeNeighbor(&exBestNeighbor, &nextExchangeMove, indi, thisProb);
		//if (exBestNeighbor.profit > indi->profit)
		//{
		//	IndiCopy(indi, &exBestNeighbor);
		//	imp = 1;
		//}

		//if (imp == true)
		//{
		//	cout << "exchange improve the profit to " << indi->profit << endl;
		//	continue;
		//}
	}

	//int sumProfit = 0;
	//int sumWeight = 0;
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemGainExpectedTour[i] < 0)
	//		continue;

	//	sumProfit += thisProb->items[i].profit;
	//	sumWeight += thisProb->items[i].weight;
	//	cout << i << ": " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << indi->cityBackDist[thisProb->items[i].inCity] << " " << itemGainExpectedTour[i] << endl;
	//}

	//cout << "after single flip" << endl;
	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//IndiEvaluate(indi, thisProb);
	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//system("pause");

	if (indi->profit > bfSolution->profit)
		IndiCopy(bfSolution, indi);

	//cout << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << endl;
	//cout << bfSolution->tourLength << " " << bfSolution->itemWeight << " " << bfSolution->itemProfit << " " << bfSolution->profit << endl;

	//OutputLog(bfSolution, logFileName);

	clock_t currT = clock();
	double duration = (double)(currT-startT)/CLOCKS_PER_SEC;
	lsDuration = (double)(currT-lsStartT)/CLOCKS_PER_SEC;

	//cout << duration << " " << lsDuration << " " << MAX_RUNTIME-elapsedTime-lsDuration << endl;

	if (duration > MAX_RUNTIME-elapsedTime-lsDuration)
	{
		OutputLog(bfSolution, logFileName);
		OutputRes(bfSolution, outFileName);
	}

	//cout << "finish local search" << endl;
}
