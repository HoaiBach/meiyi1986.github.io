
#ifndef MA_H
#define MA_H

using namespace std;
#include <iostream>
#include <cstring>
#include <algorithm> // for sort
#include <vector>
#include <cstdlib>

#include "parameters.h"
#include "problem.h"
#include "city.h"
#include "item.h"
#include "individual.h"
#include "sampling.h"
#include "operators.h"
#include "MST.h"

extern clock_t startT;
extern int elapsedTime;
extern int concordeRuns;

// Initialize the population of MA
void MAPopInit(vector<individual> & pop, minSpanTree *thisMST, problem *thisProb, char *ConcordeOutputFileName);

// The MA optimization framework
void MAOpt(vector<individual> & pop, individual *bfSolution, int maxGen, minSpanTree *thisMST, problem *thisProb, char *outFileName, char *logFileName, char *resFileName);

// Local search of MA
void MALocalSearch(individual *indi, individual *bfSolution, problem *thisProb, char *outFileName, char *logFileName, double & lsDuration);

#endif