
#include "MST.h"

void GetMinSpanTree(minSpanTree *thisMST, delaunayTriangulation *thisDT, problem *thisProb)
{
	//clock_t t1 = clock();

	thisDT->dtEdgeList.sort(edgeShorter()); // short the edges from shortest to longest

	//clock_t t2 = clock();

	vector<int> pred(thisProb->numCities+1, -1); // the predecessor of each city, initially -1, indicating no predecessor

	list<dtEdge>::iterator it = thisDT->dtEdgeList.begin();
	for(int i = 0; i < thisProb->numCities ; i++)
	{
		while (!CheckCycle(it->v1.index, it->v2.index, pred))
		{
			++ it; // skip the edges that form cycles

			if (it == thisDT->dtEdgeList.end())
				break;
		}

		if (it == thisDT->dtEdgeList.end())
			break;

		// add this edge into the tree
		thisMST->edgeList.push_back(*it);
		++ it;

		//cout << it->v1.index << ", " << it->v2.index << " = " << it->length << endl;	
		//system("pause");
	}

	// fix for duplicate nodes
	for (vector<city>::iterator it = thisProb->cities.begin()+1; it != thisProb->cities.end(); ++it)
	{
		if (it->inDT == true)
			continue;

		//cout << it->index << endl;

		// find the duplication
		for (vector<city>::iterator jt = thisProb->cities.begin()+1; jt != thisProb->cities.end(); ++jt)
		{
			if ((jt->xcord == it->xcord) && (jt->ycord == it->ycord) && (jt->inDT == true))
			{
				dtEdge newEdge;
				newEdge.v1 = *jt;
				newEdge.v2 = *it;
				newEdge.length = 0;
				thisMST->edgeList.push_back(newEdge);
				break;
			}
		}

		it->inDT = true;
	}

	//clock_t t3 = clock();

	// transform from edge list to adjacency list
	thisMST->adjList.resize(thisProb->numCities+1);
	for (vector<city>::size_type i = 1; i != thisMST->adjList.size(); i++)
	{
		thisMST->adjList[i].index = (int)i;
	}
	for (list<dtEdge>::iterator it = thisMST->edgeList.begin(); it != thisMST->edgeList.end(); ++it)
	{
		dtNeighbor tmpNeighbor;
		tmpNeighbor.index = it->v2.index;
		tmpNeighbor.dist = it->length;
		thisMST->adjList[it->v1.index].dtNeighborList.push_back(tmpNeighbor);
		tmpNeighbor.index = it->v1.index;
		thisMST->adjList[it->v2.index].dtNeighborList.push_back(tmpNeighbor);
	}

	//for (vector<city>::size_type i = 1; i != thisMST->adjList.size(); i++)
	//{
	//	cout << i << ": ";
	//	for (int j = 0; j < thisMST->adjList[i].dtNeighborList.size(); j++)
	//	{
	//		cout << "d(" << thisMST->adjList[i].dtNeighborList[j].index << ") = " << thisMST->adjList[i].dtNeighborList[j].dist << ", ";
	//	}
	//	cout << endl;
	//}

	//// output and check correctness
	//ofstream outfile;
	//outfile.open("MST.txt");
	//for (list<dtEdge>::iterator i = thisMST->edgeList.begin(); i != thisMST->edgeList.end(); ++i)
	//{
	//	outfile << i->v1.index << " " << i->v2.index << endl;
	//}
	//outfile.close();

	//clock_t t4 = clock();

	//cout << t2-t1 << " " << t3-t2 << " " << t4-t3 << endl;
}

bool CheckCycle(int src,int des, vector<int> & pred)
{
	
	while(pred[des]!=-1)
		des = pred[des];

	while(pred[src]!=-1)
		src = pred[src];
	
	if(src!=des)
	{
		pred[des]=src;
		return true;
	}
	return false;
}