
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Obtaining the Minimal Spanning Tree
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MST_H
#define MST_H

using namespace std;
#include <iostream>
#include <vector>
#include <fstream>
#include <time.h>

#include "problem.h"
#include "city.h"
#include "delaunay2D.h"

typedef struct minSpanTree // represented as adjacency list
{
	vector<city> adjList;
	list<dtEdge> edgeList;
} minSpanTree;

struct edgeShorter
{
    inline bool operator() (const dtEdge& struct1, const dtEdge& struct2)
    {
		return (struct1.length < struct2.length);
    }
};

// Get the minimal spanning tree by Kruskal algorithm, given the graph in thisDT
void GetMinSpanTree(minSpanTree *thisMST, delaunayTriangulation *thisDT, problem *thisProb);

// Chech whether (src, des) form a cycle
bool CheckCycle(int src,int des, vector<int> & pred);

#endif