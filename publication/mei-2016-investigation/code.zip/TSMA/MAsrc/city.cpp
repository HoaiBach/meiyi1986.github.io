
#include "city.h"

double EuclDist(city city1, city city2)
{
	double diff1 = (double) (city1.xcord-city2.xcord);
	double diff2 = (double) (city1.ycord-city2.ycord);
	return sqrt (diff1 * diff1 + diff2 * diff2);
}

int CeilEuclDist(city city1, city city2)
{
	double diff1 = (double) (city1.xcord-city2.xcord);
	double diff2 = (double) (city1.ycord-city2.ycord);
	return (int) (ceil (sqrt (diff1 * diff1 + diff2 * diff2)));
}

int L1Dist(city city1, city city2)
{
	int diff1 = (city1.xcord-city2.xcord);
	int diff2 = (city1.ycord-city2.ycord);

	return abs(diff1)+abs(diff2);
}

void PrintDTNeighbors(city & c)
{
	for (vector<dtNeighbor>::iterator it = c.dtNeighborList.begin(); it != c.dtNeighborList.end(); ++it)
	{
		cout << it->index << ": " << it->dist << endl;
	}
}

void PrintNeighborVec(vector<dtNeighbor> dtNeigVec)
{
	for (vector<dtNeighbor>::iterator it = dtNeigVec.begin(); it != dtNeigVec.end(); ++it)
	{
		cout << it->index << ": " << it->dist << endl;
	}
}