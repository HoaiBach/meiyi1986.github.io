
#ifndef CITY_H
#define CITY_H

using namespace std;
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm> // for sorting

typedef struct dtNeighbor // the DT neighbor of a city
{
	int index;
	int dist;
} dtNeighbor;

typedef struct city
{
	int index; // index
	double xcord; // x cordinate
	double ycord; // y cordinate
	double totalProfit; // the total profit of items available in this city
	double totalWeight; // the total weight of items available in this city
	double wpRatio;
	vector<dtNeighbor> dtNeighborList; // the nearest neighbors of this city
	bool inDT; // whether it is in Delaunay Triangulation?
} city;



// the Euclidean distance between city1 and city2
double EuclDist(city city1, city city2);

// the Ceiling Euclidean distance between city1 and city2
int CeilEuclDist(city city1, city city2);

// the L1 distance between city1 and city2
int L1Dist(city city1, city city2);

// find the neighbor with smaller distance
struct distSmaller
{
	inline bool operator() (const dtNeighbor& struct1, const dtNeighbor& struct2)
    {
		return (struct1.dist < struct2.dist);
    }
};


// print the neighbors and distance of a city
void PrintDTNeighbors(city & c);

void PrintNeighborVec(vector<dtNeighbor> dtNeigVec);

#endif