
#include "delaunay2D.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetDelaunayTriangulation(delaunayTriangulation *thisDT, problem *thisProb)
{
	// get the node set
	vector<city> yxIncCitySet(thisProb->cities); // with first y increase, and then x increase
	// sort the cities lexicographically, ignore city[0]
	sort(yxIncCitySet.begin()+1, yxIncCitySet.end(), yxSmaller());

	/*for (vector<city>::size_type i = 1; i != yxIncCitySet.size(); i++)
	{
		cout << yxIncCitySet[i].index << ": " << "(" << yxIncCitySet[i].xcord << ", " << yxIncCitySet[i].ycord << ")" << endl;
		system("PAUSE");
	}*/

	vector<city>::size_type initDTSize;
	InitDelaunayTriangulation(thisDT, &yxIncCitySet, initDTSize);

	//cout << "init size = " << initDTSize << endl;
	//PrintDTEdgeList(thisDT->dtEdgeList);
	//system("PAUSE");

	list<city>::iterator currFrontPtr = thisDT->advFront.begin();
	for (vector<city>::size_type i = initDTSize+1; i != yxIncCitySet.size(); i++) // start from the first city after the initial set
	{
		//cout << i << "/" << yxIncCitySet.size() << ", front size = " << thisDT->advFront.size() << ", inserting " << yxIncCitySet[i].index << endl;
		currFrontPtr = InsertDelaunayTriangulation(thisDT, yxIncCitySet[i], currFrontPtr);
		//cout << "end insert " << yxIncCitySet[i].index << endl;

		//for (list<dtEdge>::iterator it = thisDT->dtEdgeList.begin(); it != thisDT->dtEdgeList.end(); ++it)
		//{
		//	bool valid = TwoTriValid(it);
		//	if (!valid)
		//	{
		//		cout << "invalid!" << endl;
		//		system("PAUSE");
		//	}
		//}
	}

	// finalize the advance front
	Finalize(thisDT);

	// get the length of each dtEdge
	for (list<dtEdge>::iterator it = thisDT->dtEdgeList.begin(); it != thisDT->dtEdgeList.end(); ++it)
	{
		it->length = CeilEuclDist(it->v1, it->v2);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void InitDelaunayTriangulation(delaunayTriangulation *thisDT, vector<city> *citySet, vector<city>::size_type &initDTSize)
{
	// get the first three nodes, ignore city[0]
	vector<city> initCitySet(citySet->begin()+1, citySet->begin()+4);
	initDTSize = 3;

	/*for (vector<city>::size_type i = 0; i != initCitySet.size(); i++)
	{
		cout << "(" << initCitySet[i].xcord << ", " << initCitySet[i].ycord << ")" << endl;
	}
	system("PAUSE");*/

	if (initCitySet.size() < 3)
	{
		perror("not enough initial set!");
	}

	while (Collinear(&initCitySet))
	{
		initDTSize ++;
		initCitySet.push_back(citySet->at(initDTSize));
	}

	// get the bottom and top cities (the first and last ones in the initial set)
	thisDT->bottom = initCitySet.front().ycord;
	thisDT->top = initCitySet.back().ycord;

	/*for (vector<city>::size_type i = 0; i != initCitySet.size(); i++)
	{
		cout << "(" << initCitySet[i].xcord << ", " << initCitySet[i].ycord << ")" << endl;
	}
	system("PAUSE");*/

	// get initial leftmost, rightmost, lower convex hull and advance front
	sort(initCitySet.begin(), initCitySet.end(), xySmaller());
	thisDT->leftmost = initCitySet.front().xcord;
	thisDT->rightmost = initCitySet.back().xcord;

	thisDT->lowerHull.push_back(initCitySet.front());
	thisDT->advFront.push_back(initCitySet.front());
	for (vector<city>::size_type i = 1; i != initCitySet.size()-1; i++) // excluding leftmost and rightmost
	{
		if (initCitySet[i].ycord > initCitySet.front().ycord && initCitySet[i].ycord > initCitySet.back().ycord)
		{
			thisDT->advFront.push_back(initCitySet[i]);
		}
		else if (initCitySet[i].ycord <= initCitySet.front().ycord && initCitySet[i].ycord <= initCitySet.back().ycord)
		{
			thisDT->lowerHull.push_back(initCitySet[i]);
		}
		else
		{
			if (LowerTriangle(initCitySet.front(), initCitySet[i], initCitySet.back()))
			{
				thisDT->lowerHull.push_back(initCitySet[i]);
			}
			else
			{
				thisDT->advFront.push_back(initCitySet[i]);
			}
		}
	}
	thisDT->lowerHull.push_back(initCitySet.back());
	thisDT->advFront.push_back(initCitySet.back());

	// construct the dtEdge list
	// there are 2n-3 initial edges in total, where the first (n-2) edges are (c[i],c[i+1]), i = 1,...,n-2, and the last (n-1) edges are (c[i],c[n]), i = 1,...,n-1
	// the iterator of (c[i],c[i+1]) is (i-1) for i=1,...,n-2, and of (c[i],c[n]) is (n-3+i) for i=1,...,n-1
	thisDT->dtEdgeList.resize(2*initDTSize-3);
	list<dtEdge>::iterator edgePtr = thisDT->dtEdgeList.begin();

	// the edges (c[i],c[i+1]), forming triangle with c[n], with one triangle and two associate edges (c[i],c[n]) and (c[i+1],c[n])
	for (vector<city>::size_type i = 1; i < initDTSize-1; i++)
	{
		dtEdge tmpEdge;
		tmpEdge.v1 = citySet->at(i);
		tmpEdge.v2 = citySet->at(i+1);
		//tmpEdge.dtNeighborList.push_back(citySet->at(initDTSize));
		tmpEdge.numTriangles = 1;
		tmpEdge.triv1 = citySet->at(initDTSize);
		tmpEdge.assoEdge11 = thisDT->dtEdgeList.begin();
		advance(tmpEdge.assoEdge11, initDTSize-3+i);
		tmpEdge.assoEdge12 = tmpEdge.assoEdge11;
		++tmpEdge.assoEdge12;
		*edgePtr = tmpEdge;
		++edgePtr;

		//if ((FindCity(thisDT->advFront.begin(), thisDT->advFront.end(), tmpEdge.v1) != thisDT->advFront.end()) &&
		//	(FindCity(thisDT->advFront.begin(), thisDT->advFront.end(), tmpEdge.v2) != thisDT->advFront.end())) // both nodes are in advance front
		//{
		//	thisDT->advFrontEdges.push_back(tmpEdge);
		//}
	}

	// the edges (c[i],c[n]), forming two triangles with c[i-1] and c[i+1] except the first and last elements, 
	// and four (two) edges (c[i-1],c[n]), (c[i-1],c[i]), (c[i+1],c[n]), (c[i], c[i+1])
	for (vector<city>::size_type i = 1; i < initDTSize; i++)
	{
		dtEdge tmpEdge;
		tmpEdge.v1 = citySet->at(i);
		tmpEdge.v2 = citySet->at(initDTSize);
		if (i == 1) // only one triangle with two edges (c[i+1],c[n]), (c[i], c[i+1])
		{
			tmpEdge.numTriangles = 1;
			tmpEdge.triv1 = citySet->at(i+1);
			tmpEdge.assoEdge11 = edgePtr;
			++tmpEdge.assoEdge11;
			tmpEdge.assoEdge12 = thisDT->dtEdgeList.begin();
			advance(tmpEdge.assoEdge12, i-1);
			//tmpEdge.dtNeighborList.push_back(citySet->at(i-1));
		}
		else if (i == initDTSize-1) // only one triangle with two edges (c[i-1],c[n]), (c[i-1], c[i])
		{
			tmpEdge.numTriangles = 1;
			tmpEdge.triv1 = citySet->at(i-1);
			tmpEdge.assoEdge11 = edgePtr;
			--tmpEdge.assoEdge11;
			tmpEdge.assoEdge12 = thisDT->dtEdgeList.begin();
			advance(tmpEdge.assoEdge12, i-2);
			//tmpEdge.dtNeighborList.push_back(citySet->at(i+1));
		}
		else
		{
			tmpEdge.numTriangles = 2;
			tmpEdge.triv1 = citySet->at(i-1);
			tmpEdge.assoEdge11 = edgePtr;
			--tmpEdge.assoEdge11;
			tmpEdge.assoEdge12 = thisDT->dtEdgeList.begin();
			advance(tmpEdge.assoEdge12, i-2);
			tmpEdge.triv2 = citySet->at(i+1);
			tmpEdge.assoEdge21 = edgePtr;
			++tmpEdge.assoEdge21;
			tmpEdge.assoEdge22 = tmpEdge.assoEdge12;
			++tmpEdge.assoEdge22;
			//tmpEdge.dtNeighborList.push_back(citySet->at(i-1));
			//tmpEdge.dtNeighborList.push_back(citySet->at(i+1));
		}
		
		*edgePtr = tmpEdge;
		++edgePtr;

		//if ((FindCity(thisDT->advFront.begin(), thisDT->advFront.end(), tmpEdge.v1) != thisDT->advFront.end()) &&
		//	(FindCity(thisDT->advFront.begin(), thisDT->advFront.end(), tmpEdge.v2) != thisDT->advFront.end())) // both nodes are in advance front
		//{
		//	thisDT->advFrontEdges.push_back(tmpEdge);
		//}
	}

	/*cout << "initial lower hull" << endl;
	PrintCityList(thisDT->lowerHull);
	cout << "initial advance front" << endl;
	PrintCityList(thisDT->advFront);
	cout << thisDT->leftmost.xcord << " " << thisDT->rightmost.xcord << endl;
	system("PAUSE");*/
}

bool Collinear(vector<city> *citySet)
{
	city c1 = citySet->front(); // the first element
	city c2 = citySet->at(1); // the second element
	city c3 = citySet->back(); // the last element

	double dx1 = 1.0*(c2.xcord-c1.xcord);
	double dy1 = 1.0*(c2.ycord-c1.ycord);
	double dx2 = 1.0*(c3.xcord-c1.xcord);
	double dy2 = 1.0*(c3.ycord-c1.ycord);

	return (dx1*dy2 == dx2*dy1);
}

bool Collinear(list<city> *citySet)
{
	list<city>::iterator it = citySet->begin();
	++it;
	city c1 = citySet->front(); // the first element
	city c2 = *it; // the second element
	city c3 = citySet->back(); // the last element

	double dx1 = 1.0*(c2.xcord-c1.xcord);
	double dy1 = 1.0*(c2.ycord-c1.ycord);
	double dx2 = 1.0*(c3.xcord-c1.xcord);
	double dy2 = 1.0*(c3.ycord-c1.ycord);

	return (dx1*dy2 == dx2*dy1);
}

bool Collinear(city &c1, city & c2, city & c3)
{
	double dx1 = 1.0*(c2.xcord-c1.xcord);
	double dy1 = 1.0*(c2.ycord-c1.ycord);
	double dx2 = 1.0*(c3.xcord-c1.xcord);
	double dy2 = 1.0*(c3.ycord-c1.ycord);

	return (dx1*dy2 == dx2*dy1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

list<city>::iterator InsertDelaunayTriangulation(delaunayTriangulation *thisDT, city & c, list<city>::iterator currFrontPtr)
{
	//clock_t t1 = clock();

	// find all the previous points with the same location
	bool overlap = false;
	for (list<city>::iterator it = thisDT->advFront.begin(); it != thisDT->advFront.end(); ++it)
	{
		if (it->xcord == c.xcord && it->ycord == c.ycord)
		{
			cout << c.index << " is found to overlap with " << it->index << endl;
			overlap = true;
			break;
		}
	}

	//clock_t t2 = clock();

	if (overlap) // there exist overlapping points, skip this point
		return currFrontPtr;

	//ofstream outfile;
	//outfile.open("edges.txt");
	//for (list<dtEdge>::iterator i = thisDT->dtEdgeList.begin(); i != thisDT->dtEdgeList.end(); ++i)
	//{
	//	outfile << i->v1.index << " " << i->v2.index << endl;
	//}
	//outfile.close();

	//cout << "begin insert " << c.index << ": " << currFrontPtr->index << endl;
	//cout << thisDT->leftmost << " " << currFrontPtr->xcord << " " << thisDT->rightmost << " " << c.xcord << endl;
	//cout << "front" << endl;
	//PrintCityList(thisDT->advFront);
	//cout << "hull" << endl;
	//PrintCityList(thisDT->lowerHull);
	////cout << "edge list" << endl;
	////PrintDTEdgeList(thisDT->dtEdgeList);
	//system("PAUSE");

	// update the top city of this DT with c (
	if (c.ycord > thisDT->top)
		thisDT->top = c.ycord;

	// the inserted city is the new leftmost
	if (c.xcord < thisDT->leftmost)
	{
		//cout << "case1" << endl;

		thisDT->leftmost = c.xcord;
		list<city>::iterator left = thisDT->advFront.begin();
		list<city>::iterator right = left;
		++right;

		//cout << "(" << c.index << ", " << left->index << ", " << right->index << ")" << endl;
		////cout << "before" << endl;
		////PrintDTEdgeList(thisDT->dtEdgeList);
		//cout << "before lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "before advance front" << endl;
		//PrintCityList(thisDT->advFront);

		// add edges (c,left) and (c,right) to the edge list
		dtEdge tmpEdge1, tmpEdge2;
		
		if (LowerTriangle(c, *left, *right))
		{
			//cout << "case 1.1" << endl;

			// form the triangle (c,left,right) by adding two edges (c,left) and (c,right)
			thisDT->dtEdgeList.resize(thisDT->dtEdgeList.size()+2); // add two locations
			// edge (c,left), with two associate edges (c,right) and (left,right)
			tmpEdge1.v1 = c;
			tmpEdge1.v2 = *left;
			//tmpEdge1.dtNeighborList.push_back(*right);
			tmpEdge1.numTriangles = 1;
			tmpEdge1.triv1 = *right;
			tmpEdge1.assoEdge11 = FindEdgeBackward(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right); // the location of (left,right)
			tmpEdge1.assoEdge12 = thisDT->dtEdgeList.end();
			--tmpEdge1.assoEdge12;
			//thisDT->dtEdgeList.push_back(tmpEdge1);
			// edge (c,right), with two associate edges (c,left) and (left,right)
			tmpEdge2.v1 = c;
			tmpEdge2.v2 = *right;
			//tmpEdge2.dtNeighborList.push_back(*left);
			tmpEdge2.numTriangles = 1;
			tmpEdge2.triv1 = *left;
			tmpEdge2.assoEdge11 = tmpEdge1.assoEdge11; // the location of (left,right)
			tmpEdge2.assoEdge12 = tmpEdge1.assoEdge12;
			--tmpEdge2.assoEdge12;
			//thisDT->dtEdgeList.push_back(tmpEdge2);

			// add the associate edges (c,left) and (c,right) to (left,right), whose iterator is tmpEdge1.assoEdge11
			tmpEdge1.assoEdge11->numTriangles = 2; // (left,right) must have already one associate triangle
			tmpEdge1.assoEdge11->triv2 = c;
			tmpEdge1.assoEdge11->assoEdge21 = tmpEdge2.assoEdge12; // iterator of (c,left)
			tmpEdge1.assoEdge11->assoEdge22 = tmpEdge1.assoEdge12; // iterator of (c,right)
			//edgePtr->dtNeighborList.push_back(c);

			// add the two edges in the list
			*tmpEdge2.assoEdge12 = tmpEdge1;
			*tmpEdge1.assoEdge12 = tmpEdge2;

			// add the associate edges (c,left) and (c,right) to (left,right), whose iterator is tmpEdge1.assoEdge11
			tmpEdge1.assoEdge11->numTriangles = 2; // (left,right) must have already one associate triangle
			tmpEdge1.assoEdge11->triv2 = c;
			tmpEdge1.assoEdge11->assoEdge21 = tmpEdge2.assoEdge12; // iterator of (c,left)
			tmpEdge1.assoEdge11->assoEdge22 = tmpEdge1.assoEdge12; // iterator of (c,right)
			//edgePtr->dtNeighborList.push_back(c);

			// check empty circle property from the edge (left,right), whose iterator is tmpEdge1.assoEdge11
			DTEmptyCircle(thisDT, tmpEdge1.assoEdge11);

			// updat advance front
			*left = c;

			currFrontPtr = left;
		}
		else
		{
			//cout << "case 1.2" << endl;

			// only connect the edge (c,left) with no triangle, but will form the triangle when updating the lower convex hull
			tmpEdge1.v1 = c;
			tmpEdge1.v2 = *left;
			tmpEdge1.numTriangles = 0;
			thisDT->dtEdgeList.push_back(tmpEdge1);

			// updat advance front
			thisDT->advFront.push_front(c);

			currFrontPtr = thisDT->advFront.begin();
		}

		//cout << "begin insert " << c.index << ": " << currFrontPtr->index << endl;
		//cout << thisDT->leftmost << " " << currFrontPtr->xcord << " " << thisDT->rightmost << " " << c.xcord << endl;
		//cout << "front" << endl;
		//PrintCityList(thisDT->advFront);
		//cout << "hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "edge list" << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		// update lower convex hull from left

		//for (list<dtEdge>::iterator it = thisDT->dtEdgeList.begin(); it != thisDT->dtEdgeList.end(); ++it)
		//{
		//	bool valid = TwoTriValid(it);
		//	if (!valid)
		//	{
		//		cout << "1 invalid!" << it->v1.index << " " << it->v2.index << endl;
		//		system("PAUSE");
		//	}
		//}
		
		//cout << "start lower" << endl;
		UpdateLeftLowerHull(thisDT, c);

		//for (list<dtEdge>::iterator it = thisDT->dtEdgeList.begin(); it != thisDT->dtEdgeList.end(); ++it)
		//{
		//	bool valid = TwoTriValid(it);
		//	if (!valid)
		//	{
		//		cout << "2 invalid!" << it->v1.index << " " << it->v2.index << endl;
		//		system("PAUSE");
		//	}
		//}

		//cout << "after lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "after advance front" << endl;
		//PrintCityList(thisDT->advFront);
		//system("PAUSE");

		//cout << "before filling " << c.index << ": " << currFrontPtr->index << endl;
		//cout << thisDT->leftmost << " " << currFrontPtr->xcord << " " << thisDT->rightmost << " " << c.xcord << endl;
		//cout << "front" << endl;
		//PrintCityList(thisDT->advFront);
		//cout << "hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "edge list" << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		// fill the basin
		//cout << "start filling" << endl;
		FillBasinLeft(thisDT, c, right);

		//cout << "after" << endl;
		////PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");
	}
	// the inserted city is the new rightmost
	else if (c.xcord > thisDT->rightmost)
	{
		//cout << "case2" << endl;

		thisDT->rightmost = c.xcord;
		list<city>::iterator right = thisDT->advFront.end();
		--right;
		list<city>::iterator left = right;
		--left;

		//cout << "(" << c.index << ", " << left->index << ", " << right->index << ")" << endl;
		////cout << "before" << endl;
		////PrintDTEdgeList(thisDT->dtEdgeList);
		//cout << "before lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "before advance front" << endl;
		//PrintCityList(thisDT->advFront);

		// add edges (c,left) and (c,right) to the edge list
		dtEdge tmpEdge1, tmpEdge2;
		if (LowerTriangle(*left, *right, c))
		{
			//cout << "case 2.1" << endl;

			// form the triangle (c,left,right) by adding two edges (c,left) and (c,right)
			thisDT->dtEdgeList.resize(thisDT->dtEdgeList.size()+2); // add two locations
			// edge (c,left), with two associate edges (c,right) and (left,right)
			tmpEdge1.v1 = c;
			tmpEdge1.v2 = *left;
			//tmpEdge1.dtNeighborList.push_back(*right);
			tmpEdge1.numTriangles = 1;
			tmpEdge1.triv1 = *right;
			tmpEdge1.assoEdge11 = FindEdgeBackward(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right); // the location of (left,right)
			tmpEdge1.assoEdge12 = thisDT->dtEdgeList.end();
			--tmpEdge1.assoEdge12;
			//thisDT->dtEdgeList.push_back(tmpEdge1);
			// edge (c,right), with two associate edges (c,left) and (left,right)
			tmpEdge2.v1 = c;
			tmpEdge2.v2 = *right;
			//tmpEdge2.dtNeighborList.push_back(*left);
			tmpEdge2.numTriangles = 1;
			tmpEdge2.triv1 = *left;
			tmpEdge2.assoEdge11 = tmpEdge1.assoEdge11; // the location of (left,right)
			tmpEdge2.assoEdge12 = tmpEdge1.assoEdge12;
			--tmpEdge2.assoEdge12;
			//thisDT->dtEdgeList.push_back(tmpEdge2);

			// add the associate edges (c,left) and (c,right) to (left,right), whose iterator is tmpEdge1.assoEdge11
			tmpEdge1.assoEdge11->numTriangles = 2; // (left,right) must have already one associate triangle
			tmpEdge1.assoEdge11->triv2 = c;
			tmpEdge1.assoEdge11->assoEdge21 = tmpEdge2.assoEdge12; // iterator of (c,left)
			tmpEdge1.assoEdge11->assoEdge22 = tmpEdge1.assoEdge12; // iterator of (c,right)
			//edgePtr->dtNeighborList.push_back(c);

			// add the two edges in the list
			*tmpEdge2.assoEdge12 = tmpEdge1;
			*tmpEdge1.assoEdge12 = tmpEdge2;

			// add the associate edges (c,left) and (c,right) to (left,right), whose iterator is tmpEdge1.assoEdge11
			tmpEdge1.assoEdge11->numTriangles = 2; // (left,right) must have already one associate triangle
			tmpEdge1.assoEdge11->triv2 = c;
			tmpEdge1.assoEdge11->assoEdge21 = tmpEdge2.assoEdge12; // iterator of (c,left)
			tmpEdge1.assoEdge11->assoEdge22 = tmpEdge1.assoEdge12; // iterator of (c,right)
			//edgePtr->dtNeighborList.push_back(c);

			// check empty circle property from the edge (left,right), whose iterator is tmpEdge1.assoEdge11
			DTEmptyCircle(thisDT, tmpEdge1.assoEdge11);

			// updat advance front
			*right = c;

			currFrontPtr = right;
		}
		else
		{
			//cout << "case 2.2" << endl;
			tmpEdge1.v1 = c;
			tmpEdge1.v2 = *right;
			tmpEdge1.numTriangles = 0;
			thisDT->dtEdgeList.push_back(tmpEdge1);

			// updat advance front
			thisDT->advFront.push_back(c);

			currFrontPtr = thisDT->advFront.end();
			--currFrontPtr;
		}

		// update lower convex hull from right
		
		UpdateRightLowerHull(thisDT, c);

		//cout << "begin filling" << endl;

		// fill the basin
		FillBasinRight(thisDT, c, left);

		//cout << "after" << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		//cout << "after lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "after advance front" << endl;
		//PrintCityList(thisDT->advFront);
		//system("PAUSE");
	}
	// the vertical projection hits the advance front
	else
	{
		//cout << "case3" << endl;

		// find the left and right city
		list<city>::iterator left, right;
		if (c.xcord == thisDT->leftmost) // locate left most, left = first, right = first+1
		{
			left = thisDT->advFront.begin();
			right = left;
			++right;
		}
		else if (c.xcord == thisDT->rightmost) // locate right most, right = last, left = last-1
		{
			right = thisDT->advFront.end();
			--right;
			left = right;
			--left;
		}
		else if (c.xcord == currFrontPtr->xcord) // on top of the current pointer
		{
			list<city>::iterator it = currFrontPtr;
			++it;
			if (it->xcord > c.xcord)
			{
				left = currFrontPtr;
				right = it;
			}
			else
			{
				right = currFrontPtr;
				left = right;
				--left;
			}
		}
		else if (c.xcord < currFrontPtr->xcord)
		{
			if (c.xcord-thisDT->leftmost < currFrontPtr->xcord-c.xcord) // left half, search foward from begin()
			{
				//cout << "case 4.1" << endl;
				right = GetRightForward(thisDT->advFront.begin(), thisDT->advFront.end(), c);
				left = right;
				--left;
			}
			else // right half, search backward from currentFrontPtr
			{
				//cout << "case 4.2" << endl;
				left = GetLeftBackward(thisDT->advFront.begin(), currFrontPtr, c);
				right = left;
				++right;
			}
		}
		else // c.xcord > currFrontPtr->xcord
		{
			if (c.xcord-currFrontPtr->xcord < thisDT->rightmost-c.xcord) // left half, search forward from currFrontPtr
			{
				//cout << "case 4.3" << endl;
				right = GetRightForward(currFrontPtr, thisDT->advFront.end(), c);
				left = right;
				--left;
			}
			else // right half, search backward from last
			{
				//cout << "case 4.4" << endl;
				left = GetLeftBackward(currFrontPtr, thisDT->advFront.end(), c);
				right = left;
				++right;
			}
		}

		//clock_t t3 = clock();

		//list<city>::iterator right1 = thisDT->advFront.begin();
		//while (right1 != thisDT->advFront.end())
		//{
		//	++right1;
		//	if (c.xcord < right1->xcord)
		//	{
		//		break;
		//	}
		//	else if (c.xcord == right1->xcord)
		//	{
		//		list<city>::iterator preright = right1;
		//		--preright;

		//		if (c.xcord > preright->xcord)
		//			break;
		//	}
		//}
		//if (right1 == thisDT->advFront.end()) // c.xcord == thisDT->rightmost.xcord
		//{
		//	--right1; // set right to the last element
		//}
		//list<city>::iterator left1 = right1;
		//--left1;

		//if (left1->index != left->index || right1->index != right->index)
		//{
		//	cout << left->index << " " << right->index << endl;
		//	cout << left1->index << " " << right1->index << endl;
		//	cout << left->xcord << " " << c.xcord << " " << right->xcord << endl;
		//	cout << left1->xcord << " " << c.xcord << " " << right1->xcord << endl;
		//	system("PAUSE");
		//}

		//cout << left->index << " " << right->index << endl;
		//system("PAUSE");

		//cout << "before inserting " << c.index << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);

		//if (c.index == 1)
		//{
		//	cout << c.index << " " << left->index << " " << right->index << endl;
		//cout << c.xcord << " " << thisDT->leftmost.xcord << " " << thisDT->rightmost.xcord << endl;
		//cout << "before lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "before advance front" << endl;
		//PrintCityList(thisDT->advFront);
		//}
		
		// add edges (c,left) and (c,right) to the edge list
		dtEdge tmpEdge1, tmpEdge2;

		// form the triangle (c,left,right) by adding two edges (c,left) and (c,right)
		//thisDT->dtEdgeList.resize(thisDT->dtEdgeList.size()+2); // add two locations
		// edge (c,left), with two associate edges (c,right) and (left,right)
		tmpEdge1.v1 = c;
		tmpEdge1.v2 = *left;
		//tmpEdge1.dtNeighborList.push_back(*right);
		tmpEdge1.numTriangles = 1;
		tmpEdge1.triv1 = *right;
		
		tmpEdge1.assoEdge11 = FindEdgeBackward(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right); // the location of (left,right)
		//tmpEdge1.assoEdge12 is tmpEdge2, which is to be set later
		//tmpEdge1.assoEdge12 = thisDT->dtEdgeList.end();
		//--tmpEdge1.assoEdge12;
		
		// edge (c,right), with two associate edges (c,left) and (left,right)
		tmpEdge2.v1 = c;
		tmpEdge2.v2 = *right;
		//tmpEdge2.dtNeighborList.push_back(*left);
		tmpEdge2.numTriangles = 1;
		tmpEdge2.triv1 = *left;
		tmpEdge2.assoEdge11 = tmpEdge1.assoEdge11; // the location of (left,right)
		//tmpEdge2.assoEdge12 is tmpEdge1, which is to be set later
		//tmpEdge2.assoEdge12 = tmpEdge1.assoEdge12;
		//--tmpEdge2.assoEdge12;
		
		// add the two edges in the list
		thisDT->dtEdgeList.push_back(tmpEdge1);
		thisDT->dtEdgeList.push_back(tmpEdge2);

		// set tmpEdge1.assoEdge12 to tmpEdge2
		list<dtEdge>::iterator edgePtr2 = thisDT->dtEdgeList.end();
		--edgePtr2; // iterator of tmpEdge2
		list<dtEdge>::iterator edgePtr1 = edgePtr2;
		--edgePtr1; // iterator of tmpEdge1
		edgePtr1->assoEdge12 = edgePtr2; // set tmpEdge1.assoEdge12 to tmpEdge2
		edgePtr2->assoEdge12 = edgePtr1; // set tmpEdge1.assoEdge12 to tmpEdge2

		// add the associate edges (c,left) and (c,right) to (left,right), whose iterator is tmpEdge1.assoEdge11
		tmpEdge1.assoEdge11->numTriangles = 2; // (left,right) must have already one associate triangle
		tmpEdge1.assoEdge11->triv2 = c;
		tmpEdge1.assoEdge11->assoEdge21 = edgePtr1; // iterator of (c,left)
		tmpEdge1.assoEdge11->assoEdge22 = edgePtr2; // iterator of (c,right)

		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		//// add the two edges in the list
		//*tmpEdge2.assoEdge12 = tmpEdge1; // add (c,left) first
		//*tmpEdge1.assoEdge12 = tmpEdge2;

		//cout << "before checking " << c.index << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		//clock_t t4 = clock();

		//if (c.index == 197)
		//{
		//	cout << tmpEdge1.assoEdge11->v1.index << " " << tmpEdge1.assoEdge11->v2.index << endl;
		//	//PrintDTEdgeList(thisDT->dtEdgeList);
		//	//system("PAUSE");
		//}

		// check empty circle property from the edge (left,right), whose iterator is tmpEdge1.assoEdge11
		DTEmptyCircle(thisDT, tmpEdge1.assoEdge11);

		//clock_t t5 = clock();

		//cout << "after checking " << c.index << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		// update the advance front and lower convex hull
		if (c.xcord == thisDT->leftmost)
		{
			/*cout << "case 1" << endl;
			cout << "before lower hull" << endl;
			PrintCityList(thisDT->lowerHull);
			cout << "before advance front" << endl;
			PrintCityList(thisDT->advFront);*/

			*left = c;
			thisDT->lowerHull.push_front(c);

			currFrontPtr = left;
			//cout << "1 after insert " << c.index << ", point to " << currFrontPtr->index << endl;

			/*cout << "after lower hull" << endl;
			PrintCityList(thisDT->lowerHull);
			cout << "after advance front" << endl;
			PrintCityList(thisDT->advFront);
			system("PAUSE");*/
		}
		else if (c.xcord == thisDT->rightmost)
		{
			/*cout << "case 2" << endl;
			cout << "before lower hull" << endl;
			PrintCityList(thisDT->lowerHull);
			cout << "before advance front" << endl;
			PrintCityList(thisDT->advFront);*/

			*right = c;
			thisDT->lowerHull.push_back(c);

			currFrontPtr = right;
			//cout << "2 after insert " << c.index << ", point to " << currFrontPtr->index << endl;

			/*cout << "after lower hull" << endl;
			PrintCityList(thisDT->lowerHull);
			cout << "after advance front" << endl;
			PrintCityList(thisDT->advFront);
			system("PAUSE");*/
		}
		else
		{
			currFrontPtr = thisDT->advFront.insert(right, c);
			//cout << "3 after insert " << c.index << ", point to " << currFrontPtr->index << endl;
		}

		//if (c.index == 1)
		//{
		//	cout << "after lower hull" << endl;
		//PrintCityList(thisDT->lowerHull);
		//cout << "after advance front" << endl;
		//PrintCityList(thisDT->advFront);
		//system("PAUSE");
		//}

		//if (c.index == 958)
		//	cout << "before" << endl;

		//clock_t t6 = clock();

		// fill the basin
		//cout << "begin basin" << endl;
		//cout << left->index << " " << right->index << endl;
		FillBasinLeft(thisDT, c, right);

		//if (c.index == 958)
		//	cout << "before 2" << endl;
		//cout << left->index << " " << right->index << endl;
		FillBasinRight(thisDT, c, left);
		//cout << "end basin" << endl;

		//clock_t t7 = clock();

		//if (c.index == 958)
		//	cout << "after" << endl;

		//cout << "after inserting " << c.index << endl;
		//PrintDTEdgeList(thisDT->dtEdgeList);
		//system("PAUSE");

		//double dt1 = (double)(t2-t1);
		//double dt2 = (double)(t3-t2);
		//double dt3 = (double)(t4-t3);
		//double dt4 = (double)(t5-t4);
		//double dt5 = (double)(t6-t5);
		//double dt6 = (double)(t7-t6);

		//cout << dt1 << " " << dt2 << " " << dt3 << " " << dt4 << " " << dt5 << " " << dt6 << endl;
		//cout << dt3 << endl;
	}

	return currFrontPtr;
}




list<city>::iterator FindCity(list<city>::iterator first, list<city>::iterator last, city & c)
{
	while (first != last)
	{
		if (first->index == c.index)
			return first;

		++first;
	}
	return last;
}

list<dtEdge>::iterator FindEdge(list<dtEdge>::iterator first, list<dtEdge>::iterator last, city & c1, city & c2)
{
	while (first != last)
	{
		if ((first->v1.index == c1.index && first->v2.index == c2.index) ||
			(first->v1.index == c2.index && first->v2.index == c1.index))
			return first;

		++first;
	}
	return last;
}

list<dtEdge>::iterator FindEdgeBackward(list<dtEdge>::iterator first, list<dtEdge>::iterator last, city & c1, city & c2)
{
	--last;
	while (first != last)
	{
		if ((last->v1.index == c1.index && last->v2.index == c2.index) ||
			(last->v1.index == c2.index && last->v2.index == c1.index))
			return last;

		--last;
	}
	return first;
}

list<dtEdge>::iterator FindEdgeIndex(list<dtEdge>::iterator first, list<dtEdge>::iterator last, int cid1, int cid2)
{
	while (first != last)
	{
		if ((first->v1.index == cid1 && first->v2.index == cid2) ||
			(first->v1.index == cid2 && first->v2.index == cid1))
			return first;

		++first;
	}
	return last;
}

void DTEmptyCircle(delaunayTriangulation *thisDT, list<dtEdge>::iterator startEdgePtr)
{
	//if (startEdgePtr->v1.index == 33266 && startEdgePtr->v2.index == 33262)
	//{
	//	PrintDTEdge(*startEdgePtr);
	//	cout << "is empty? " << EdgeEmptyCircle(startEdgePtr) << endl;
	//	system("PAUSE");
	//}

	// check the validity of the edge
	//bool valid = TwoTriValid(startEdgePtr);
	//if (!valid)
	//{
	//	cout << "invalid edge" << endl;
	//}

	if (EdgeEmptyCircle(startEdgePtr)) // satisfies the empty circle property
	{
		// cout << "v1 = " << startEdgePtr->v1.index << ", v2 = " << startEdgePtr->v2.index << ", empty!" << endl;
		return;
	}

	//cout << "empty circle change" << endl;

	//cout << "change edge (" << startEdgePtr->v1.index << ", " << startEdgePtr->v2.index << ") to (" 
	//	<< startEdgePtr->triv1.index << ", " << startEdgePtr->triv2.index << ")" << endl;

	// modify the associate edges
	list<dtEdge>::iterator e11, e12, e21, e22; // e11 = (triv1,v1), e12 = (triv1,v2), e21 = (triv2,v1), e22 = (triv2,v2)

	if ((startEdgePtr->assoEdge11->v1.index == startEdgePtr->v1.index) ||
		(startEdgePtr->assoEdge11->v2.index == startEdgePtr->v1.index)) // this associate edge is (triv1,v1)
	{
		e11 = startEdgePtr->assoEdge11;
		e12 = startEdgePtr->assoEdge12;
	}
	else // this associate edge is (triv1,v2)
	{
		e11 = startEdgePtr->assoEdge12;
		e12 = startEdgePtr->assoEdge11;
	}
	if ((startEdgePtr->assoEdge21->v1.index == startEdgePtr->v1.index) ||
		(startEdgePtr->assoEdge21->v2.index == startEdgePtr->v1.index)) // this associate edge is (triv2,v1)
	{
		e21 = startEdgePtr->assoEdge21;
		e22 = startEdgePtr->assoEdge22;
	}
	else
	{
		e21 = startEdgePtr->assoEdge22;
		e22 = startEdgePtr->assoEdge21;
	}

	// update the associate edges of e11, e12, e21, e22
	// fine the original triv = v2 for e11
	if (e11->triv1.index == startEdgePtr->v2.index) // in the first triangle
	{
		e11->triv1 = startEdgePtr->triv2; // change v2 to triv2
		e11->assoEdge11 = startEdgePtr; // later change to (triv1,triv2)
		e11->assoEdge12 = e21; // (triv2,v1)
	}
	else // must in the second triangle
	{
		e11->triv2 = startEdgePtr->triv2; // change v2 to triv2
		e11->assoEdge21 = startEdgePtr; // later change to (triv1,triv2)
		e11->assoEdge22 = e21; // (triv2,v1)
	}

	// find the original triv = v1 for e12
	if (e12->triv1.index == startEdgePtr->v1.index) // in the first triangle
	{
		e12->triv1 = startEdgePtr->triv2; // change v1 to triv2
		e12->assoEdge11 = startEdgePtr; // later change to (triv1,triv2)
		e12->assoEdge12 = e22; // (triv2,v2)
	}
	else // must in the second triangle
	{
		e12->triv2 = startEdgePtr->triv2; // change v2 to triv2
		e12->assoEdge21 = startEdgePtr; // later change to (triv1,triv2)
		e12->assoEdge22 = e22; // (triv2,v2)
	}

	// find the original triv = v2 for e21
	if (e21->triv1.index == startEdgePtr->v2.index) // in the first triangle
	{
		e21->triv1 = startEdgePtr->triv1; // change v2 to triv1
		e21->assoEdge11 = startEdgePtr; // later change to (triv1,triv2)
		e21->assoEdge12 = e11; // (triv1,v1)
	}
	else // must in the second triangle
	{
		e21->triv2 = startEdgePtr->triv1; // change v2 to triv1
		e21->assoEdge21 = startEdgePtr; // later change to (triv1,triv2)
		e21->assoEdge22 = e11; // (triv1,v1)
	}

	// find the original triv = v1 for e22
	if (e22->triv1.index == startEdgePtr->v1.index) // in the first triangle
	{
		e22->triv1 = startEdgePtr->triv1; // change v1 to triv1
		e22->assoEdge11 = startEdgePtr; // later change to (triv1,triv2)
		e22->assoEdge12 = e12; // (triv1,v2)
	}
	else // must in the second triangle
	{
		e22->triv2 = startEdgePtr->triv1; // change v2 to triv1
		e22->assoEdge21 = startEdgePtr; // later change to (triv1,triv2)
		e22->assoEdge22 = e12; // (triv1,v2)
	}

	// change aedge11 and aedge12 of this edge to (triv1,v1) and (triv2,v1)
	startEdgePtr->assoEdge11 = e11;
	startEdgePtr->assoEdge12 = e21;
	// change aedge21 and aedge22 of this edge to (triv1,v2) and (triv2,v2)
	startEdgePtr->assoEdge21 = e12;
	startEdgePtr->assoEdge22 = e22;

	// modify the edge startEdgePtr and its four associated edges
	// modify startEdgePtr: (v1,v2) --> (triv1,triv2)
	city tmpv;
	// swap v1 and triv1
	tmpv = startEdgePtr->v1;
	startEdgePtr->v1 = startEdgePtr->triv1;
	startEdgePtr->triv1 = tmpv;
	// swap v2 and triv2
	tmpv = startEdgePtr->v2;
	startEdgePtr->v2 = startEdgePtr->triv2;
	startEdgePtr->triv2 = tmpv;

	//cout << "after change " << endl;
	//PrintDTEdgeList(thisDT->dtEdgeList);
	//system("PAUSE");

	/*cout << "update" << endl;
	PrintDTEdgeList(thisDT->dtEdgeList);
	cout << "end" << endl;
	system("PAUSE");*/

	// record the nodes of the edges
	int v121 = startEdgePtr->assoEdge12->v1.index;
	int v122 = startEdgePtr->assoEdge12->v2.index;
	int v211 = startEdgePtr->assoEdge21->v1.index;
	int v212 = startEdgePtr->assoEdge21->v2.index;
	int v221 = startEdgePtr->assoEdge22->v1.index;
	int v222 = startEdgePtr->assoEdge22->v2.index;

	//valid = TwoTriValid(startEdgePtr);
	//if (!valid)
	//{
	//	cout << "invalid edge" << endl;
	//}

	// check from edge11
	DTEmptyCircle(thisDT, startEdgePtr->assoEdge11);
	if (startEdgePtr->assoEdge12->v1.index == v121 && startEdgePtr->assoEdge12->v2.index == v122) // edge12 unchanged
	{
		DTEmptyCircle(thisDT, startEdgePtr->assoEdge12);
	}
	if (startEdgePtr->assoEdge21->v1.index == v211 && startEdgePtr->assoEdge21->v2.index == v212) // edge21 unchanged
	{
		DTEmptyCircle(thisDT, startEdgePtr->assoEdge21);
	}
	if (startEdgePtr->assoEdge22->v1.index == v221 && startEdgePtr->assoEdge22->v2.index == v222) // edge22 unchanged
	{
		DTEmptyCircle(thisDT, startEdgePtr->assoEdge22);
	}
}

bool EdgeEmptyCircle(list<dtEdge>::iterator edgePtr)
{
	if (edgePtr->numTriangles <= 1) // only one neighbor, only one triangle
		return true;

	double x1 = (double)edgePtr->v1.xcord;
	double y1 = (double)edgePtr->v1.ycord;
	double x2 = (double)edgePtr->v2.xcord;
	double y2 = (double)edgePtr->v2.ycord;
	double x3 = (double)edgePtr->triv1.xcord;
	double y3 = (double)edgePtr->triv1.ycord;
	double x4 = (double)edgePtr->triv2.xcord;
	double y4 = (double)edgePtr->triv2.ycord;

	// calculate the first circle
	double a = 2*(x2-x1);
	double b = 2*(y2-y1);
	double c = x2*x2+y2*y2-x1*x1-y1*y1;
	double d1 = 2*(x3-x2);
	double e1 = 2*(y3-y2);
	double f1 = x3*x3+y3*y3-x2*x2-y2*y2;
	double cx1 = (b*f1-e1*c)/(b*d1-e1*a);
	double cy1 = (d1*c-a*f1)/(b*d1-e1*a);
	double dist13 = (cx1-x3)*(cx1-x3)+(cy1-y3)*(cy1-y3);
	double dist14 = (cx1-x4)*(cx1-x4)+(cy1-y4)*(cy1-y4);
	bool empty1 = ((dist13-dist14)/dist14 < 1e-10);
	//bool empty1 = ((cx1-x3)*(cx1-x3)+(cy1-y3)*(cy1-y3) <= 
	//	(cx1-x4)*(cx1-x4)+(cy1-y4)*(cy1-y4));

	

	//if (edgePtr->v1.index == 167 && edgePtr->v2.index == 172)
	//{
	//	double dist11 = (cx1-x1)*(cx1-x1)+(cy1-y1)*(cy1-y1);
	//	double dist12 = (cx1-x2)*(cx1-x2)+(cy1-y2)*(cy1-y2);
	//	double dist13 = (cx1-x3)*(cx1-x3)+(cy1-y3)*(cy1-y3);
	//	double dist14 = (cx1-x4)*(cx1-x4)+(cy1-y4)*(cy1-y4);

	//	cout << "(" << edgePtr->v1.xcord << ", " << edgePtr->v1.ycord << ")" << endl;
	//	cout << "(" << edgePtr->v2.xcord << ", " << edgePtr->v2.ycord << ")" << endl;
	//	cout << "(" << c3->xcord << ", " << c3->ycord << ")" << endl;
	//	cout << "(" << c4->xcord << ", " << c4->ycord << ")" << endl;
	//	cout << "center1 = (" << cx1 << ", " << cy1 << ")" << endl;
	//	cout << dist11 << " " << dist12 << " " << dist13 << " " << dist14 << endl;
	//
	//	cout << edgePtr->v1.index << " " << edgePtr->v2.index << " " << c3->index << " " << c4->index << ": " << empty1 << endl;
	//}

	if (!empty1)
		return false;

	// calculate the second circle
	double d2 = 2*(x4-x2);
	double e2 = 2*(y4-y2);
	double f2 = x4*x4+y4*y4-x2*x2-y2*y2;
	double cx2 = (b*f2-e2*c)/(b*d2-e2*a);
	double cy2 = (d2*c-a*f2)/(b*d2-e2*a);
	double dist23 = (cx2-x3)*(cx2-x3)+(cy2-y3)*(cy2-y3);
	double dist24 = (cx2-x4)*(cx2-x4)+(cy2-y4)*(cy2-y4);
	bool empty2 = ((dist24-dist23)/dist23 < 1e-10);
	//bool empty2 = ((cx2-x4)*(cx2-x4)+(cy2-y4)*(cy2-y4) <=
	//	(cx2-x3)*(cx2-x3)+(cy2-y3)*(cy2-y3));

	

	//if (edgePtr->v1.index == 167 && edgePtr->v2.index == 172)
	//{
	//	double dist21 = (cx2-x1)*(cx2-x1)+(cy2-y1)*(cy2-y1);
	//	double dist22 = (cx2-x2)*(cx2-x2)+(cy2-y2)*(cy2-y2);
	//	double dist23 = (cx2-x3)*(cx2-x3)+(cy2-y3)*(cy2-y3);
	//	double dist24 = (cx2-x4)*(cx2-x4)+(cy2-y4)*(cy2-y4);
	//	cout << dist21 << " " << dist22 << " " << dist23 << " " << dist24 << endl;

	//	cout << edgePtr->v1.index << " " << edgePtr->v2.index << " " << c3->index << " " << c4->index << ": " << empty1 << " " << empty2 << endl;
	//}

	return (empty1 && empty2);
}

void FillBasinLeft(delaunayTriangulation *thisDT, city & c, list<city>::iterator right)
{
	// Check and fill the basin
	list<city>::iterator rightFollower = right;
	//++rightFollower;
	if (rightFollower != thisDT->advFront.end()) // right is not the last element in the advance front
	{
		// the angle between c and rightFollower is smaller than 3pi/4 under the current DT (need normalization)
		double xNormCoef = 1.0/(thisDT->rightmost-thisDT->leftmost);
		double yNormCoef = 1.0/(thisDT->top-thisDT->bottom);
		if ((c.ycord-rightFollower->ycord)*yNormCoef > (rightFollower->xcord-c.xcord)*xNormCoef)
		{
			list<city>::iterator basinBottom = rightFollower;
			int bottomy = basinBottom->ycord;
			++basinBottom;
			while (basinBottom != thisDT->advFront.end() && basinBottom->ycord < bottomy)
			{
				bottomy = basinBottom->ycord;
				++basinBottom;
			}
			list<city> cityChain1(rightFollower, basinBottom);
			--basinBottom;

			if (basinBottom != rightFollower)
			{
				list<city>::iterator rightBorder = basinBottom;
				++rightBorder;
				while (rightBorder != thisDT->advFront.end() && 
					((rightBorder->ycord > bottomy) || (rightBorder->ycord == bottomy && bottomy < rightFollower->ycord)))
				{
					bottomy = rightBorder->ycord;
					++rightBorder;
				}
				list<city> cityChain2(basinBottom, rightBorder);

				if (cityChain2.size() >= 2) // rightBorder != basinBottom
				{
					/*cout << "chain1" << endl;
					PrintCityList(cityChain1);
					cout << "chain2" << endl;
					PrintCityList(cityChain2);*/

					/*for (list<city>::iterator it = cityChain1.begin(); it != cityChain1.end(); ++it)
					{
						list<city>::iterator tmpit = it;
						++tmpit;
						if (tmpit == cityChain1.end())
							break;

						list<dtEdge>::iterator printEdge = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *it, *tmpit);
						PrintDTEdge(*printEdge);
					}
					for (list<city>::iterator it = cityChain2.begin(); it != cityChain2.end(); ++it)
					{
						list<city>::iterator tmpit = it;
						++tmpit;
						if (tmpit == cityChain2.end())
							break;

						list<dtEdge>::iterator printEdge = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *it, *tmpit);
						PrintDTEdge(*printEdge);
					}
					system("PAUSE");*/

					list<city>::iterator it1 = cityChain2.begin();
					list<city>::iterator it2 = it1;
					++it2;
					list<city>::iterator it3 = cityChain1.end();
					--it3;
					--it3;

					//cout << "forming triangle (" << it2->index << ", " << it3->index << ", " << it1->index << ")" << endl;

					FormTriangle(thisDT, *it2, *it3, *it1);

					bool leftend = false;
					bool rightend = false;
					bool moveleft;
					while (1)
					{
						if (it3 == cityChain1.begin())
						{
							moveleft = false;
							leftend = true;
						}
						++it2;
						if (it2 == cityChain2.end())
						{
							moveleft = true;
							rightend = true;
						}
						--it2;

						if (leftend && rightend)
							break;

						//cout << "it2 = " << it2->index << ", it3 = " << it3->index << endl;
						//cout << "leftend = " << leftend << ", rightend = " << rightend << ", moveleft = " << moveleft << ")" << endl;

						if (!leftend && !rightend) // both directions are available
						{
							--it3;
							++it2;

							if (it3->ycord < it2->ycord) // left is lower than right, connect from left
							{
								moveleft = true;
								--it2; // right back to original place
							}
							else // if ((it3->ycord >= it2->ycord)) // right is lower than left, connect from right
							{
								moveleft = false;
								++it3; // left back to original place
							}

							if (moveleft)
							{
								it1 = it3;
								++it1;
							}
							else
							{
								it1 = it2;
								--it1;
							}
						}
						else
						{
							if (moveleft)
							{
								--it3;
								it1 = it3;
								++it1;
							}
							else
							{
								++it2;
								it1 = it2;
								--it1;
							}
						}

						if (!LowerTriangle(*it3, *it1, *it2)) // cannot form triangle anymore
							break;

						//cout << "forming triangle (" << it2->index << ", " << it3->index << ", " << it1->index << ")" << endl;

						FormTriangle(thisDT, *it2, *it3, *it1);
					}
				}
			}
		}
	}
}

void FillBasinRight(delaunayTriangulation *thisDT, city & c, list<city>::iterator left)
{
	// Check and fill the basin
	list<city>::iterator leftFollower = left;

	if (leftFollower == thisDT->advFront.begin()) // no basin
		return;

	//if (leftFollower != thisDT->advFront.begin()) // left is not the first element in the advance front
	//{
	//	--leftFollower; // move backward
		// the angle between c and leftFollower is smaller than 3pi/4 under the current DT (need normalization)
		double xNormCoef = 1.0/(thisDT->rightmost-thisDT->leftmost);
		double yNormCoef = 1.0/(thisDT->top-thisDT->bottom);

		if ((c.ycord-leftFollower->ycord)*yNormCoef > (c.xcord-leftFollower->xcord)*xNormCoef)
		{
			//cout << "start filling from right: c = " << c.index << endl;

			list<city>::iterator basinBottom = leftFollower;
			int bottomy = basinBottom->ycord;
			--basinBottom;
			while (basinBottom != thisDT->advFront.begin() && basinBottom->ycord < bottomy)
			{
				bottomy = basinBottom->ycord;
				--basinBottom;
			}
			++basinBottom; // make sure basin is larger than begin(), leave space to leftBorder
			++leftFollower;
			list<city> cityChain2(basinBottom, leftFollower);
			--leftFollower;

			if (basinBottom != leftFollower)
			{
				list<city>::iterator leftBorder = basinBottom;
				--leftBorder;
				while ((leftBorder != thisDT->advFront.begin()) &&
					((leftBorder->ycord > bottomy) || (leftBorder->ycord == bottomy && bottomy < leftFollower->ycord)))
				{
					bottomy = leftBorder->ycord;
					--leftBorder;
				}
				
				if ((leftBorder == thisDT->advFront.begin()) &&
					((leftBorder->ycord > bottomy) || (leftBorder->ycord == bottomy && bottomy < leftFollower->ycord)))
				{
					// don't do anything
				}
				else
				{
					++leftBorder; // the current point is worse
				}

				++basinBottom;
				list<city> cityChain1(leftBorder, basinBottom);

				if (cityChain1.size() >= 2) // leftBorder != basinBottom
				{
					//if (c.index == 958)
					//{
					//	cout << c.index << endl;
					//	cout << "chain1" << endl;
					//	PrintCityList(cityChain1);
					//	cout << "chain2" << endl;
					//	PrintCityList(cityChain2);
					//	cout << "advance front" << endl;
					//	PrintCityList(thisDT->advFront);
					//	system("PAUSE");
					//}

					/*for (list<city>::iterator it = cityChain1.begin(); it != cityChain1.end(); ++it)
					{
						list<city>::iterator tmpit = it;
						++tmpit;
						if (tmpit == cityChain1.end())
							break;

						list<dtEdge>::iterator printEdge = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *it, *tmpit);
						PrintDTEdge(*printEdge);
					}
					for (list<city>::iterator it = cityChain2.begin(); it != cityChain2.end(); ++it)
					{
						list<city>::iterator tmpit = it;
						++tmpit;
						if (tmpit == cityChain2.end())
							break;

						list<dtEdge>::iterator printEdge = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *it, *tmpit);
						PrintDTEdge(*printEdge);
					}
					system("PAUSE");*/

					list<city>::iterator it1 = cityChain2.begin();
					list<city>::iterator it2 = it1;
					++it2;
					list<city>::iterator it3 = cityChain1.end();
					--it3;
					--it3;

					//if (c.index == 958)
					//	cout << "forming triangle (" << it2->index << ", " << it3->index << ", " << it1->index << ")" << endl;

					FormTriangle(thisDT, *it2, *it3, *it1);

					bool leftend = false;
					bool rightend = false;
					bool moveleft;
					while (1)
					{
						if (it3 == cityChain1.begin())
						{
							moveleft = false;
							leftend = true;
						}
						++it2;
						if (it2 == cityChain2.end())
						{
							moveleft = true;
							rightend = true;
						}
						--it2;

						if (leftend && rightend)
							break;

						//cout << "it2 = " << it2->index << ", it3 = " << it3->index << endl;
						//cout << "leftend = " << leftend << ", rightend = " << rightend << ", moveleft = " << moveleft << ")" << endl;

						if (!leftend && !rightend) // both directions are available
						{
							--it3;
							++it2;

							if (it3->ycord < it2->ycord) // left is lower than right, connect from left
							{
								moveleft = true;
								--it2; // right back to original place
							}
							else // if ((it3->ycord >= it2->ycord)) // right is lower than left, connect from right
							{
								moveleft = false;
								++it3; // left back to original place
							}

							if (moveleft)
							{
								it1 = it3;
								++it1;
							}
							else
							{
								it1 = it2;
								--it1;
							}
						}
						else
						{
							if (moveleft)
							{
								--it3;
								it1 = it3;
								++it1;
							}
							else
							{
								++it2;
								it1 = it2;
								--it1;
							}
						}

						if (!LowerTriangle(*it3, *it1, *it2)) // cannot form triangle anymore
							break;

						//if (c.index == 958)
						//	cout << "forming triangle (" << it2->index << ", " << it3->index << ", " << it1->index << ")" << endl;

						FormTriangle(thisDT, *it2, *it3, *it1);
					}

					//cout << "finish filling" << endl;
				}
			}
		//}
	}
}

void FormTriangle(delaunayTriangulation *thisDT, city & c1, city & c2, city & c3)
{
	// add the new edge (c1,c2), with one triangle and two associate edges (c1,c3) and (c2,c3)
	dtEdge newEdge;
	newEdge.v1 = c1;
	newEdge.v2 = c2;
	//newEdge.dtNeighborList.push_back(c3);
	newEdge.numTriangles = 1;
	newEdge.triv1 = c3;
	newEdge.assoEdge11 = FindEdgeBackward(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c1, c3); // (c1,c3)
	newEdge.assoEdge12 = FindEdgeBackward(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c2, c3); // (c2,c3)

	// add the new edge in the edge list
	thisDT->dtEdgeList.push_back(newEdge);

	// remove c3 from the advance front
	list<city>::iterator it = FindCity(thisDT->advFront.begin(), thisDT->advFront.end(), c3);
	it = thisDT->advFront.erase(it);

	// add the associate edges (c1,c2) and (c2,c3) to (c1,c3), whose iterator is newEdge.assoEdge11
	//newEdge.assoEdge11->dtNeighborList.push_back(c2);
	newEdge.assoEdge11->numTriangles = 2;
	newEdge.assoEdge11->triv2 = c2;
	newEdge.assoEdge11->assoEdge21 = thisDT->dtEdgeList.end();
	--newEdge.assoEdge11->assoEdge21; // (c1,c2) is the last element
	newEdge.assoEdge11->assoEdge22 = newEdge.assoEdge12; // (c2,c3)

	// add the associate edges (c1,c2) and (c1,c3) to (c2,c3), whose iterator is newEdge.assoEdge12
	//newEdge.assoEdge12->dtNeighborList.push_back(c1);
	newEdge.assoEdge12->numTriangles = 2;
	newEdge.assoEdge12->triv2 = c1;
	newEdge.assoEdge12->assoEdge21 = newEdge.assoEdge11->assoEdge21; // (c1,c2)
	newEdge.assoEdge12->assoEdge22 = newEdge.assoEdge11; // (c1,c3)

	//// find the existing edges of the triangle
	//list<dtEdge>::iterator edgePtr1 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c1, c3);
	//edgePtr1->dtNeighborList.push_back(c2);
	//list<dtEdge>::iterator edgePtr2 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c2, c3);
	//edgePtr2->dtNeighborList.push_back(c1);
	
	// check from (c1,c3)
	DTEmptyCircle(thisDT, newEdge.assoEdge11);

	if (newEdge.assoEdge12->v1.index == c2.index && newEdge.assoEdge12->v2.index == c3.index) // (c2,c3) is unchanged
		DTEmptyCircle(thisDT, newEdge.assoEdge12);

	/*cout << "after forming triangle" << endl;
	PrintDTEdgeList(thisDT->dtEdgeList);
	system("PAUSE");*/
}

void UpdateLeftLowerHull(delaunayTriangulation *thisDT, city & c)
{
	list<city>::iterator left = thisDT->lowerHull.begin();
	list<city>::iterator right = left;
	++right;

	int count = 0;
	while (UpperTriangle(c, *left, *right))
	{
		count ++;
		//if (c.index == 275)
		//{
		//	cout << c.index << " " << left->index << " " << right->index << endl;
		//	cout << "before empty circle " << c.index << ": " << endl;
		//	cout << "front" << endl;
		//	PrintCityList(thisDT->advFront);
		//	cout << "hull" << endl;
		//	PrintCityList(thisDT->lowerHull);
		//	cout << "edge list" << endl;
		//	PrintDTEdgeList(thisDT->dtEdgeList);
		//	system("PAUSE");
		//}

		// form a triangle (c,left,right) by adding edge (c,right)
		// the new edge (c,right), with one triangle and two associate edges (c,left) and (left,right)
		dtEdge newEdge;
		newEdge.v1 = c;
		newEdge.v2 = *right;
		//newEdge.dtNeighborList.push_back(*left);
		newEdge.numTriangles = 1;
		newEdge.triv1 = *left;
		newEdge.assoEdge11 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right); // the iterator of (left,right)
		newEdge.assoEdge12 = thisDT->dtEdgeList.end();
		--newEdge.assoEdge12;
		if (count == 1 && newEdge.assoEdge12->numTriangles == 1) // this one is (c,right), (c,left) is the previous one
			--newEdge.assoEdge12;
		thisDT->dtEdgeList.push_back(newEdge);

		// add (c,right) and (left,right) to the associate edges of (c,left), whose iterator is newEdge.assoEdge12
		//newEdge.assoEdge12->dtNeighborList.push_back(*right);
		if (newEdge.assoEdge12->numTriangles == 0) // the edge is added with no triangle (only happen when the first edge added)
		{
			newEdge.assoEdge12->numTriangles = 1;
			newEdge.assoEdge12->triv1 = *right;
			newEdge.assoEdge12->assoEdge11 = newEdge.assoEdge11; // (left,right)
			newEdge.assoEdge12->assoEdge12 = thisDT->dtEdgeList.end();
			--newEdge.assoEdge12->assoEdge12; // (c,right) is the last element
		}
		else
		{
			newEdge.assoEdge12->numTriangles = 2;
			newEdge.assoEdge12->triv2 = *right;
			newEdge.assoEdge12->assoEdge21 = newEdge.assoEdge11; // (left,right)
			newEdge.assoEdge12->assoEdge22 = thisDT->dtEdgeList.end();
			--newEdge.assoEdge12->assoEdge22; // (c,right) is the last element
		}

		// add (c,left) and (c,right) to the associate edges of (left,right), whose iterator is newEdge.assoEdge11
		//newEdge.assoEdge11->dtNeighborList.push_back(c);
		newEdge.assoEdge11->numTriangles = 2;
		newEdge.assoEdge11->triv2 = c;
		newEdge.assoEdge11->assoEdge21 = newEdge.assoEdge12; // (c,left)
		newEdge.assoEdge11->assoEdge22 = thisDT->dtEdgeList.end();
		--newEdge.assoEdge11->assoEdge22; // (c,right) is the last element

		//// find the existing edges of the triangle
		//list<dtEdge>::iterator edgePtr1 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right);
		//edgePtr1->dtNeighborList.push_back(c);
		//list<dtEdge>::iterator edgePtr2 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c, *left);
		//edgePtr2->dtNeighborList.push_back(*right);

		//if (c.index == 275)
		//{
		//	cout << "before empty circle " << c.index << ": " << endl;
		//	cout << "front" << endl;
		//	PrintCityList(thisDT->advFront);
		//	cout << "hull" << endl;
		//	PrintCityList(thisDT->lowerHull);
		//	cout << "edge list" << endl;
		//	PrintDTEdgeList(thisDT->dtEdgeList);
		//	system("PAUSE");
		//}

		// check the empty circle starting from (left,right)
		DTEmptyCircle(thisDT, newEdge.assoEdge11);
		if (newEdge.assoEdge12->numTriangles == 2 && newEdge.assoEdge12->v1.index == c.index && newEdge.assoEdge12->v2.index == left->index) // (c,left) is unchanged
			DTEmptyCircle(thisDT, newEdge.assoEdge12); // check from (c,left)

		// move forward
		++right;
		if (right == thisDT->lowerHull.end())
			break;
		++left;
	}

	// update lower convex hull
	thisDT->lowerHull.erase(thisDT->lowerHull.begin(), left);
	thisDT->lowerHull.push_front(c);
}

void UpdateRightLowerHull(delaunayTriangulation *thisDT, city & c)
{
	list<city>::iterator right = thisDT->lowerHull.end();
	--right;
	list<city>::iterator left = right;
	--left;

	while (UpperTriangle(*left, *right, c))
	{
		//cout << c.index << " " << left->index << " " << right->index << endl;

		// form a triangle (c,left,right) by adding edge (c,left)
		// the new edge (c,left), with one triangle and two associate edges (c,right) and (left,right)
		dtEdge newEdge;
		newEdge.v1 = c;
		newEdge.v2 = *left;
		newEdge.numTriangles = 1;
		newEdge.triv1 = *right;
		newEdge.assoEdge11 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right); // the iterator of (left,right)
		newEdge.assoEdge12 = thisDT->dtEdgeList.end();
		--newEdge.assoEdge12; // (c,right) is the previous added edge
		thisDT->dtEdgeList.push_back(newEdge);
		//newEdge.dtNeighborList.push_back(*right);
		

		// add (c,left) and (left,right) to the associate edges of (c,right), whose iterator is newEdge.assoEdge12
		//newEdge.assoEdge12->dtNeighborList.push_back(*right);
		if (newEdge.assoEdge12->numTriangles == 0) // the edge is added with no triangle (only happen when the first edge added)
		{
			newEdge.assoEdge12->numTriangles = 1;
			newEdge.assoEdge12->triv1 = *left;
			newEdge.assoEdge12->assoEdge11 = newEdge.assoEdge11; // (left,right)
			newEdge.assoEdge12->assoEdge12 = thisDT->dtEdgeList.end();
			--newEdge.assoEdge12->assoEdge12; // (c,left) is the last element
		}
		else
		{
			newEdge.assoEdge12->numTriangles = 2;
			newEdge.assoEdge12->triv2 = *left;
			newEdge.assoEdge12->assoEdge21 = newEdge.assoEdge11; // (left,right)
			newEdge.assoEdge12->assoEdge22 = thisDT->dtEdgeList.end();
			--newEdge.assoEdge12->assoEdge22; // (c,left) is the last element
		}

		// add (c,left) and (c,right) to the associate edges of (left,right), whose iterator is newEdge.assoEdge11
		//newEdge.assoEdge11->dtNeighborList.push_back(c);
		newEdge.assoEdge11->numTriangles = 2;
		newEdge.assoEdge11->triv2 = c;
		newEdge.assoEdge11->assoEdge21 = thisDT->dtEdgeList.end();
		--newEdge.assoEdge11->assoEdge21; // (c,left) is the last element
		newEdge.assoEdge11->assoEdge22 = newEdge.assoEdge12; // (c,right);

		//// find the existing edges of the triangle
		//list<dtEdge>::iterator edgePtr1 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), *left, *right);
		//edgePtr1->dtNeighborList.push_back(c);
		//list<dtEdge>::iterator edgePtr2 = FindEdge(thisDT->dtEdgeList.begin(), thisDT->dtEdgeList.end(), c, *right);
		//edgePtr2->dtNeighborList.push_back(*left);

		// check the empty circle starting from (left,right)
		DTEmptyCircle(thisDT, newEdge.assoEdge11);
		if (newEdge.assoEdge12->numTriangles == 2 && newEdge.assoEdge12->v1.index == c.index && newEdge.assoEdge12->v2.index == right->index) // (c,right) is unchanged
			DTEmptyCircle(thisDT, newEdge.assoEdge12); // check from (c,left)

		--right;

		if (left == thisDT->lowerHull.begin())
		{
			break;
		}

		// move backward
		--left;
	}

	// update lower convex hull
	++right;
	thisDT->lowerHull.erase(right, thisDT->lowerHull.end());
	thisDT->lowerHull.push_back(c);
}

bool LowerTriangle(city & c1, city & c2, city & c3)
{
	double dy1 = (double)(c1.ycord-c2.ycord);
	double dx1 = (double)(c2.xcord-c1.xcord);
	double dy2 = (double)(c2.ycord-c3.ycord);
	double dx2 = (double)(c3.xcord-c2.xcord);

	double leftside = dy1*dx2;
	double rightside = dy2*dx1;

	/*if (c1.index == 90 && c2.index == 133 && c3.index == 76)
	{
		cout << c1.index << " " << c2.index << " " << c3.index << endl;
		cout << dy1 << " " << dx1 << " " << dy2 << " " << dx2 << " " << leftside << " " << rightside << endl;
		system("PAUSE");
	}*/

	return (leftside > rightside);
}

bool UpperTriangle(city & c1, city & c2, city & c3)
{
	double dy1 = (double)(c1.ycord-c2.ycord);
	double dx1 = (double)(c2.xcord-c1.xcord);
	double dy2 = (double)(c2.ycord-c3.ycord);
	double dx2 = (double)(c3.xcord-c2.xcord);

	double leftside = dy1*dx2;
	double rightside = dy2*dx1;

	/*if (c1.index == 90 && c2.index == 133 && c3.index == 76)
	{
		cout << c1.index << " " << c2.index << " " << c3.index << endl;
		cout << dy1 << " " << dx1 << " " << dy2 << " " << dx2 << " " << leftside << " " << rightside << endl;
		system("PAUSE");
	}*/

	return (leftside < rightside);
}

void Finalize(delaunayTriangulation *thisDT)
{
	bool improved = true;
	list<city>::iterator it1, it2, it3;

	while (improved)
	{
		improved = false;

		//initialize it1, it2 and it3
		it1 = thisDT->advFront.begin();
		it2 = it1;
		++it2;
		it3 = it2;
		++it3;

		while (it3 != thisDT->advFront.end())
		{
			//cout << it1->index << " " << it2->index << " " << it3->index << endl;
			//cout << "advance front" << endl;
			//PrintCityList(thisDT->advFront);

			if (!LowerTriangle(*it1, *it2, *it3)) // move forward
			{
				//cout << "move forward" << endl;

				++it1;
				++it2;
				++it3;
			}
			else // form a triangle (it1, it3, it2)
			{
				//cout << "form triangle" << endl;

				improved = true;
				FormTriangle(thisDT, *it1, *it3, *it2); // this already removes the element of it2, and it2 has lost
				it2 = it3;
				++it3; // restore the position of it3
			}
		}
	}
}

list<city>::iterator GetRightForward(list<city>::iterator first, list<city>::iterator last, city & c)
{
	while (first != last)
	{
		++first;
		if (c.xcord < first->xcord)
		{
			break;
		}
		else if (c.xcord == first->xcord)
		{
			list<city>::iterator prefirst = first;
			--prefirst;

			if (c.xcord > prefirst->xcord)
				break;
		}
	}
	if (first == last)
	{
		--first; // set first to the last element
	}

	return first;
}

list<city>::iterator GetLeftBackward(list<city>::iterator first, list<city>::iterator last, city & c)
{
	while (first != last)
	{
		--last;

		if (c.xcord > last->xcord)
		{
			break;
		}
	}

	return last;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintCityList(list<city> & cityList) 
{
	for(list<city>::iterator i = cityList.begin(); i != cityList.end(); ++i)
	{
		cout << i->index << " ";
	}
	cout << endl;
}

void PrintCityVector(vector<city> & cityVec)
{
	for(vector<city>::iterator it = cityVec.begin(); it != cityVec.end(); ++it)
	{
		cout << it->index << " ";
	}
	cout << endl;
}

void PrintDTEdge(dtEdge & dtEdge)
{
	cout << "(" << dtEdge.v1.index << ", " << dtEdge.v2.index << "), - ";
	if (dtEdge.numTriangles == 0)
	{
		return;
	}
	else if (dtEdge.numTriangles == 1)
	{
		cout << dtEdge.triv1.index << ": (" << dtEdge.assoEdge11->v1.index << ", " << dtEdge.assoEdge11->v2.index 
			<< "), (" << dtEdge.assoEdge12->v1.index << ", " << dtEdge.assoEdge12->v2.index << ")" << endl;
	}
	else // two triangles and four associate edges
	{
		cout << dtEdge.triv1.index << ": (" << dtEdge.assoEdge11->v1.index << ", " << dtEdge.assoEdge11->v2.index 
			<< "), (" << dtEdge.assoEdge12->v1.index << ", " << dtEdge.assoEdge12->v2.index
			<< "), " << dtEdge.triv2.index << ": (" << dtEdge.assoEdge21->v1.index << ", " << dtEdge.assoEdge21->v2.index 
			<< "), (" << dtEdge.assoEdge22->v1.index << ", " << dtEdge.assoEdge22->v2.index << ")" << endl;
	}
}

void PrintDTEdgeList(list<dtEdge> & dtEdgeList)
{
	for(list<dtEdge>::iterator i = dtEdgeList.begin(); i != dtEdgeList.end(); ++i)
	{
		PrintDTEdge(*i);
	}
}


bool TwoTriValid(list<dtEdge>::iterator edgePtr)
{
	if (edgePtr->numTriangles == 0)
		return true;

	// check the validity of the edge
	vector<int> nodeSet;
	nodeSet.push_back(edgePtr->v1.index);
	nodeSet.push_back(edgePtr->v2.index);
	nodeSet.push_back(edgePtr->triv1.index);
	nodeSet.push_back(edgePtr->triv2.index);
	vector<int> edgeNodeSet;

	edgeNodeSet.push_back(edgePtr->assoEdge11->v1.index);
	edgeNodeSet.push_back(edgePtr->assoEdge11->v2.index);
	edgeNodeSet.push_back(edgePtr->assoEdge12->v1.index);
	edgeNodeSet.push_back(edgePtr->assoEdge12->v2.index);
	if (edgePtr->numTriangles == 2)
	{
		edgeNodeSet.push_back(edgePtr->assoEdge21->v1.index);
		edgeNodeSet.push_back(edgePtr->assoEdge21->v2.index);
		edgeNodeSet.push_back(edgePtr->assoEdge22->v1.index);
		edgeNodeSet.push_back(edgePtr->assoEdge22->v2.index);
	}

	bool valid = true;
	for (int i = 0; i < edgeNodeSet.size(); i++)
	{
		valid = false;
		for (int j = 0; j < nodeSet.size(); j++)
		{
			if (nodeSet[j] == edgeNodeSet[i])
			{
				valid = true;
				break;
			}
		}
	}
	
	return valid;
}