///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// The algorithm to obtain the Delaunay Triangulation given a set of 2D points and their cordinates.
// The implementation is based on the following paper:
// B. Zalik, "An efficient sweep-line Delaunay triangulation algorithm", Computer-Aided Design,
// vol. 37, pp. 1027-1038, 2005.
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef DELAUNAY2D_H
#define DELAUNAY2D_H

using namespace std;
#include <iostream>
#include <fstream>
#include <cstring>
#include <iterator>
#include <algorithm> // for sort
#include <vector>
#include <list>
#include <cstdlib>
#include <time.h>

#include "problem.h"
#include "city.h"

typedef struct dtEdge
{
	city v1; // first node
	city v2; // second node
	//list<city> dtNeighborList; // the neighboring cities (in the same Delaunay triangle) of this edge
	int numTriangles; // the number of triangles associate to this edge
	city triv1; // the other vertex of the first triangle
	city triv2; // the other vertex of the second triangle
	list<dtEdge>::iterator assoEdge11; // the first associated edge of triangle 1
	list<dtEdge>::iterator assoEdge12; // the second associated edge of triangle 1
	list<dtEdge>::iterator assoEdge21; // the first associated edge of triangle 2
	list<dtEdge>::iterator assoEdge22; // the second associated edge of triangle 2
	int length;
} dtEdge;

typedef struct delaunayTriangulation
{
	list<dtEdge> dtEdgeList; // the list of edges
	int leftmost; // the leftmost cordinate
	int rightmost; // the rightmost cordinate
	int bottom; // the bottom cordinate (the ycord of the first city added)
	int top; // the top cordinate (the ycord of the last city added)
	list<city> lowerHull; // the lower convex hull, with x cordinate from small to large
	list<city> advFront; // the advance front, with x cordinate from small to large
} delaunayTriangulation;

// first y smaller, and then x smaller
struct yxSmaller
{
    inline bool operator() (const city& struct1, const city& struct2)
    {
		return ((struct1.ycord < struct2.ycord) || ((struct1.ycord == struct2.ycord) && (struct1.xcord < struct2.xcord)));
    }
};

// first x smaller, and then y smaller
struct xySmaller
{
    inline bool operator() (const city& struct1, const city& struct2)
    {
		return ((struct1.xcord < struct2.xcord) || ((struct1.xcord == struct2.xcord) && (struct1.ycord < struct2.ycord)));
    }
};

// get the Delaunay Triangulation
void GetDelaunayTriangulation(delaunayTriangulation *thisDT, problem *thisProb);

// initialize the Delaunay Triangulation
void InitDelaunayTriangulation(delaunayTriangulation *thisDT, vector<city> *citySet, vector<city>::size_type &initDTSize);

// insert a city in the current Delaunay triangulation
list<city>::iterator InsertDelaunayTriangulation(delaunayTriangulation *thisDT, city & c, list<city>::iterator currFrontPtr);

// check whether the city set is collinear (on the same line)
bool Collinear(vector<city> *citySet);
bool Collinear(list<city> *citySet);
bool Collinear(city &c1, city & c2, city & c3);

// find the iterator of a city
list<city>::iterator FindCity(list<city>::iterator first, list<city>::iterator last, city & c);

// find the iterator of the edge (c1,c2)
list<dtEdge>::iterator FindEdge(list<dtEdge>::iterator first, list<dtEdge>::iterator last, city & c1, city & c2);
list<dtEdge>::iterator FindEdgeIndex(list<dtEdge>::iterator first, list<dtEdge>::iterator last, int cid1, int cid2);

// find the iterator of the edge (c1,c2) from backward
list<dtEdge>::iterator FindEdgeBackward(list<dtEdge>::iterator first, list<dtEdge>::iterator last, city & c1, city & c2);

// check the empty circle property for the Delaunay Triangulation, starting from an edge, and revise the Delaunay Triangulation accordingly
void DTEmptyCircle(delaunayTriangulation *thisDT, list<dtEdge>::iterator startEdgePtr);

// check if the edge (pointer in the Delaunay Triangulation satisfies the empty circle property (all the neighbors are outside the others' circumstance)
bool EdgeEmptyCircle(list<dtEdge>::iterator edgePtr);

// fill the basin from left
void FillBasinLeft(delaunayTriangulation *thisDT, city & c, list<city>::iterator right);

// fill the basin from right
void FillBasinRight(delaunayTriangulation *thisDT, city & c, list<city>::iterator left);

// form a new triangle by connecting c1 and c2, along with the existing c3
void FormTriangle(delaunayTriangulation *thisDT, city & c1, city & c2, city & c3);

// update the lower convex hull from left
void UpdateLeftLowerHull(delaunayTriangulation *thisDT, city & c);

// update the lower convex hull from right
void UpdateRightLowerHull(delaunayTriangulation *thisDT, city & c);

// finalize the triangulation by filling the concave advance front
void Finalize(delaunayTriangulation *thisDT);

// whether the triangle (c1,c2,c3) is lower part, given c1.x <= c2.x <= c3.x, and they are not collinear
bool LowerTriangle(city & c1, city & c2, city & c3);

// whether the triangle (c1,c2,c3) is upper part, given c1.x <= c2.x <= c3.x, and they are not collinear
bool UpperTriangle(city & c1, city & c2, city & c3);

// get the right with forward search
list<city>::iterator GetRightForward(list<city>::iterator first, list<city>::iterator last, city & c);

// get the left with backward search
list<city>::iterator GetLeftBackward(list<city>::iterator first, list<city>::iterator last, city & c);

////////////////////////////////////////////////////////////////////////

// print the city list
void PrintCityList(list<city> & cityList);
void PrintCityVector(vector<city> & cityVec);

// print the dt edge
void PrintDTEdge(dtEdge & dtEdge);

// print the dt edge list
void PrintDTEdgeList(list<dtEdge> & dtEdgeList);


bool TwoTriValid(list<dtEdge>::iterator edgePtr);

#endif