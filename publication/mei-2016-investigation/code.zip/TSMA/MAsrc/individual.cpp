
#include "individual.h"

void IndiEvaluate(individual *indi, problem *thisProb)
{
	// Get cityProfit and cityWeight
	//if (indi->cityProfit.size() != thisProb->numCities+1) // not initialized yet
	//{
	//	indi->cityProfit.resize(thisProb->numCities+1);
	//}
	//if (indi->cityWeight.size() != thisProb->numCities+1)
	//{
	//	indi->cityWeight.resize(thisProb->numCities+1);
	//}

	indi->cityProfit.assign(thisProb->numCities+1, 0);
	indi->cityWeight.assign(thisProb->numCities+1, 0);
	indi->cityBackDist.assign(thisProb->numCities+1, 0);
	indi->cityNextDist.assign(thisProb->numCities+1, 0);

	for (int i = 1; i != indi->pickPlan.size(); i++)
	{
		if (indi->pickPlan[i] > 0) // pick the item
		{
			int tmpCity = indi->pickPlan[i];
			indi->cityProfit[tmpCity] += thisProb->items[i].profit;
			indi->cityWeight[tmpCity] += thisProb->items[i].weight;
		}
	}

	// calculate the distance from each city to its next city in the tour
	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);

	// calculate the distance from each city back to the starting city
	long long int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	//system("PAUSE");

	// get everything through the tour
	indi->itemProfit = 0;
	indi->itemWeight = 0;
	indi->tourLength = 0;
	indi->tourTime = 0;
	long long int currWeight = 0;
	double currSpeed = thisProb->maxSpeed;
	for (int i = 0; i != indi->tour.size()-1; i++)
	{
		double tmpTime = (1.0*indi->cityNextDist[indi->tour[i]])/currSpeed;
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
		indi->tourTime += tmpTime;

		// update profit, weight and speed
		indi->itemProfit += indi->cityProfit[indi->tour[i+1]];
		indi->itemWeight += indi->cityWeight[indi->tour[i+1]];
		currSpeed = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*(1.0*indi->itemWeight)/thisProb->capacity;
		//cout << indi->tour[i] << " " << indi->tour[i+1] << " " << tmpDist << " " << currSpeed << " " << indi->tourLength << " " << indi->tourTime << endl;
	}
	// last step: return to the starting city
	double tmpTime = (1.0*indi->cityNextDist[indi->tour.back()])/currSpeed;
	indi->tourLength += indi->cityNextDist[indi->tour.back()];
	indi->tourTime += tmpTime;

	indi->vioWeight = 0;
	if (indi->itemWeight > thisProb->capacity)
		indi->vioWeight = indi->itemWeight-thisProb->capacity;

	indi->profit = indi->itemProfit-thisProb->rent*indi->tourTime;

	//cout << indi->tourLength << " " << indi->tourTime << " " << indi->itemProfit << " " << indi->profit << endl;
	//system("PAUSE");

	//update_best_fit(indi->profit); // update the best fitness vector
}


// only update tourTime and profit
void IndiReEvaluate(individual *indi, problem *thisProb)
{
	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// get everything through the tour
	//indi->itemProfit = 0;
	//indi->itemWeight = 0;
	//indi->tourLength = 0;
	indi->tourTime = 0;
	long long int accuWeight = 0;
	double currSpeed = thisProb->maxSpeed;
	for (int i = 0; i != indi->tour.size()-1; i++)
	{
		indi->tourTime += (1.0*indi->cityNextDist[indi->tour[i]])/currSpeed;
		//indi->tourLength += indi->cityNextDist[indi->tour[i]];

		if (indi->cityWeight[indi->tour[i+1]] == 0)
			continue;

		// update speed
		//indi->itemProfit += indi->cityProfit[indi->tour[i+1]];
		//indi->itemWeight += indi->cityWeight[indi->tour[i+1]];
		accuWeight += indi->cityWeight[indi->tour[i+1]];
		currSpeed = thisProb->maxSpeed-gamma*accuWeight;
		//cout << indi->tour[i] << " " << indi->tour[i+1] << " " << tmpDist << " " << currSpeed << " " << indi->tourLength << " " << indi->tourTime << endl;
	}
	// last step: return to the starting city
	indi->tourTime += (1.0*indi->cityNextDist[indi->tour.back()])/currSpeed;
	//indi->tourLength += indi->cityNextDist[indi->tour.back()];

	indi->vioWeight = 0;
	if (indi->itemWeight > thisProb->capacity)
		indi->vioWeight = indi->itemWeight-thisProb->capacity;

	indi->profit = indi->itemProfit-thisProb->rent*indi->tourTime;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//// update the best fitness vector
//void update_best_fit(vector<int> numFitEval, vector<double> bestFit, double newFit)
//{
//	if (numFitEval[0] == 0)
//	{
//		numFitEval[0] ++;
//		bestFit[0] ++;
//		numFitEval[numFitEval[0]] = 1;
//		bestFit[numFitEval[0]] = newFit;
//		return;
//	}
//
//	numFitEval[numFitEval[0]] ++;
//	if (newFit > bestFit[numFitEval[0]])
//	{
//		bestFit[numFitEval[0]] = newFit;
//	}
//}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// copy individual from source to target
void IndiCopy(individual *target, individual *source)
{
	target->tour = source->tour;
	target->posInTour = source->posInTour;
	target->pickPlan = source->pickPlan;
	target->cityProfit = source->cityProfit;
	target->cityWeight = source->cityWeight;
	target->cityBackDist = source->cityBackDist;
	target->cityNextDist = source->cityNextDist;
	target->itemProfit = source->itemProfit;
	target->itemWeight = source->itemWeight;
	target->vioWeight = source->vioWeight;
	target->tourLength = source->tourLength;
	target->tourTime = source->tourTime;
	target->profit = source->profit;
}

void GetPosInTour(individual *indi, problem *thisProb)
{
	indi->posInTour.resize(thisProb->numCities+1, 0); // resize, and set position of city 1 to 0
	for (vector<int>::size_type i = 1; i != indi->tour.size(); i++) // ignore tour[0] = city 1
	{
		indi->posInTour[indi->tour[i]] = (int)i;
	}
}


void PrintIntVec(vector<int> vec)
{
	for (vector<int>::iterator it = vec.begin(); it != vec.end(); ++it)
	{
		cout << *it << " ";
	}
	cout << endl;
}

void PrintIndi(individual *indi)
{
	cout << "tour" << endl;
	for (vector<int>::iterator it = indi->tour.begin(); it != indi->tour.end(); ++it)
	{
		cout << *it << " ";
	}
	cout << endl;
	cout << "pick plan" << endl;
	for (vector<int>::size_type i = 1; i != indi->pickPlan.size(); i++)
	{
		if (indi->pickPlan[i] > 0)
			cout << i << " ";
	}
	cout << endl;
	cout << "tourLength = " << indi->tourLength << ", value = " << indi->itemProfit << ", weight = " << indi->itemWeight << ", profit = " << indi->profit << endl;
}


bool ValidTour(individual *indi, problem *thisProb)
{
	vector<int> tmpTour(indi->tour);
	sort(tmpTour.begin(), tmpTour.end());

	for (int i = 0; i != tmpTour.size(); i++)
	{
		if (tmpTour[i] != i+1)
		{
			cout << i+1 << " is missing, and " << tmpTour[i] << " is duplicated" << endl;
			return false;
		}
	}

	return true;
}
