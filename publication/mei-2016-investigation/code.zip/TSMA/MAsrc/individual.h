#ifndef INDIVIDUAL_H
#define INDIVIDUAL_H

using namespace std;
#include <iostream>
#include <cstring>
#include <vector>

#include "parameters.h"
#include "problem.h"
#include "city.h"
#include "item.h"

typedef struct individual
{
	vector<int> tour; // a permutation of all the cities (1 is the starting city)
	vector<int> posInTour; // the position of each city in the tour (of course city 1 is in position 1
	vector<int> pickPlan; // the picking plan: the city that each item is picked
	vector<long long int> cityProfit; // the profit of the items picked by each city
	vector<long long int> cityWeight; // the weight of the items picked by each city
	vector<long long int> cityBackDist; // the distance of each city back to the starting city, for RepairPickPlan();
	vector<int> cityNextDist; // the distance of each city to its next city in the tour, for ReEvaluate();
	long long int itemProfit; // total profit of the items picked
	long long int itemWeight; // total weight of the items picked
	long long int vioWeight; // the violated weight
	long long int tourLength; // length of the tour
	long double tourTime; // the time of the tour
	long double profit; // the final profit (objective function)
} individual;

// Evaluate individual
void IndiEvaluate(individual *indi, problem *thisProb);

// Reevaluate individual after modification (cityProfit and cityWeight have been updated)
void IndiReEvaluate(individual *indi, problem *thisProb);

// Copy individual
void IndiCopy(individual *target, individual *source);

// Get the positions of each city in the tour according to the tour
void GetPosInTour(individual *indi, problem *thisProb);

// Sort population with fitness (profit) from best to worst
struct indiFitnessBetter
{
    inline bool operator() (const individual& struct1, const individual& struct2)
    {
		return (struct1.profit > struct2.profit);
    }
};
// Sort the population with tour length from best to worst
struct indiTourLengthBetter
{
    inline bool operator() (const individual& struct1, const individual& struct2)
    {
		return (struct1.tourLength < struct2.tourLength);
    }
};


// print int vector (the tour)
void PrintIntVec(vector<int> vec);

// print the individual
void PrintIndi(individual *indi);

// whether the tour of the individual is valid
bool ValidTour(individual *indi, problem *thisProb);

#endif
