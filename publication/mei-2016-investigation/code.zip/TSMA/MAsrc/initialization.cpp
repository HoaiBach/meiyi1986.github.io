
#include "initialization.h"

// get the Delaunay Triangulation neighbors

void GetDTNeighbors(problem *thisProb, delaunayTriangulation *thisDT)
{
	for (list<dtEdge>::iterator it = thisDT->dtEdgeList.begin(); it != thisDT->dtEdgeList.end(); ++it)
	{
		dtNeighbor tmpNeighbor;
		tmpNeighbor.index = it->v2.index;
		tmpNeighbor.dist = it->length;
		thisProb->cities[it->v1.index].dtNeighborList.push_back(tmpNeighbor);
		tmpNeighbor.index = it->v1.index;
		thisProb->cities[it->v2.index].dtNeighborList.push_back(tmpNeighbor);
	}

	// check for duplicate points
	for (vector<city>::iterator it = thisProb->cities.begin()+1; it != thisProb->cities.end(); ++it)
	{
		if (it->inDT == true)
			continue;

		// find the duplication
		for (vector<city>::iterator jt = thisProb->cities.begin()+1; jt != thisProb->cities.end(); ++jt)
		{
			if ((jt->xcord == it->xcord) && (jt->ycord == it->ycord) && (jt->inDT == true))
			{
				it->dtNeighborList.assign(jt->dtNeighborList.begin(), jt->dtNeighborList.end());
				dtNeighbor tmpNeighbor;
				tmpNeighbor.index = jt->index;
				tmpNeighbor.dist = 0;
				it->dtNeighborList.push_back(tmpNeighbor);
				tmpNeighbor.index = it->index;
				jt->dtNeighborList.push_back(tmpNeighbor);

				//cout << it->index << endl;
				//PrintDTNeighbors(*it);
				//cout << jt->index << endl;
				//PrintDTNeighbors(*jt);
			}
		}

		it->inDT = true;
	}

	// sort the neighbors of each city
	for (vector<city>::iterator it = thisProb->cities.begin()+1; it != thisProb->cities.end(); ++it)
	{
		sort(it->dtNeighborList.begin(), it->dtNeighborList.end(), distSmaller());

		//cout << it->index << ", number of neighbors = " << it->dtNeighborList.size() << endl;
		//PrintDTNeighbors(*it);
		//system("PAUSE");
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize a tour
void RandTour(individual *indi, problem *thisProb)
{
	indi->tour.resize(thisProb->numCities);
	for (int i = 1; i <= thisProb->numCities; i++)
	{
		indi->tour[i-1] = i;
	}

	random_shuffle(indi->tour.begin()+1, indi->tour.end());

	//RandPerm(indi->tour, thisProb->numCities-1); // randomly initialize the tour;

	//cout << thisProb->numCities << endl;
	//PrintIntVec(indi->tour);
	//system("PAUSE");

	//indi->tour.resize(thisProb->numCities);
	//for (int i = thisProb->numCities-1; i > 0; i--) // make city 1 to be starting city
	//{
	//	indi->tour[i+1] = indi->tour[i]+1;
	//}
	//indi->tour[0] = 1;

	GetPosInTour(indi, thisProb); // get the positions of the cities

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "tour position" << endl;
	//PrintIntVec(indi->posInTour);
	//system("PAUSE");

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize a tour based on DT neighbors
void RandDTNeighborTour(individual *indi, int k, problem *thisProb)
{
	int sum = 0;

	indi->tour.resize(thisProb->numCities);
	indi->tour[0] = 1; // city 1 is the starting city

	vector<int> candOrder(thisProb->numCities-1);
	for (int i = 0; i < thisProb->numCities-1; i++)
	{
		candOrder[i] = i+2;
	}
	random_shuffle(candOrder.begin(), candOrder.end());
	int currPtr = 0; // the current pointer of the candidate order list (all the previous cities are visited)

	vector<bool> inTour(thisProb->numCities+1, false); // whether each city is in the tour
	inTour[1] = true; // city 1 is already in the tour

	int backID = 0; // the id of the last element (back) in the tour, initially 0
	while (backID < thisProb->numCities-1)
	{
		// pick the next city
		// first randomly from its DT neighbors
		int currCity = indi->tour[backID];
		int nextCity;
		vector<int> unvisitedNeighborList;
		for (int i = 0; i < thisProb->cities[currCity].dtNeighborList.size(); i++)
		{
			if (!inTour[thisProb->cities[currCity].dtNeighborList[i].index])
			{
				unvisitedNeighborList.push_back(thisProb->cities[currCity].dtNeighborList[i].index);
			}
		}

		int ub = k;
		if (unvisitedNeighborList.size() < k)
			ub = unvisitedNeighborList.size();

		if (ub == 0) // no neighbor available, randomly pick an unvisited city outside
		{
			sum ++;
			while (inTour[candOrder[currPtr]])
			{
				currPtr ++;
			}

			nextCity = candOrder[currPtr];
			currPtr ++;
		}
		else
		{
			int r = RandChoose(0, ub-1);
			nextCity = unvisitedNeighborList[r];
		}

		// insert the next city to the back of the tour
		backID ++;
		indi->tour[backID] = nextCity;
		inTour[nextCity] = true;

		//cout << "curr = " << currCity << ", next = " << nextCity << endl;
	}

	cout << "num of random = " << sum << endl;

	//cout << thisProb->numCities << endl;
	//PrintIntVec(indi->tour);
	//system("PAUSE");

	//indi->tour.resize(thisProb->numCities);
	//for (int i = thisProb->numCities-1; i > 0; i--) // make city 1 to be starting city
	//{
	//	indi->tour[i+1] = indi->tour[i]+1;
	//}
	//indi->tour[0] = 1;

	GetPosInTour(indi, thisProb); // get the positions of the cities

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "tour position" << endl;
	//PrintIntVec(indi->posInTour);
	//system("PAUSE");

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
}

void MSTTour(individual *indi, minSpanTree *thisMST, problem *thisProb)
{
	indi->tour.clear();
	vector<bool> inTour(thisProb->numCities+1, false); // whether each city is in the tour, initially all false

	//cout << "start DFS" << endl;

	MSTTourDFS(indi, 1, inTour, thisMST, thisProb);

	//cout << thisProb->numCities << endl;
	//PrintIntVec(indi->tour);
	//system("PAUSE");

	GetPosInTour(indi, thisProb); // get the positions of the cities

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "tour position" << endl;
	//PrintIntVec(indi->posInTour);
	//system("PAUSE");

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
}

void MSTTourDFS(individual *indi, int currID, vector<bool> & inTour, minSpanTree *thisMST, problem *thisProb)
{
	vector<int> unvisitedNeighborList;
	for (vector<dtNeighbor>::iterator it = thisMST->adjList[currID].dtNeighborList.begin(); it != thisMST->adjList[currID].dtNeighborList.end(); ++it)
	{
		if (!inTour[it->index])
			unvisitedNeighborList.push_back(it->index);
	}

	indi->tour.push_back(currID); // add this city into the tour
	inTour[currID] = true;

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "unvisit neighbors" << endl;
	//PrintIntVec(unvisitedNeighborList);

	if (unvisitedNeighborList.size() == 0) // there is no unvisited neighbor, back to the previous point
		return;

	random_shuffle(unvisitedNeighborList.begin(), unvisitedNeighborList.end());

	//cout << "unvisit neighbors" << endl;
	//PrintIntVec(unvisitedNeighborList);
	//system("pause");

	for (int i = 0; i < unvisitedNeighborList.size(); i++)
	{
		MSTTourDFS(indi, unvisitedNeighborList[i], inTour, thisMST, thisProb);
	}
}



void RandChristofidesTour(individual *indi, minSpanTree *thisMST, problem *thisProb)
{
	minSpanTree EulerGraph(*thisMST);

	// find the odd cities in the MST
	vector<int> oddCityList;
	for (vector<city>::iterator it = thisMST->adjList.begin()+1; it != thisMST->adjList.end(); ++it)
	{
		if (it->dtNeighborList.size()%2 == 1)
			oddCityList.push_back(it->index);
	}

	// randomly shuffle oddCityList
	random_shuffle(oddCityList.begin(), oddCityList.end());

	//PrintIntVec(oddCityList);
	//system("pause");

	clock_t t1 = clock();
	// find minimal matching based on greeding algorithm
	vector<bool> inMatching(oddCityList.size(), false); // whether each odd city is in matching, initially all false
	for (int i = 0; i < oddCityList.size()-1; i++)
	{
		if (inMatching[i])
			continue;

		// find the matching ID
		int minDist = INF;
		int matchingID;
		for (int j = i+1; j < oddCityList.size(); j++)
		{
			if (inMatching[j])
				continue;

			int tmpDist = CeilEuclDist(thisProb->cities[oddCityList[i]], thisProb->cities[oddCityList[j]]);
			if (tmpDist < minDist)
			{
				minDist = tmpDist;
				matchingID = j;
			}
		}

		//cout << "match " << i << " and " << matchingID << endl;

		// add the edge into graph
		dtNeighbor tmpNeighbor;
		tmpNeighbor.index = oddCityList[matchingID];
		tmpNeighbor.dist = minDist;
		EulerGraph.adjList[oddCityList[i]].dtNeighborList.push_back(tmpNeighbor);
		tmpNeighbor.index = oddCityList[i];
		EulerGraph.adjList[oddCityList[matchingID]].dtNeighborList.push_back(tmpNeighbor);
		inMatching[i] = true;
		inMatching[matchingID] = true;
	}

	// walk through the Euler graph
	indi->tour.resize(thisProb->numCities);
	int currTourLength = 0;
	vector<bool> inTour(thisProb->numCities+1, false); // whether each city is in the tour, initially all false

	clock_t t2 = clock();

	EulerTourDFS(indi, currTourLength, 1, inTour, &EulerGraph, thisProb);

	clock_t t3 = clock();

	//cout << thisProb->numCities << endl;
	//PrintIntVec(indi->tour);
	//system("PAUSE");

	GetPosInTour(indi, thisProb); // get the positions of the cities

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "tour position" << endl;
	//PrintIntVec(indi->posInTour);
	//system("PAUSE");

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}

	cout << "tour length = " << indi->tourLength << endl;
	cout << t2-t1 << " " << t3-t2 << endl;
}

void EulerTourDFS(individual *indi, int & currTourLength, int currID, vector<bool> & inTour, minSpanTree *EulerGraph, problem *thisProb)
{
	// add this city into the tour
	if (!inTour[currID])
	{
		indi->tour[currTourLength] = currID;
		currTourLength ++;
		inTour[currID] = true;
	}

	if (currTourLength == thisProb->numCities) // the tour has been successfully constructed
		return;

	vector<int> unvisitedNeighborList;
	for (vector<dtNeighbor>::iterator it = EulerGraph->adjList[currID].dtNeighborList.begin(); it != EulerGraph->adjList[currID].dtNeighborList.end(); ++it)
	{
		if (!inTour[it->index])
			unvisitedNeighborList.push_back(it->index);
	}

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "unvisit neighbors" << endl;
	//PrintIntVec(unvisitedNeighborList);
	//system("pause");

	for (int i = 0; i < unvisitedNeighborList.size(); i++)
	{
		EulerTourDFS(indi, currTourLength, unvisitedNeighborList[i], inTour, EulerGraph, thisProb);
	}

	// remove this city from the tour
	if (!inTour[currID])
	{
		currTourLength --;
		inTour[currID] = false;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize a tour with k-nearest neighbor
//void RandKNNTour(individual *indi, int k, problem *thisProb)
//{
//	indi->tour.resize(thisProb->numCities);
//	indi->tour[0] = 1; // initally start from city 1
//
//	vector<int> inTour(thisProb->numCities+1, 0); // whether each city is already in tour, skip 0
//	inTour[1] = 1;
//
//	vector<int> knnCity(k), knnDist(k);
//	for (int i = 1; i < thisProb->numCities; i++)
//	{
//		//cout << "i = " << i << endl;
//		// initialize the knn information
//		int currCity = indi->tour[i-1];
//		int knnSize = 0;
//
//		vector<dtNeighbor> knnNeighborList;
//		vector<dtNeighbor>::iterator it = thisProb->cities[currCity].dtNeighborList.begin();
//		for (vector<dtNeighbor>::iterator it = thisProb->cities[currCity].dtNeighborList.begin(); it != thisProb->cities[currCity].dtNeighborList.end(); ++it)
//		{
//			if (inTour[it->index] || thisProb->cities[it->index].dtNeighborList.size() <= 2)
//				continue;
//
//			knnNeighborList.push_back(*it);
//
//			knnSize ++;
//			if (knnSize == k)
//				break;
//		}
//
//		cout << currCity << endl;
//		PrintNeighborVec(knnNeighborList);
//		system("PAUSE");
//
//		// randomly pick from the first k closest cities
//		int ub = k;
//		if ((int)knnNeighborList.size() < ub)
//			ub = (int)knnNeighborList.size();
//
//		int r = RandChoose(0, ub-1);
//		int nextCity = knnNeighborList[r].index;
//		indi->tour[i] = nextCity;
//		inTour[nextCity] = 1;
//
//		/*cout << r << " " << ub << " ";
//		for (int j = 0; j < ub; j++)
//		{
//			cout << knnCity[j] << " ";
//		}
//		cout << currCity << " " << nextCity << endl;
//		system("PAUSE");*/
//	}
//
//	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */
//
//	indi->cityBackDist.resize(thisProb->numCities+1, 0);
//	indi->cityNextDist.resize(thisProb->numCities+1, 0);
//	indi->tourLength = 0;
//
//	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
//	{
//		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
//		indi->tourLength += indi->cityNextDist[indi->tour[i]];
//	}
//	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
//	indi->tourLength += indi->cityNextDist[indi->tour.back()];
//
//	// calculate the distance from each city back to the starting city
//	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
//	//cout << tour.back() << " " << accuDist << endl;
//	indi->cityBackDist[indi->tour.back()] = accuDist;
//	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
//	{
//		accuDist += indi->cityNextDist[indi->tour[i]];
//		indi->cityBackDist[indi->tour[i]] = accuDist;
//		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
//	}
//	//system("PAUSE");
//}

void RandKNNTour(individual *indi, int k, problem *thisProb)
{
	indi->tour.resize(thisProb->numCities);
	indi->tour[0] = 1; // initally start from city 1

	vector<int> inTour(thisProb->numCities+1, 0); // whether each city is already in tour, skip 0
	inTour[1] = 1;

	vector<int> knnCity(k), knnDist(k);
	for (int i = 1; i < thisProb->numCities; i++)
	{
		//cout << "i = " << i << endl;
		// initialize the knn information
		int knnSize = 0; // no city in knn
		int currCity = indi->tour[i-1];
		for (int c = 2; c <= thisProb->numCities; c++)
		{
			if (inTour[c]) // already in tour
				continue;

			int tmpDist = CeilEuclDist(thisProb->cities[currCity], thisProb->cities[c]);
			int knnPos = 0;
			while (knnPos < knnSize && knnDist[knnPos] < tmpDist)
			{
				knnPos ++;
				if (knnPos == k)
					break;
			}

			if (knnPos == k)
				continue;

			//cout << "knnPos = " << knnPos << " " << knnCity.size() << " start insert" << endl;
			// insert knnCity and knnDist
			for (int j = k-1; j > knnPos; j--)
			{
				knnCity[j] = knnCity[j-1];
				knnDist[j] = knnDist[j-1];
			}
			knnCity[knnPos] = c;
			knnDist[knnPos] = tmpDist;
			knnSize ++;
			//knnCity.insert(knnCity.begin()+knnPos, c);
			//knnDist.insert(knnDist.begin()+knnPos, tmpDist);
			//cout << "finish insert" << endl;
		}

		// randomly pick from the first k closest cities
		int ub = k;
		if (knnSize < ub)
			ub = knnSize;

		int r = RandChoose(0, ub-1);
		int nextCity = knnCity[r];
		indi->tour[i] = nextCity;
		inTour[nextCity] = 1;

		//cout << i << ": " << r << " " << ub << " ";
		//for (int j = 0; j < ub; j++)
		//{
		//	cout << knnCity[j] << " ";
		//}
		//cout << currCity << " " << nextCity << " | " << inTour[nextCity] << endl;
		//system("PAUSE");
	}

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	//system("PAUSE");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize a tour with k-nearest neighbor in terms of distance and v/w ratio
void RandRatioKNNTour(individual *indi, int k, problem *thisProb)
{
	indi->tour.resize(thisProb->numCities);
	indi->tour[0] = 1; // initally start from city 1

	vector<int> inTour(thisProb->numCities+1, 0); // whether each city is already in tour, skip 0
	inTour[1] = 1;

	vector<int> knnCity, knnDist;
	for (int i = 2; i <= thisProb->numCities; i++)
	{
		// initialize the knn information
		knnCity.clear();
		knnDist.clear();
		int currCity = indi->tour.back();
		for (int c = 2; c <= thisProb->numCities; c++)
		{
			if (inTour[c]) // already in tour
				continue;

			//cout << "c = " << c << endl;
			int tmpDist = CeilEuclDist(thisProb->cities[currCity], thisProb->cities[c]);
			int knnPos = 0;
			while (knnDist.size() > knnPos && knnDist[knnPos] < tmpDist)
			{
				knnPos ++;
				if (knnPos == k)
					break;
			}

			if (knnPos == k)
				continue;

			//cout << "knnPos = " << knnPos << " " << knnCity.size() << " start insert" << endl;
			knnCity.insert(knnCity.begin()+knnPos, c);
			knnDist.insert(knnDist.begin()+knnPos, tmpDist);
			//cout << "finish insert" << endl;
		}

		// randomly pick from the first k closest cities
		int ub = k;
		if (knnCity.size() < ub)
			ub = knnCity.size();

		int r = RandChoose(0, ub-1);
		int nextCity = knnCity[r];
		indi->tour.push_back(nextCity);
		inTour[nextCity] = 1;

		/*cout << r << " " << ub << " ";
		for (int j = 0; j < ub; j++)
		{
			cout << knnCity[j] << " ";
		}
		cout << currCity << " " << nextCity << endl;
		system("PAUSE");*/
	}

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.assign(thisProb->numCities+1, 0);
	indi->cityNextDist.assign(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	//system("PAUSE");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize the picking plan based on k best adjusted value based on the tour without violating the capacity of the knapsack
void RandKBestAValuePickPlan(individual *indi, int k, problem *thisProb)
{
	// initialize the picking plan
	if (indi->pickPlan.size() == 0)
	{
		indi->pickPlan.resize(thisProb->numItems+1, 0); // all to zero
		indi->cityProfit.resize(thisProb->numCities+1, 0);
		indi->cityWeight.resize(thisProb->numCities+1, 0);
	}
	else
	{
		indi->pickPlan.assign(thisProb->numItems+1, 0);
		indi->cityProfit.assign(thisProb->numCities+1, 0);
		indi->cityWeight.assign(thisProb->numCities+1, 0);
	}

	// initialize the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	indi->itemProfit = 0;
	indi->itemWeight = 0;

	// calculate the item properties of each item
	vector<itemProperty> sortItems(thisProb->numItems+1);
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		double tmpSpeed = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*thisProb->items[i].weight/thisProb->capacity;
		double deltaTime = (1.0*indi->cityBackDist[thisProb->items[i].inCity])*(1.0/tmpSpeed-1.0/thisProb->maxSpeed);
		sortItems[i].index = i;
		sortItems[i].aValue = thisProb->items[i].profit - thisProb->rent*deltaTime;
		sortItems[i].avwRatio = sortItems[i].aValue/thisProb->items[i].weight;
		//cout << sortItems[i].index << " " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << backDist[thisProb->items[i].inCity] << " " << tmpSpeed  << " " << sortItems[i].avwRatio << endl;
	}
	//system("PAUSE");

	//vector<double> itemGainEmptyTour(thisProb->numItems+1);
	//GetItemGainEmptyTour(itemGainEmptyTour, indi, thisProb);
	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	sortItems[i].index = i;
	//	sortItems[i].aValue = itemGainEmptyTour[i];
	//	sortItems[i].avwRatio = sortItems[i].aValue/thisProb->items[i].weight;
	//}

	// sort with decreasing order of avwRatio
	sort(sortItems.begin()+1, sortItems.end(), itemAvwRatioLarger()); // ignore sortItems[0]

	//for (vector<itemProperty>::iterator it = sortItems.begin()+1; it != sortItems.end(); ++it)
	//{
	//	cout << it->index << ": " << it->aValue << " " << it->avwRatio << " " << indi->cityBackDist[thisProb->items[it->index].inCity] << endl;
	//	system("pause");
	//}

	/*for (int i = 1; i <= thisProb->numItems; i++)
	{
		cout << sortItems[i].index << " " << sortItems[i].avwRatio << endl;
	}
	system("PAUSE");*/

	// pick the sorted items until the knapsack is full
	vector<int> picked(thisProb->numItems+1, 0); // whether the item has already picked
	int weightResidual = thisProb->capacity;
	while (1)
	{
		int r = RandChoose(1, k);
		int ptr = 1;
		int pickedItem = 0;
		for (int i = 1; i <= thisProb->numItems; i++)
		{
			if (sortItems[i].avwRatio < 0)
				break;

			int tmpItem = sortItems[i].index;
			if (picked[tmpItem] || thisProb->items[tmpItem].weight > weightResidual) // skip this item
				continue;

			if (ptr < r)
			{
				pickedItem = tmpItem;
			}
			else if (ptr == r)
			{
				pickedItem = tmpItem;
				break;
			}

			ptr ++;
		}

		/*for (int i = 0; i < indi->tour.size(); i++)
		{
			cout << indi->tour[i] << " ";
		}
		cout << endl;
		cout << r << " " << weightResidual << " " << pickedItem << " " << thisProb->items[pickedItem].weight << endl;
		system("PAUSE");*/

		if (pickedItem == 0) // no item can be picked
			break;

		// pick the item
		indi->pickPlan[pickedItem] = thisProb->items[pickedItem].inCity;
		picked[pickedItem] = 1;
		weightResidual -= thisProb->items[pickedItem].weight;

		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[pickedItem]] += thisProb->items[pickedItem].profit;
		indi->cityWeight[indi->pickPlan[pickedItem]] += thisProb->items[pickedItem].weight;
		indi->itemProfit += thisProb->items[pickedItem].profit;
		indi->itemWeight += thisProb->items[pickedItem].weight;
	}

	/*for (int i = 0; i < indi->tour.size(); i++)
	{
		cout << indi->tour[i] << " ";
	}
	cout << endl;
	system("PAUSE");*/
}


void BestAvwRatioInsertPickPlan(individual *indi, problem *thisProb)
{
	// initialize the picking plan
	indi->pickPlan.assign(thisProb->numItems+1, 0); // all to zero

	// initialize the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	indi->cityProfit.assign(thisProb->numCities+1, 0);
	indi->cityWeight.assign(thisProb->numCities+1, 0);
	indi->itemProfit = 0;
	indi->itemWeight = 0;

	vector<int> picked(thisProb->numItems+1, 0); // whether the item has already picked
	int weightResidual = thisProb->capacity;

	// insert the items until the knapsack is full
	while (1)
	{
		itemProperty pickedItem, tmpItem;
		pickedItem.avwRatio = -INF;
		for (int i = 1; i <= thisProb->numItems; i++)
		{
			if (picked[i] || thisProb->items[i].weight > weightResidual)
				continue;

			int startWeight = 0;
			int startPos;
			double startSpeed;

			// find the startWeight, startSpeed and startPos
			for (int j = 0; j < indi->tour.size(); j++)
			{
				startWeight += indi->cityWeight[indi->tour[j]];

				if (indi->tour[j] == thisProb->items[i].inCity)
				{
					startSpeed = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*(1.0*startWeight)/thisProb->capacity;
					startPos = j;
					break;
				}
			}

			//cout << "start weight = " << startWeight << ", speed = " << startSpeed << ", pos = " << startPos << endl;

			int accuDist = 0;
			// calculate the tour time without this item from its city
			double time1 = 0;
			double currSpeed1 = startSpeed;
			int currWeight1 = startWeight;
			for (int j = startPos; j < indi->tour.size()-1; j++)
			{
				time1 += (1.0*indi->cityNextDist[indi->tour[j]])/currSpeed1;

				if (indi->cityWeight[indi->tour[j+1]] == 0)
					continue;

				// update speed and weight
				currWeight1 += indi->cityWeight[indi->tour[j+1]];
				currSpeed1 = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*(1.0*currWeight1)/thisProb->capacity;
			}
			// last step: return to the starting city
			time1 += (1.0*indi->cityNextDist[indi->tour.back()])/currSpeed1;
			double cost1 = thisProb->rent*time1;

			// calculate the tour time and adjusted profit with this item from its city
			double time2 = 0;
			int currWeight2 = startWeight+thisProb->items[i].weight; // add the item
			double currSpeed2 = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*(1.0*currWeight2)/thisProb->capacity;
			for (int j = startPos; j < indi->tour.size()-1; j++)
			{
				time2 += (1.0*indi->cityNextDist[indi->tour[j]])/currSpeed2;

				if (indi->cityWeight[indi->tour[j+1]] == 0)
					continue;

				// update speed and weight
				currWeight2 += indi->cityWeight[indi->tour[j+1]];
				currSpeed2 = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*(1.0*currWeight2)/thisProb->capacity;
			}
			// last step: return to the starting city
			time2 += (1.0*indi->cityNextDist[indi->tour.back()])/currSpeed2;
			double cost2 = thisProb->rent*time2;

			tmpItem.index = i;
			tmpItem.aValue = thisProb->items[i].profit+cost1-cost2;
			tmpItem.avwRatio = tmpItem.aValue/thisProb->items[i].weight;

			/*cout << i << " " << cost1 << " " << cost2 << " " << thisProb->items[i].profit << " " << thisProb->items[i].weight << endl;
			system("PAUSE");*/

			if (tmpItem.avwRatio > pickedItem.avwRatio)
				pickedItem = tmpItem;
		}

		if (pickedItem.avwRatio <= 0) // no improvement
			break;

		/*for (int k = 0; k < indi->tour.size(); k++)
		{
			cout << indi->tour[k] << " ";
		}
		cout << endl;
		cout << pickedItem.index << "/" << indi->pickPlan.size()-1 << " " << pickedItem.avwRatio << " " << weightResidual << endl;
		system("PAUSE");*/

		// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->pickPlan[pickedItem.index] = thisProb->items[pickedItem.index].inCity;
		indi->cityProfit[thisProb->items[pickedItem.index].inCity] += thisProb->items[pickedItem.index].profit;
		indi->cityWeight[thisProb->items[pickedItem.index].inCity] += thisProb->items[pickedItem.index].weight;
		indi->itemProfit += thisProb->items[pickedItem.index].profit;
		indi->itemWeight += thisProb->items[pickedItem.index].weight;

		picked[pickedItem.index] = 1;
		weightResidual -= thisProb->items[pickedItem.index].weight;
	}

	/*for (int i = 1; i <= thisProb->numCities; i++)
	{
		cout << i << " " << indi->cityProfit[i] << " " << indi->cityWeight[i] << endl;
	}*/
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly initialize the picking plan without violating the capacity of the knapsack
void RandPickPlan(individual *indi, problem *thisProb)
{
	// initialize the picking plan
	if (indi->pickPlan.size() == 0)
	{
		indi->pickPlan.resize(thisProb->numItems+1, 0); // all to zero
		indi->cityProfit.resize(thisProb->numCities+1, 0);
		indi->cityWeight.resize(thisProb->numCities+1, 0);
	}
	else
	{
		indi->pickPlan.assign(thisProb->numItems+1, 0);
		indi->cityProfit.assign(thisProb->numCities+1, 0);
		indi->cityWeight.assign(thisProb->numCities+1, 0);
	}

	// initialize the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	indi->itemProfit = 0;
	indi->itemWeight = 0;


	int weightResidual = thisProb->capacity;

	vector<int> pickList(thisProb->numItems+1);
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		pickList[i] = i;
	}

	random_shuffle(pickList.begin()+1, pickList.end()); // ignore pickList[0]

	//PrintIntVec(pickList);
	//system("pause");

	for (vector<int>::iterator it = pickList.begin()+1; it != pickList.end(); ++it)
	{
		if (thisProb->items[*it].weight > weightResidual) // violate capacity, skip
			continue;

		// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->pickPlan[*it] = thisProb->items[*it].inCity;
		indi->cityProfit[thisProb->items[*it].inCity] += thisProb->items[*it].profit;
		indi->cityWeight[thisProb->items[*it].inCity] += thisProb->items[*it].weight;
		indi->itemProfit += thisProb->items[*it].profit;
		indi->itemWeight += thisProb->items[*it].weight;

		weightResidual -= thisProb->items[*it].weight;
	}

	//vector<int> picked(indi->pickPlan); // all the items are not picked
	//while (1)
	//{
	//	// randomly choose an item
	//	int k = RandChoose(1, thisProb->numItems);
	//	int moveStep = 0;
	//	while (picked[k] || thisProb->items[k].weight > weightResidual) // not eligible, move forward
	//	{
	//		moveStep ++;
	//		if (moveStep == thisProb->numItems) // all the items are not eligible
	//			break;

	//		k ++;
	//		if (k > thisProb->numItems) // out of bound
	//			k = 1;
	//	}

	//	if (moveStep == thisProb->numItems) // no more item can be picked, finish
	//		return;

	//	// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	//	indi->pickPlan[k] = thisProb->items[k].inCity;
	//	indi->cityProfit[thisProb->items[k].inCity] += thisProb->items[k].profit;
	//	indi->cityWeight[thisProb->items[k].inCity] += thisProb->items[k].weight;
	//	indi->itemProfit += thisProb->items[k].profit;
	//	indi->itemWeight += thisProb->items[k].weight;

	//	picked[k] = 1;
	//	weightResidual -= thisProb->items[k].weight;
	//}
}



void CoreItemPickPlan(individual *indi, vector<int> & coreItemList, vector<double> & itemGainExpectedTour, problem *thisProb)
{
	// initialize the picking plan
	if (indi->pickPlan.size() == 0)
	{
		indi->pickPlan.resize(thisProb->numItems+1, 0); // all to zero
		indi->cityProfit.resize(thisProb->numCities+1, 0);
		indi->cityWeight.resize(thisProb->numCities+1, 0);
	}
	else
	{
		indi->pickPlan.assign(thisProb->numItems+1, 0);
		indi->cityProfit.assign(thisProb->numCities+1, 0);
		indi->cityWeight.assign(thisProb->numCities+1, 0);
	}

	// initialize the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	indi->itemProfit = 0;
	indi->itemWeight = 0;

	int weightResidual = thisProb->capacity;

	//vector<itemGain> coreItemGainList;
	//for (vector<int>::iterator it = coreItemList.begin(); it != coreItemList.end(); ++it)
	//{
	//	itemGain tmpIG;
	//	tmpIG.item = *it;
	//	tmpIG.gain = itemGainExpectedTour[*it];
	//	coreItemGainList.push_back(tmpIG);
	//}

	//// sort the core items based on item gain
	//sort(coreItemGainList.begin(), coreItemGainList.end(), itemGainLarger());

	//for (vector<itemGain>::iterator it = coreItemGainList.begin(); it != coreItemGainList.end(); ++it)
	//{
	//	if (thisProb->items[it->item].weight > weightResidual) // violate capacity, skip
	//		continue;

	//	// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	//	indi->pickPlan[it->item] = thisProb->items[it->item].inCity;
	//	indi->cityProfit[thisProb->items[it->item].inCity] += thisProb->items[it->item].profit;
	//	indi->cityWeight[thisProb->items[it->item].inCity] += thisProb->items[it->item].weight;
	//	indi->itemProfit += thisProb->items[it->item].profit;
	//	indi->itemWeight += thisProb->items[it->item].weight;

	//	weightResidual -= thisProb->items[it->item].weight;
	//}

	// randomly shuffle
	random_shuffle(coreItemList.begin(), coreItemList.end());

	for (vector<int>::iterator it = coreItemList.begin(); it != coreItemList.end(); ++it)
	{
		if (thisProb->items[*it].weight > weightResidual) // violate capacity, skip
			continue;

		// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->pickPlan[*it] = thisProb->items[*it].inCity;
		indi->cityProfit[thisProb->items[*it].inCity] += thisProb->items[*it].profit;
		indi->cityWeight[thisProb->items[*it].inCity] += thisProb->items[*it].weight;
		indi->itemProfit += thisProb->items[*it].profit;
		indi->itemWeight += thisProb->items[*it].weight;

		weightResidual -= thisProb->items[*it].weight;
	}
}



void ItemGainPickPlan(individual *indi, vector<itemGain> & itemGainList, vector<int> & coreItemList, int coreSize, problem *thisProb)
{
	// initialize the picking plan
	if (indi->pickPlan.size() == 0)
	{
		indi->pickPlan.resize(thisProb->numItems+1, 0); // all to zero
		indi->cityProfit.resize(thisProb->numCities+1, 0);
		indi->cityWeight.resize(thisProb->numCities+1, 0);
	}
	else
	{
		indi->pickPlan.assign(thisProb->numItems+1, 0);
		indi->cityProfit.assign(thisProb->numCities+1, 0);
		indi->cityWeight.assign(thisProb->numCities+1, 0);
	}

	// initialize the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	indi->itemProfit = 0;
	indi->itemWeight = 0;


	// initialize core item list
	if (coreItemList.size() > 0)
		coreItemList.clear();


	int weightResidual = thisProb->capacity;

	int breakPos1 = 1;
	int breakPos2 = 1;
	for (vector<itemGain>::iterator it = itemGainList.begin()+1; it != itemGainList.end(); ++it)
	{
		if (thisProb->items[it->item].weight > weightResidual) // violate capacity, finish
			break;

		if (it->gain >= 0)
			breakPos1 ++;

		//if (it->gain < 0 || (thisProb->items[it->item].weight > weightResidual)) // violate capacity, skip
		//	break;

		breakPos2 ++;

		cout << it->item << ": " << thisProb->items[it->item].profit << " " << thisProb->items[it->item].weight << " " << indi->cityBackDist[thisProb->items[it->item].inCity] <<
			" " << it->gain << endl;

		// insert the picked item and update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->pickPlan[it->item] = thisProb->items[it->item].inCity;
		indi->cityProfit[thisProb->items[it->item].inCity] += thisProb->items[it->item].profit;
		indi->cityWeight[thisProb->items[it->item].inCity] += thisProb->items[it->item].weight;
		indi->itemProfit += thisProb->items[it->item].profit;
		indi->itemWeight += thisProb->items[it->item].weight;

		weightResidual -= thisProb->items[it->item].weight;
	}

	// get the core item list based on breaking item
	int coreStartPos = breakPos1-(int)(0.5*coreSize);

	if (coreStartPos < 1)
	{
		coreStartPos = 1;
	}
	else if (coreStartPos > thisProb->numItems-coreSize+1)
	{
		coreStartPos = thisProb->numItems-coreSize+1;
	}

	int coreEndPos = coreStartPos+coreSize-1;

//	cout << coreStartPos << " " << breakPos1 << " " << coreEndPos << endl;
//	system("pause");

	for (vector<itemGain>::iterator it = itemGainList.begin()+coreStartPos; it != itemGainList.begin()+coreEndPos; ++it)
	{
		coreItemList.push_back(it->item);
	}
}



// the core item list includes the first items in the sorted gain list to fill a full tour and the ones with positive gain in the best full tour
void GetCoreItemList(vector<int> & coreItemList, vector<itemGain> & itemGainList, individual *indi, problem *thisProb)
{
	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// initialize the core item list to be empty
	if (coreItemList.size() > 0)
		coreItemList.clear();

	vector<bool> inCore(thisProb->numItems+1, false); // whether each item is in the core list

	int accWeight = 0;
	vector<itemGain>::iterator it = itemGainList.begin()+1;

	// include the first items in the sorted gain list to fill a full tour
	while (it != itemGainList.end())
	{
		//double w = 1.0*weightResidual/thisProb->capacity;

		//if (it->gain < 0 || (thisProb->items[it->item].weight > weightResidual)) // violate capacity, skip
		if (thisProb->items[it->item].weight > thisProb->capacity-accWeight) // violate capacity, finish
			break;

		//double tmpGain;
		//if (accWeight == 0)
		//{
		//	tmpGain = it->gain;
		//}
		//else
		//{
		//	// estimate the expected time without the item under the linear weight assumption
		//	double a, b, w0, w1;
		//	w0 = (1-(1.0*indi->cityBackDist[thisProb->items[it->item].inCity])/indi->tourLength)*accWeight;
		//	w1 = accWeight;
		//	a = -gamma*(w1-w0);
		//	b = thisProb->maxSpeed-gamma*w0;
		//	double time1 = indi->cityBackDist[thisProb->items[it->item].inCity]*(log(a+b)-log(b))/a;

		//	// estimate the expected time without the item under the linear weight assumption
		//	w0 += thisProb->items[it->item].weight;
		//	w1 += thisProb->items[it->item].weight;
		//	b = thisProb->maxSpeed-gamma*w0;
		//	double time2 = indi->cityBackDist[thisProb->items[it->item].inCity]*(log(a+b)-log(b))/a;
		//	double tmpGain = thisProb->items[it->item].profit-thisProb->rent*(time2-time1);

		//	//cout << it->item << ": " << thisProb->items[it->item].profit << " " << thisProb->items[it->item].weight << " " << indi->cityBackDist[thisProb->items[it->item].inCity] <<
		//	//	" " << it->gain*thisProb->items[it->item].weight << " " << tmpGain << endl;
		//	//system("pause");
		//}

		// estimate the worst-case gain
		double speed1 = thisProb->maxSpeed-gamma*accWeight;
		double speed2 = thisProb->maxSpeed-gamma*(accWeight+thisProb->items[it->item].weight);
		long double deltaTime = indi->cityBackDist[thisProb->items[it->item].inCity]*(1/speed2-1/speed1);
		double worstGain = thisProb->items[it->item].profit-thisProb->rent*deltaTime;

		if (worstGain < 0) // worst-case gain is negative
		{
			//estimate expected gain under linear weight assumption
			//estimate the expected time without the item under the linear weight assumption
			double a, b, w0, w1;
			w0 = (1-(1.0*indi->cityBackDist[thisProb->items[it->item].inCity])/indi->tourLength)*accWeight;
			w1 = accWeight;
			a = -gamma*(w1-w0);
			b = thisProb->maxSpeed-gamma*w0;
			double time1 = indi->cityBackDist[thisProb->items[it->item].inCity]*log(a/b+1)/a;

			// estimate the expected time with the item under the linear weight assumption
			w0 += thisProb->items[it->item].weight;
			w1 += thisProb->items[it->item].weight;
			b = thisProb->maxSpeed-gamma*w0;
			double time2 = indi->cityBackDist[thisProb->items[it->item].inCity]*log(a/b+1)/a;
			double expGain = thisProb->items[it->item].profit-thisProb->rent*(time2-time1);

			if (expGain < 0)
			{
				++ it;
				continue;
			}

			//++ it;
			//continue;
		}

		//cout << accWeight << " " << speed1 << " " << speed2 << endl;
		//cout << it->item << ": " << thisProb->items[it->item].profit << " " << thisProb->items[it->item].weight << " " << indi->cityBackDist[thisProb->items[it->item].inCity] <<
		//	" " << it->gain << " " << tmpGain << endl;
		//system("pause");

		// include this item into the core item list
		coreItemList.push_back(it->item);
		inCore[it->item] = true;

		accWeight += thisProb->items[it->item].weight;

		++ it;
	}

	//// select the remaining items based on some heuristics
	//int numRemainingItems = thisProb->numItems-coreItemList.size();
	//int count = 0;
	//while (count < 0.05*numRemainingItems) // select the 5% of the remaining items to be in the core item list
	//{
	//	// include this item into the core item list
	//	coreItemList.push_back(it->item);
	//	inCore[it->item] = true;

	//	accWeight += thisProb->items[it->item].weight;

	//	++ it;
	//	count ++;
	//}

	//cout << accWeight << endl;
	//cout << coreItemList.size() << endl;
	//system("pause");
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ChainedLinKernTour(individual *indi, problem *thisProb, char *currOutputFileName)
{
	if (indi->tour.size() > 0)
		indi->tour.clear();

	int nextCity, edgeNum;
	// read the output file from Concorde
	ifstream file(currOutputFileName);

	//cout << currOutputFileName << endl;

	if (file.is_open())
	{
		string tmpString;

		file >> tmpString;
		file >> tmpString;
		edgeNum = atoi(tmpString.c_str());

		file >> tmpString;
		nextCity = atoi(tmpString.c_str());
		nextCity ++; // from index 0 to 1
		indi->tour.push_back(nextCity);

		for (int i = 1; i < edgeNum; i++)
		{
			file >> tmpString; // the second node of the edge
			nextCity = atoi(tmpString.c_str());
			nextCity ++; // from index 0 to 1
			indi->tour.push_back(nextCity);
			file >> tmpString; // the edge length
			file >> tmpString; // the first node of the next edge
		}
	}

	file.close();

	//PrintIntVec(indi->tour);
	//system("pause");

	GetPosInTour(indi, thisProb); // get the positions of the cities

	//cout << "tour" << endl;
	//PrintIntVec(indi->tour);
	//cout << "tour position" << endl;
	//PrintIntVec(indi->posInTour);
	//system("PAUSE");

	/* calculate the tour-related properties: cityBackDist, cityNextDist, tourLength; */

	indi->cityBackDist.resize(thisProb->numCities+1, 0);
	indi->cityNextDist.resize(thisProb->numCities+1, 0);
	indi->tourLength = 0;

	for (vector<int>::size_type i = 0; i != indi->tour.size()-1; i++)
	{
		indi->cityNextDist[indi->tour[i]] = CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]);
		indi->tourLength += indi->cityNextDist[indi->tour[i]];
	}
	indi->cityNextDist[indi->tour.back()] = CeilEuclDist(thisProb->cities[indi->tour.back()], thisProb->cities[1]);
	indi->tourLength += indi->cityNextDist[indi->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = indi->cityNextDist[indi->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	indi->cityBackDist[indi->tour.back()] = accuDist;
	for (vector<int>::size_type i = indi->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
}
