
#ifndef INITIALIZATION_H
#define INITIALIZATION_H

using namespace std;
#include <iostream>
#include <fstream>
#include <cstring>
#include <algorithm> // for sort
#include <vector>
#include <cstdlib>
#include <cmath>

#include "parameters.h"
#include "problem.h"
#include "city.h"
#include "item.h"
#include "individual.h"
#include "sampling.h"
#include "operators.h"
#include "delaunay2D.h"
#include "MST.h"

vector<dtNeighbor>::iterator FindNeighborID(vector<dtNeighbor>::iterator first, vector<dtNeighbor>::iterator last, int index);
list<dtNeighbor>::iterator FindNeighborID(list<dtNeighbor>::iterator first, list<dtNeighbor>::iterator last, int index);

void ConcatenateNeighborList(city &c1, city &c2);

void GetDTNeighbors(problem *thisProb, delaunayTriangulation *thisDT);


// randomly initialize a tour
void RandTour(individual *indi, problem *thisProb);

// randomly initialize a tour based on DT neighbors
void RandDTNeighborTour(individual *indi, int k, problem *thisProb);

// get the tour based on minimal spanning tree
void MSTTour(individual *indi, minSpanTree *thisMST, problem *thisProb);
// MSTour Depth First Search
void MSTTourDFS(individual *indi, int currID, vector<bool> & inTour, minSpanTree *thisMST, problem *thisProb);

// Random (minimal matching) Christofides tour
void RandChristofidesTour(individual *indi, minSpanTree *thisMST, problem *thisProb);
void EulerTourDFS(individual *indi, int & currTourLength, int currID, vector<bool> & inTour, minSpanTree *EulerGraph, problem *thisProb);

// randomly initialize a tour with k-nearest neighbor
void RandKNNTour(individual *indi, int k, problem *thisProb);

// randomly initialize a tour with k-nearest neighbor in terms of distance and v/w ratio
void RandRatioKNNTour(individual *indi, int k, problem *thisProb);

typedef struct itemProperty
{
	int index;
	double aValue;
	double avwRatio;
} itemProperty;

struct itemAvwRatioLarger
{
    inline bool operator() (const itemProperty& struct1, const itemProperty& struct2)
    {
        return (struct1.avwRatio > struct2.avwRatio);
    }
};

struct itemAvwRatioSmaller
{
    inline bool operator() (const itemProperty& struct1, const itemProperty& struct2)
    {
        return (struct1.avwRatio < struct2.avwRatio);
    }
};

// Randomly initialize the picking plan based on k best adjusted value without violating the capacity of the knapsack
void RandKBestAValuePickPlan(individual *indi, int k, problem *thisProb);

// Insert the items based on best adjusted value/weight ratio to initialize the picking plan
void BestAvwRatioInsertPickPlan(individual *indi, problem *thisProb);

// Randomly initialize a feasible picking plan
void RandPickPlan(individual *indi, problem *thisProb);

// generate picking plan based on the core item list
void CoreItemPickPlan(individual *indi, vector<int> & coreItemList, vector<double> & itemGainExpectedTour, problem *thisProb);

typedef struct itemGain
{
	int item;
	double gain; // leftTerm + w*rightTerm
} itemGain;

struct itemGainLarger
{
    inline bool operator() (const itemGain& struct1, const itemGain& struct2)
    {
        return (struct1.gain > struct2.gain);
    }
};

// generate picking plan based on the item gain list, along with the core item list
void ItemGainPickPlan(individual *indi, vector<itemGain> & itemGainList, vector<int> & coreItemList, int coreSize, problem *thisProb);

// get the core item list based on the item gain list and the item gain in the best full tour
void GetCoreItemList(vector<int> & coreItemList, vector<itemGain> & itemGainList, individual *indi, problem *thisProb);


// the tour obtained by the chained Lin-Kern heuristic
void ChainedLinKernTour(individual *indi, problem *thisProb, char *currOutputFileName);

#endif