
#ifndef ITEM_H
#define ITEM_H

typedef struct item
{
	double profit;
	double weight;
	int inCity; // In which city is the item?
} item;

#endif
