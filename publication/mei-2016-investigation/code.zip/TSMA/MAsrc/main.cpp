
using namespace std;
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <vector>
#include <time.h>
//#include <direct.h> // to mkdir
#include <algorithm> // to sort

#include "parameters.h"
#include "problem.h"
#include "individual.h"
#include "initialization.h"
#include "MA.h"
#include "operators.h"
#include "delaunay2D.h"
#include "MST.h"

//char instanceTTP1[MAX_NUM_INSTANCES][100] = 
//{
//	"Benchmarks/a280-1.txt",
//	"Benchmarks/a280-2.txt",
//	"Benchmarks/a280-3.txt",
//	"Benchmarks/fnl4461-1.txt",
//	"Benchmarks/fnl4461-2.txt",
//	"Benchmarks/fnl4461-3.txt",
//	"Benchmarks/pla33810-1.txt",
//	"Benchmarks/pla33810-2.txt",
//	"Benchmarks/pla33810-3.txt",
//};

clock_t startT;

int elapsedTime;
int concordeRuns;
int runID;

int main(int argc, char* argv[])
{
	startT = clock();

	char currInstance[500];
	strcpy(currInstance, argv[1]);

	if (argc < 3)
	{
		elapsedTime = 0;
	}
	else
	{
		string tmpString;
		tmpString = argv[2];
		elapsedTime = atoi(tmpString.c_str());
	}

	if (argc < 4)
	{
		concordeRuns = 1;
	}
	else
	{
		string tmpString;
		tmpString = argv[3];
		concordeRuns = atoi(tmpString.c_str());
	}

	if (argc < 5)
	{
		runID = 1;
	}
	else
	{
		string tmpString;
		tmpString = argv[4];
		runID = atoi(tmpString.c_str());
	}

	//cout << elapsedTime << endl;

	//for (int i = 0; i < strlen(currInstance); i++)
	//{
	//	if (currInstance[i] ==  '/')
	//	{
	//		currInstance[i] = '-';
	//	}
	//}

	// Read the input file
	//cout << "solving instance " << currInstance << endl;
	char readInstance[500];
	strcpy(readInstance, "input/");
	strcat(readInstance, currInstance);
	problem thisProb;
	ProblemRead(&thisProb, readInstance);
	cout << "finish reading" << endl;

	// Get the Delaunay Triangulation
	delaunayTriangulation thisDT;
	GetDelaunayTriangulation(&thisDT, &thisProb);
	cout << "finish triangulation" << endl;

	// Get the minimal spanning tree
	minSpanTree thisMST;
	GetMinSpanTree(&thisMST, &thisDT, &thisProb);
	cout << "finish getting MST" << endl;

	// Get the neighbors of each city from the Delaunay Triangulation
	GetDTNeighbors(&thisProb, &thisDT);
	cout << "finish getting neighbors" << endl;

	//mkdir("Results/");

	//char outDir[100];
	//strcpy(outDir, "Results/");
	//strcat(outDir, currInstance);
	//for (int i = 9; i < strlen(outDir); i++)
	//{
	//	if (outDir[i] == '/')
	//	{
	//		outDir[i] = '-';
	//	}
	//}
	//strcat(outDir, "/");
	//mkdir(outDir);

	// initialize fitnesses

	int tm;
	tm = time(NULL);
	//tm = 1399514377;
	srand(tm);

	char timechar[15];
	itoa(tm, timechar, 10);

	char outFileName[100];
	char logFileName[100];
	strcpy(logFileName, "output/");
	strcat(logFileName, currInstance);
	strcat(logFileName, ".log");
	strcat(logFileName, ".txt");
	strcpy(outFileName, "output/");
	strcat(outFileName, currInstance);
	strcat(outFileName, ".YiMeiMA.");
	strcat(outFileName, timechar);
	strcat(outFileName, ".txt");

	char resFileName[100];
	strcpy(resFileName, "output/");
	strcat(resFileName, currInstance);
	strcat(resFileName, ".profit");
	strcat(resFileName, itoa(runID, timechar, 10));
	strcat(resFileName, ".txt");

	cout << resFileName << endl;

	//cout << logFileName << " " << outFileName << endl;

	//ofstream outfile;
	//outfile.open(logFileName);
	//outfile << "Time seed = " << tm << endl;
	//outfile.close();

	// start running this run
	// define best feasible solution
	individual bfSolution, currSolution;

	///************ TS start *****************/
	//TSOpt(&currSolution, &bfSolution, 100, &thisProb, outFileName);
	///************ TS start *****************/
			
	/************ MA start *****************/
	// Population initialization
	vector<individual> pop;
	char ConcordeOutputFileName[500];
	strcpy(ConcordeOutputFileName, currInstance);
	strcat(ConcordeOutputFileName, ".concordeout");
	MAPopInit(pop, &thisMST, &thisProb, ConcordeOutputFileName);
	sort(pop.begin(), pop.end(), indiFitnessBetter()); // sort the population with fitness from best to worst
	IndiCopy(&bfSolution, &pop[0]);

	//cout << "finish initialization" << endl;
	double lsDuration;

	//sort(pop.begin(), pop.end(), indiTourLengthBetter()); // sort the population from best to worst
	// local search
	for (vector<individual>::size_type i = 0; i != pop.size(); i++)
	{
		MALocalSearch(&pop[i], &bfSolution, &thisProb, outFileName, logFileName, lsDuration);

		clock_t currT = clock();
		double duration = (double)(currT-startT)/CLOCKS_PER_SEC;
		if (duration > MAX_RUNTIME-elapsedTime-lsDuration)
		{
			OutputFinal(&bfSolution, resFileName);
			return 1;
		}
	}

	// MA optimization process
	MAOpt(pop, &bfSolution, MA_MAX_GEN, &thisMST, &thisProb, outFileName, logFileName, resFileName);
	/************ MA finish *****************/

	//clock_t finish = clock(); // finish clock
	//double duration = (double)(finish-startT)/CLOCKS_PER_SEC;

	//outfile.open(logFileName, fstream::app);
	//outfile << "Best solution" << endl;
	//outfile << "Tour" << endl;
	//for (int i = 0; i < bfSolution.tour.size(); i++)
	//{
	//	outfile << bfSolution.tour[i] << " ";
	//}
	//outfile << endl;
	//outfile << "Pick Plan" << endl;
	//for (int i = 1; i < bfSolution.pickPlan.size(); i++)
	//{
	//	if (bfSolution.pickPlan[i] > 0)
	//	{
	//		outfile << i << " ";
	//	}
	//}
	//outfile << endl;
	//outfile << "Profit = " << bfSolution.profit << endl;
	//outfile << "Duration = " << duration << endl;
	//outfile.close();

	OutputRes(&bfSolution, outFileName);

	//outfile.open(outFileName);
	//outfile << "[";
	//for (int i = 0; i < bfSolution.tour.size()-1; i++)
	//{
	//	outfile << bfSolution.tour[i] << ",";
	//}
	//outfile << bfSolution.tour.back() << "]" << endl;
	//outfile << "[";
	//for (int i = 1; i < bfSolution.pickPlan.size()-1; i++)
	//{
	//	if (bfSolution.pickPlan[i] > 0)
	//	{
	//		outfile << i << ",";
	//	}
	//}
	//if (bfSolution.pickPlan.back() > 0)
	//	outfile << thisProb.numItems;
	//outfile << "]" << endl;
	//outfile.close();
	
	return 1;
}

