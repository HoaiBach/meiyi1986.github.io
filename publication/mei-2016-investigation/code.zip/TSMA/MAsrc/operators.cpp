
#include "operators.h"

void RandSelectParents(individual *parent1, individual *parent2, vector<individual> & pop, int popsize)
{
	int PID1 = RandChoose(0, popsize-1);
	int PID2 = RandChoose(0, popsize-2);
	if (PID2 >= PID1)
		PID2 ++;

	//cout << PID1 << " " << PID2 << endl;

	IndiCopy(parent1, &pop[PID1]);
	IndiCopy(parent2, &pop[PID2]);
}

void TournamentSelectParents(individual *parent1, individual *parent2, vector<individual> & pop, int popsize)
{
	int k1, k2, PID1, PID2;
	// select parent1
	k1 = RandChoose(0, popsize-1);
	k2 = RandChoose(0, popsize-2);
	if (k2 >= k1)
		k2 ++;

	if (k1 < k2)
	{
		PID1 = k1;
	}
	else
	{
		PID1 = k2;
	}
	IndiCopy(parent1, &pop[PID1]);

	// select parent2
	k1 = RandChoose(0, popsize-2);
	if (k1 >= PID1)
		k1 ++;
	k2 = RandChoose(0, popsize-3);
	if (k2 >= PID1)
		k2 ++;
	if (k2 >= k1)
		k2 ++;

	if (k1 < k2)
	{
		PID2 = k1;
	}
	else
	{
		PID2 = k2;
	}
	IndiCopy(parent2, &pop[PID2]);

	//cout << "PID1 = " << PID1 << ", PID2 = " << PID2 << endl;
}

void TourOXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb)
{
	int p1 = RandChoose(1, (int)parent1->tour.size()-1); // select sub-tour of tour2 from p1 to p2, ignoring the starting city
	int p2 = RandChoose(1, (int)parent1->tour.size()-2);
	if (p2 >= p1)
	{
		p2 ++;
	}
	else // swap p1 and p2
	{
		int tmp = p1;
		p1 = p2;
		p2 = tmp;
	}

	//int segmentLength = (int)(1.0*thisProb->numCities/4);
	//int p1 = RandChoose(1, thisProb->numCities-segmentLength); // the starting position of the segment
	//int p2 = p1+segmentLength-1;

	//for (int i = 0; i != parent1->tour.size(); i++)
	//{
	//	cout << parent1->tour[i] << " ";
	//}
	//cout << endl;
	//for (int i = 0; i != parent2->tour.size(); i++)
	//{
	//	cout << parent2->tour[i] << " ";
	//}
	//cout << endl;
	//cout << p1 << " " << p2 << endl;

	xchild->tour.resize(parent1->tour.size());
	xchild->tour[0] = 1; // starting from city 1
	for (int i = p1; i <= p2; i++)
	{
		xchild->tour[i] = parent2->tour[i];
	}

	vector<int> removed(thisProb->numCities+1, 0);
	removed[1] = 1; // city 1 is removed
	for (int i = p1; i <= p2; i++)
	{
		removed[parent2->tour[i]] = 1;
	}

	int xindex = p2+1;
	if (xindex >= parent1->tour.size())
		xindex = 1;

	for (int i = p2+1; i < parent1->tour.size(); i++)
	{
		if (!removed[parent1->tour[i]])
		{
			xchild->tour[xindex] = parent1->tour[i];
			xindex ++;
			if (xindex >= parent1->tour.size())
				xindex = 1;
		}
	}
	for (int i = 1; i <= p2; i++)
	{
		if (!removed[parent1->tour[i]])
		{
			xchild->tour[xindex] = parent1->tour[i];
			xindex ++;
			if (xindex >= parent1->tour.size())
				xindex = 1;
		}
	}

	GetPosInTour(xchild, thisProb); // get the positions of the cities

	//if (!ValidTour(xchild, thisProb))
	//{
	//	cout << "parent1" << endl;
	//	PrintIntVec(parent1->tour);
	//	cout << "parent2" << endl;
	//	PrintIntVec(parent2->tour);
	//	cout << "p1 = " << p1 << ", p2 = " << p2 << endl;
	//	PrintIntVec(xchild->tour);
	//	system("PAUSE");
	//}

	// update the tour-related properties of xchild: cityBackDist, cityNextDist, tourLength;
	xchild->cityBackDist.assign(thisProb->numCities+1, 0);
	xchild->cityNextDist.assign(thisProb->numCities+1, 0);
	xchild->tourLength = 0;
	for (vector<int>::size_type i = 0; i != xchild->tour.size()-1; i++)
	{
		xchild->cityNextDist[xchild->tour[i]] = CeilEuclDist(thisProb->cities[xchild->tour[i]], thisProb->cities[xchild->tour[i+1]]);
		xchild->tourLength += xchild->cityNextDist[xchild->tour[i]];
	}
	xchild->cityNextDist[xchild->tour.back()] = CeilEuclDist(thisProb->cities[xchild->tour.back()], thisProb->cities[1]);
	xchild->tourLength += xchild->cityNextDist[xchild->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = xchild->cityNextDist[xchild->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	xchild->cityBackDist[xchild->tour.back()] = accuDist;
	for (vector<int>::size_type i = xchild->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += xchild->cityNextDist[xchild->tour[i]];
		xchild->cityBackDist[xchild->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	//system("PAUSE");
}

void TourERXOver(individual *xchild, individual *parent1, individual *parent2, problem *thisProb)
{
	// pick a segment randomly from parent1
	int segmentLength = (int)(1.0*thisProb->numCities/4);
	int segmentStartPos = RandChoose(0, thisProb->numCities-segmentLength); // the starting position of the segment

	vector<bool> inTour(thisProb->numCities+1, false); // whether each city is in tour, initially all false
	int currCity; // the current city

	// copy the tour segment
	//vector<int> tourSegment;
	for (vector<int>::iterator it = parent1->tour.begin()+segmentStartPos; it != parent1->tour.begin()+segmentStartPos+segmentLength; ++it)
	{
		//tourSegment.push_back(*it);
		xchild->tour.push_back(*it);
		inTour[*it] = true;
	}
	currCity = xchild->tour.back();

	PrintIntVec(parent1->tour);
	PrintIntVec(parent2->tour);
	cout << segmentStartPos << " " << segmentLength << endl;
	PrintIntVec(xchild->tour);
//	system("pause");

	// construct the edge map, as a vector of edge lists

	vector<edgeList> edgeMap(thisProb->numCities+1); // for each city
	vector<int>::iterator currit, predit, succit;

	// for the tour of parent2
	currit = parent2->tour.begin();
	predit = parent2->tour.end()-1;
	succit = currit+1;

	while (currit != parent2->tour.end())
	{
		if (inTour[*currit] == true && *currit != currCity) // the other cities in the segment than the current city
		{
			// update the three iterators
			++ currit;
			++ succit;
			if (succit == parent2->tour.end())
				succit = parent2->tour.begin();
			++ predit;
			if (predit == parent2->tour.end())
				predit = parent2->tour.begin();

			continue;
		}

		if (!inTour[*predit])
		{
			edgeMap[*currit].neighborList.push_back(*predit);
		}

		if (!inTour[*succit])
		{
			edgeMap[*currit].neighborList.push_back(*succit);
		}

		// update the three iterators
		++ currit;
		++ succit;
		if (succit == parent2->tour.end())
			succit = parent2->tour.begin();
		++ predit;
		if (predit == parent2->tour.end())
			predit = parent2->tour.begin();
	}

	// for the remaining tour of parent1
	currit = parent1->tour.begin();
	predit = parent1->tour.end()-1;
	succit = currit+1;

	while (currit != parent1->tour.end())
	{
		if (inTour[*currit] == true && *currit != currCity) // the other cities in the segment than the current city
		{
			// update the three iterators
			++ currit;
			++ succit;
			if (succit == parent1->tour.end())
				succit = parent1->tour.begin();
			++ predit;
			if (predit == parent1->tour.end())
				predit = parent1->tour.begin();

			continue;
		}

		if (!inTour[*predit])
		{
			// find whether it is a shared edge
			list<int>::iterator it = find(edgeMap[*currit].neighborList.begin(), edgeMap[*currit].neighborList.end(), *predit);
			if (it == edgeMap[*currit].neighborList.end()) // not a shared edge
			{
				edgeMap[*currit].neighborList.push_back(*predit);
			}
			else // is a shared edge, mark it as its -id
			{
				*it = -*it;
			}
		}

		if (!inTour[*succit])
		{
			// find whether it is a shared edge
			list<int>::iterator it = find(edgeMap[*currit].neighborList.begin(), edgeMap[*currit].neighborList.end(), *succit);
			if (it == edgeMap[*currit].neighborList.end()) // not a shared edge
			{
				edgeMap[*currit].neighborList.push_back(*succit);
			}
			else // is a shared edge, mark it as its -id
			{
				*it = -*it;
			}
		}

		// update the three iterators
		++ currit;
		++ succit;
		if (succit == parent1->tour.end())
			succit = parent1->tour.begin();
		++ predit;
		if (predit == parent1->tour.end())
			predit = parent1->tour.begin();
	}

	//// print the edge map
	//int index = 1;
	//for (vector<edgeList>::iterator it = edgeMap.begin()+1; it != edgeMap.end(); ++it)
	//{
	//	cout << index << ": ";
	//	index++;
	//	for (list<int>::iterator jt = it->neighborList.begin(); jt != it->neighborList.end(); ++jt)
	//	{
	//		cout << *jt << " ";
	//	}
	//	cout << endl;
	//}
	//system("pause");

	// insert the cities starting from the current city
	while (xchild->tour.size() < thisProb->numCities)
	{
		int nextCity;

		// examine the neighbor list of the current city
		if (edgeMap[currCity].neighborList.size() == 0) // empty edge map, edge failure!
		{
			//cout << "edge failure!" << endl;

			// randomly pick from the unvisited cities
			for (int i = 1; i <= thisProb->numCities; i++)
			{
				if (!inTour[i])
				{
					nextCity = i;
					break;
				}
			}
		}
		else
		{
			nextCity = edgeMap[currCity].neighborList.front(); // first set to the first neighbor
			// look for the shared edge
			for (list<int>::iterator it = edgeMap[currCity].neighborList.begin(); it != edgeMap[currCity].neighborList.end(); ++it)
			{
				if (*it < 0)
				{
					nextCity = -*it;
					break;
				}
			}

			//cout << currCity << " " << nextCity << " (";
			//for (list<int>::iterator it = edgeMap[currCity].neighborList.begin(); it != edgeMap[currCity].neighborList.end(); ++it)
			//{
			//	cout << *it << " ";
			//}
			//cout << ")" << endl;
			//system("pause");
		}

		// insert the next city
		xchild->tour.push_back(nextCity);
		inTour[nextCity] = true;
		// remove the occurrence of nextcity in the edge map
		for (list<int>::iterator it = edgeMap[nextCity].neighborList.begin(); it != edgeMap[nextCity].neighborList.end(); ++it)
		{
			list<int>::iterator jt; // the iterator of the occurrence of nextcity in its neighbors' list
			// each neighbor
			if (*it > 0)
			{
				jt = find(edgeMap[*it].neighborList.begin(), edgeMap[*it].neighborList.end(), nextCity);
				jt = edgeMap[*it].neighborList.erase(jt);
			}
			else // *it < 0
			{
				jt = find(edgeMap[-*it].neighborList.begin(), edgeMap[-*it].neighborList.end(), -nextCity);
				jt = edgeMap[-*it].neighborList.erase(jt);
			}
		}

		currCity = nextCity;
	}

	// find the position of city 1
	vector<int>::iterator tourStartPos = find(xchild->tour.begin(), xchild->tour.end(), 1);
	rotate(xchild->tour.begin(), tourStartPos, xchild->tour.end());

	GetPosInTour(xchild, thisProb); // get the positions of the cities

	//if (!ValidTour(xchild, thisProb))
	//{
	//	cout << "parent1" << endl;
	//	PrintIntVec(parent1->tour);
	//	cout << "parent2" << endl;
	//	PrintIntVec(parent2->tour);
	//	cout << "p1 = " << p1 << ", p2 = " << p2 << endl;
	//	PrintIntVec(xchild->tour);
	//	system("PAUSE");
	//}

	// update the tour-related properties of xchild: cityBackDist, cityNextDist, tourLength;
	xchild->cityBackDist.assign(thisProb->numCities+1, 0);
	xchild->cityNextDist.assign(thisProb->numCities+1, 0);
	xchild->tourLength = 0;
	for (vector<int>::size_type i = 0; i != xchild->tour.size()-1; i++)
	{
		xchild->cityNextDist[xchild->tour[i]] = CeilEuclDist(thisProb->cities[xchild->tour[i]], thisProb->cities[xchild->tour[i+1]]);
		xchild->tourLength += xchild->cityNextDist[xchild->tour[i]];
	}
	xchild->cityNextDist[xchild->tour.back()] = CeilEuclDist(thisProb->cities[xchild->tour.back()], thisProb->cities[1]);
	xchild->tourLength += xchild->cityNextDist[xchild->tour.back()];

	// calculate the distance from each city back to the starting city
	int accuDist = xchild->cityNextDist[xchild->tour.back()]; // accumulated distance
	//cout << tour.back() << " " << accuDist << endl;
	xchild->cityBackDist[xchild->tour.back()] = accuDist;
	for (vector<int>::size_type i = xchild->tour.size()-2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += xchild->cityNextDist[xchild->tour[i]];
		xchild->cityBackDist[xchild->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	//system("PAUSE");
}

void PickPlanSPXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb)
{
	xchild->pickPlan.resize(parent1->pickPlan.size());
	int cutPos = RandChoose(1, (int)parent1->pickPlan.size()-1); // cut the vector between cutPos and cutPos+1

	for (int i = 0; i <= cutPos; i++)
	{
		xchild->pickPlan[i] = parent1->pickPlan[i];
	}
	for (int i = cutPos+1; i < parent2->pickPlan.size(); i++)
	{
		xchild->pickPlan[i] = parent2->pickPlan[i];
	}

	// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	xchild->cityProfit.assign(thisProb->numCities+1, 0);
	xchild->cityWeight.assign(thisProb->numCities+1, 0);
	xchild->itemProfit = 0;
	xchild->itemWeight = 0;
	for (int i = 1; i != xchild->pickPlan.size(); i++)
	{
		if (xchild->pickPlan[i] > 0) // pick the item
		{
			int tmpCity = xchild->pickPlan[i];
			xchild->cityProfit[tmpCity] += thisProb->items[i].profit;
			xchild->cityWeight[tmpCity] += thisProb->items[i].weight;
			xchild->itemProfit += thisProb->items[i].profit;
			xchild->itemWeight += thisProb->items[i].weight;
		}
	}

	//cout << "before repair" << endl;
	//cout << xchild->itemWeight << endl;
	RepairPickplan(xchild, thisProb);
	//cout << "after repair" << endl;

	/*cout << "parent1 city weight" << endl;
	for (int i = 1; i < parent1->cityWeight.size(); i++)
	{
		cout << parent1->cityWeight[i] << " ";
	}
	cout << endl;
	cout << "parent2 city weight" << endl;
	for (int i = 1; i < parent2->cityWeight.size(); i++)
	{
		cout << parent2->cityWeight[i] << " ";
	}
	cout << endl;
	cout << "child city weight" << endl;
	for (int i = 1; i < xchild->cityWeight.size(); i++)
	{
		cout << xchild->cityWeight[i] << " ";
	}
	cout << endl;
	system("PAUSE");*/
}

void PickPlanUniXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb)
{
	xchild->pickPlan.resize(parent1->pickPlan.size());
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		double r = 1.0*rand()/RAND_MAX;
		if (r < 0.5)
		{
			xchild->pickPlan[i] = parent1->pickPlan[i];
		}
		else
		{
			xchild->pickPlan[i] = parent2->pickPlan[i];
		}
	}

	// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
	xchild->cityProfit.assign(thisProb->numCities+1, 0);
	xchild->cityWeight.assign(thisProb->numCities+1, 0);
	xchild->itemProfit = 0;
	xchild->itemWeight = 0;
	for (int i = 1; i != xchild->pickPlan.size(); i++)
	{
		if (xchild->pickPlan[i] > 0) // pick the item
		{
			int tmpCity = xchild->pickPlan[i];
			xchild->cityProfit[tmpCity] += thisProb->items[i].profit;
			xchild->cityWeight[tmpCity] += thisProb->items[i].weight;
			xchild->itemProfit += thisProb->items[i].profit;
			xchild->itemWeight += thisProb->items[i].weight;
		}
	}

	//cout << "before repair" << endl;
	//cout << xchild->itemWeight << endl;
	RepairPickplan(xchild, thisProb);
	//cout << "after repair" << endl;
}

void RepairPickplan(individual *indi, problem *thisProb)
{
	if (indi->itemWeight <= thisProb->capacity)
		return;

	//cout << "start repair picking plan" << endl;

	//cout << "picking plan" << endl;
	//for (int i = 1; i != indi->pickPlan.size(); i++)
	//{
	//	cout << indi->pickPlan[i] << " ";
	//}
	//cout << endl;

	// calculate the item properties of each item
	vector<itemProperty> sortItems;
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		if (indi->pickPlan[i] == 0) // this item is not picked, no need to be considered
			continue;

		itemProperty tmpProp;
		double tmpSpeed = thisProb->maxSpeed-(thisProb->maxSpeed-thisProb->minSpeed)*thisProb->items[i].weight/thisProb->capacity;
		double backTime = (1.0*indi->cityBackDist[thisProb->items[i].inCity])/tmpSpeed;
		tmpProp.index = i;
		tmpProp.aValue = thisProb->items[i].profit - thisProb->rent*backTime;
		tmpProp.avwRatio = tmpProp.aValue/thisProb->items[i].weight;
		sortItems.push_back(tmpProp);
		//cout << tmpProp.index << " " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << tmpProp.avwRatio << endl;
	}
	//system("PAUSE");

	// sort with increasing order of avwRatio
	sort(sortItems.begin(), sortItems.end(), itemAvwRatioSmaller()); // ignore sortItems[0]

	// remove the sorted items until the capacity is not violated
	for (vector<itemProperty>::size_type i = 0; i != sortItems.size(); i++)
	{
		int tmpItem = sortItems[i].index;

		// remove the item
		indi->pickPlan[tmpItem] = 0;
		indi->cityProfit[thisProb->items[tmpItem].inCity] -= thisProb->items[tmpItem].profit;
		indi->cityWeight[thisProb->items[tmpItem].inCity] -= thisProb->items[tmpItem].weight;
		indi->itemProfit -= thisProb->items[tmpItem].profit;
		indi->itemWeight -= thisProb->items[tmpItem].weight;

		if (indi->itemWeight <= thisProb->capacity)
			break;
	}

	//cout << "finish repair picking plan" << endl;
}

void GetBestTwoOptNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb)
{
	clock_t t1 = clock();

	individual tmpNeighbor;
	IndiCopy(neighbor, indi);
	nextMove->moveProfit = -INF; // no move yet

	int sum = 0;
	for (int i = 1; i < indi->tour.size()-1; i++) // starting city cannot be reversed
	{
		//int subTourWeight = indi->cityWeight[indi->tour[i]];
		for (int j = i+1; j < indi->tour.size(); j++)
		{
			//int sum1 = 0;
			//if (subTourWeight == 0)
			//{
			//	subTourWeight += indi->cityWeight[indi->tour[j]];
			//	if (subTourWeight == 0)
			//	{
			//		int dist1 = indi->cityNextDist[indi->tour[i-1]]+indi->cityNextDist[indi->tour[j]];
			//		int dist2 = CeilEuclDist(thisProb->cities[indi->tour[i-1]], thisProb->cities[indi->tour[j]])
			//			+CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[j+1]]);

			//		if (dist2 >= dist1)
			//		{
			//			//cout << "skip (" << i << ", " << j << ")" << endl;
			//			continue;
			//		}
			//	}
			//}

			//bool isdtNeighbor1 = false;
			//bool isdtNeighbor2 = false;
			//for (vector<dtNeighbor>::size_type it = 0; it != thisProb->cities[indi->tour[i-1]].dtNeighborList.size(); it++)
			//{
			//	//sum1 ++;
			//	if (thisProb->cities[indi->tour[i-1]].dtNeighborList[it].index == indi->tour[j])
			//	{
			//		isdtNeighbor1 = true;
			//		break;
			//	}
			//}
			//if (!isdtNeighbor1)
			//{
			//	int succCity;
			//	if (j == indi->tour.size()-1)
			//	{
			//		succCity = 1;
			//	}
			//	else
			//	{
			//		succCity = indi->tour[j+1];
			//	}
			//	for (vector<dtNeighbor>::size_type it = 0; it != thisProb->cities[succCity].dtNeighborList.size(); it++)
			//	{
			//		//sum1 ++;
			//		if (thisProb->cities[succCity].dtNeighborList[it].index == indi->tour[i])
			//		{
			//			isdtNeighbor2 = true;
			//			break;
			//		}
			//	}
			//}

			//if (!isdtNeighbor1 && !isdtNeighbor2)
			//{
			//	// cout << "2-opt of " << i << " and " << j << "is skipped" << endl;
			//	continue;
			//}

			sum ++;

			//cout << i << " " << j << endl;

			IndiCopy(&tmpNeighbor, indi);

			//cout << "before" << endl;
			//for (int k = 0; k < tmpNeighbor.tour.size(); k++)
			//{
			//	cout << tmpNeighbor.tour[k] << " ";
			//}
			//cout << endl;

			TourTwoOpt(&tmpNeighbor, i, j, thisProb);

			//cout << "after " << i+1 << " " << j+1 << endl;
			//for (int k = 0; k < tmpNeighbor.tour.size(); k++)
			//{
			//	cout << tmpNeighbor.tour[k] << " ";
			//}
			//cout << endl;
			//system("PAUSE");

			IndiReEvaluate(&tmpNeighbor, thisProb);

			//double profit1 = tmpNeighbor.profit;
			//IndiEvaluate(&tmpNeighbor, thisProb);
			//if (tmpNeighbor.profit != profit1)
			//{
			//	cout << "2-opt, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
			//}

			if (tmpNeighbor.profit > neighbor->profit)
			{
				IndiCopy(neighbor, &tmpNeighbor);
				nextMove->headCity = indi->tour[i];
				nextMove->tailCity = indi->tour[j];
				nextMove->headPos = i;
				nextMove->tailPos = j;
				nextMove->moveProfit = tmpNeighbor.profit;
			}
		}
	}

	clock_t t2 = clock();
	double dt = (double)(t2-t1);

	cout << "sum = " << sum << ", duration = " << dt << endl;
}

void GetBestTwoOptTSPNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb)
{
	clock_t t1 = clock();

	//if (indi->tourLength == 3941)
	//{
	//	PrintIntVec(indi->tour);
	//	cout << "length = " << indi->tourLength;
	//}

	tourTwoOptMove tmpMove;
	IndiCopy(neighbor, indi);
	nextMove->moveProfit = 0; // no move yet

	//if (indi->tourLength == 3941)
	//{
	//	PrintIntVec(indi->tour);
	//	cout << "length = " << indi->tourLength;
	//}

	int sum = 0;
	long long int sum1 = 0;
	for (int i = 0; i < indi->tour.size()-1; i++)
	{
		int id1 = indi->tour[i];
		// find the positions of the predecessor and successor of id1 in its neighbor list, INF means it is not the neighbor
		int predPosInNeighborList = INF;
		int succPosInNeighborList = INF;
		for (vector<dtNeighbor>::size_type j = 0; j != thisProb->cities[id1].dtNeighborList.size(); j++)
		{
			if (i > 0 && thisProb->cities[id1].dtNeighborList[j].index == indi->tour[i-1])
			{
				predPosInNeighborList = j;
				break;
			}
		}
		for (vector<dtNeighbor>::size_type j = 0; j != thisProb->cities[id1].dtNeighborList.size(); j++)
		{
			if (thisProb->cities[id1].dtNeighborList[j].index == indi->tour[i+1])
			{
				succPosInNeighborList = j;
				break;
			}
		}

		for (vector<dtNeighbor>::size_type j = 0; j != thisProb->cities[id1].dtNeighborList.size(); j++)
		{
			int id2 = thisProb->cities[id1].dtNeighborList[j].index;

			// position 2 is indi->posInTour[id2]
			if (indi->posInTour[id2] > i+1)
			{
				if (j > succPosInNeighborList)
					continue;

				//cout << "case 1" << endl;
				int pos1 = i+1;
				tmpMove.headCity = indi->tour[pos1];
				tmpMove.headPos = pos1;
				tmpMove.tailCity = id2;
				tmpMove.tailPos = indi->posInTour[id2];

				int succPos = tmpMove.tailPos+1;
				if (tmpMove.tailPos == thisProb->numCities-1)
					succPos = 0;

				//cout << "pos1 = " << tmpMove.headPos << ", pos2 = " << tmpMove.tailPos << endl;

				double dist1 = indi->cityNextDist[indi->tour[tmpMove.headPos-1]]+indi->cityNextDist[tmpMove.tailCity];
				double dist2 = thisProb->cities[id1].dtNeighborList[j].dist
					+CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos]], thisProb->cities[indi->tour[succPos]]);
				//double dist3 = CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos-1]], thisProb->cities[indi->tour[tmpMove.headPos]])
				//	+CeilEuclDist(thisProb->cities[indi->tour[tmpMove.tailPos]], thisProb->cities[indi->tour[succPos]]);
				//double dist4 = CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos-1]], thisProb->cities[indi->tour[tmpMove.tailPos]])
				//	+CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos]], thisProb->cities[indi->tour[succPos]]);

				//cout << dist1 << " " << dist3 << " " << dist2 << " " << dist4 << endl;

				tmpMove.moveProfit = dist1-dist2;
				if (tmpMove.moveProfit > nextMove->moveProfit)
					*nextMove = tmpMove;
			}
			else if (indi->posInTour[id2] < i-1 && indi->posInTour[id2] != 0)
			{
				if (j > predPosInNeighborList)
					continue;

				int pos2 = i-1;
				tmpMove.headCity = id2;
				tmpMove.headPos = indi->posInTour[id2];
				tmpMove.tailCity = indi->tour[pos2];
				tmpMove.tailPos = pos2;

				//cout << "case 2, pos1 = " << tmpMove.headPos << ", pos2 = " << tmpMove.tailPos << endl;

				int succPos = tmpMove.tailPos+1;
				if (tmpMove.tailPos == thisProb->numCities-1)
					succPos = 0;

				double dist1 = indi->cityNextDist[indi->tour[tmpMove.headPos-1]]+indi->cityNextDist[tmpMove.tailCity];
				double dist2 = CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos-1]], thisProb->cities[indi->tour[tmpMove.tailPos]])
					+thisProb->cities[id1].dtNeighborList[j].dist;
				//double dist3 = CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos-1]], thisProb->cities[indi->tour[tmpMove.headPos]])
				//	+CeilEuclDist(thisProb->cities[indi->tour[tmpMove.tailPos]], thisProb->cities[indi->tour[succPos]]);
				//double dist4 = CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos-1]], thisProb->cities[indi->tour[tmpMove.tailPos]])
				//	+CeilEuclDist(thisProb->cities[indi->tour[tmpMove.headPos]], thisProb->cities[indi->tour[succPos]]);

				//cout << dist1 << " " << dist3 << " " << dist2 << " " << dist4 << endl;

				tmpMove.moveProfit = dist1-dist2;
				if (tmpMove.moveProfit > nextMove->moveProfit)
					*nextMove = tmpMove;
			}

			sum ++;
			sum1 ++;
		}
	}

	//for (int i = 1; i < indi->tour.size()-1; i++) // starting city cannot be reversed
	//{
	//	//int subTourWeight = indi->cityWeight[indi->tour[i]];
	//	for (int j = i+1; j < indi->tour.size(); j++)
	//	{
	//		int succCity;
	//		if (j == indi->tour.size()-1)
	//		{
	//			succCity = 1;
	//		}
	//		else
	//		{
	//			succCity = indi->tour[j+1];
	//		}

	//		//if (subTourWeight == 0)
	//		//{
	//		//	subTourWeight += indi->cityWeight[indi->tour[j]];
	//		//	if (subTourWeight == 0)
	//		//	{
	//		//		int dist1 = indi->cityNextDist[indi->tour[i-1]]+indi->cityNextDist[indi->tour[j]];
	//		//		int dist2 = CeilEuclDist(thisProb->cities[indi->tour[i-1]], thisProb->cities[indi->tour[j]])
	//		//			+CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[j+1]]);

	//		//		if (dist2 >= dist1)
	//		//		{
	//		//			//cout << "skip (" << i << ", " << j << ")" << endl;
	//		//			continue;
	//		//		}
	//		//	}
	//		//}

	//		bool isdtNeighbor1 = false;
	//		bool isdtNeighbor2 = false;
	//		for (vector<dtNeighbor>::size_type it = 0; it != thisProb->cities[indi->tour[i-1]].dtNeighborList.size(); it++)
	//		{
	//			sum1 ++;
	//			//if (thisProb->cities[indi->tour[i-1]].dtNeighborList[it].index == indi->tour[j])
	//			//{
	//			//	isdtNeighbor1 = true;
	//			//	break;
	//			//}
	//		}
	//		//if (!isdtNeighbor1)
	//		//{
	//		//	int succCity;
	//		//	if (j == indi->tour.size()-1)
	//		//	{
	//		//		succCity = 1;
	//		//	}
	//		//	else
	//		//	{
	//		//		succCity = indi->tour[j+1];
	//		//	}
	//		//	for (vector<dtNeighbor>::size_type it = 0; it != thisProb->cities[succCity].dtNeighborList.size(); it++)
	//		//	{
	//		//		//sum1 ++;
	//		//		if (thisProb->cities[succCity].dtNeighborList[it].index == indi->tour[i])
	//		//		{
	//		//			isdtNeighbor2 = true;
	//		//			break;
	//		//		}
	//		//	}
	//		//}

	//		//if (!isdtNeighbor1 && !isdtNeighbor2)
	//		//{
	//		//	// cout << "2-opt of " << i << " and " << j << "is skipped" << endl;
	//		//	continue;
	//		//}

	//		sum ++;

	//		tmpMove.headPos = i;
	//		tmpMove.tailPos = j;

	//		//int dist1 = CeilEuclDist(thisProb->cities[indi->tour[i-1]], thisProb->cities[indi->tour[i]])
	//		//	+CeilEuclDist(thisProb->cities[indi->tour[j]], thisProb->cities[succCity]);
	//		//int dist2 = CeilEuclDist(thisProb->cities[indi->tour[i-1]], thisProb->cities[indi->tour[j]])
	//		//	+CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[succCity]);

	//		int dist1 = j;
	//		int dist2 = i;

	//		tmpMove.moveProfit = dist1-dist2;
	//		//if (tmpMove.moveProfit > nextMove->moveProfit) // improved
	//		//{
	//		//	tmpMove.headCity = indi->tour[i];
	//		//	tmpMove.tailCity = indi->tour[j];
	//		//	*nextMove = tmpMove;
	//		//}
	//	}
	//}

	//cout << "pos1 = " << nextMove->headPos << ", pos2 = " << nextMove->tailPos << ", profit = " << nextMove->moveProfit << endl;

	clock_t t2 = clock();

	if (nextMove->moveProfit > 0)
	{
		//int length1 = neighbor->tourLength-nextMove->moveProfit;

		TourTwoOpt(neighbor, nextMove->headPos, nextMove->tailPos, thisProb);
		IndiReEvaluate(neighbor, thisProb);

		//int length2 = neighbor->tourLength;
		//if (length1 != length2)
		//{
		//	cout << "length1 = " << length1 << ", length2 = " << length2 << endl;
		//	system("PAUSE");
		//}
	}

	clock_t t3 = clock();
	//cout << t2-t1 << " " << t3-t2 << endl;

	//cout << "sum1 = " << sum1 << ", sum = " << sum << ", duration = " << dt << endl;
}

void GetFirstImpTwoOptNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb)
{
	bool imp = false; // improved?
	individual tmpNeighbor;
	IndiCopy(neighbor, indi);
	nextMove->moveProfit = -INF; // no move yet
	for (int i = 1; i < indi->tour.size()-1; i++) // starting city cannot be reversed
	{
		int subTourWeight = indi->cityWeight[indi->tour[i]];
		for (int j = i+1; j < indi->tour.size(); j++)
		{
			if (subTourWeight == 0)
			{
				subTourWeight += indi->cityWeight[indi->tour[j]];
				if (subTourWeight == 0)
				{
					int dist1 = indi->cityNextDist[indi->tour[i-1]]+indi->cityNextDist[indi->tour[j]];
					int dist2 = CeilEuclDist(thisProb->cities[indi->tour[i-1]], thisProb->cities[indi->tour[j]])
						+CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[j+1]]);

					if (dist2 >= dist1)
					{
						//cout << "skip (" << i << ", " << j << ")" << endl;
						continue;
					}
				}
			}
			//cout << i << " " << j << endl;
			IndiCopy(&tmpNeighbor, indi);
			/*cout << "before" << endl;
			for (int k = 0; k < tmpNeighbor.tour.size(); k++)
			{
				cout << tmpNeighbor.tour[k] << " ";
			}
			cout << endl;*/
			TourTwoOpt(&tmpNeighbor, i, j, thisProb);
			/*cout << "after " << i+1 << " " << j+1 << endl;
			for (int k = 0; k < tmpNeighbor.tour.size(); k++)
			{
				cout << tmpNeighbor.tour[k] << " ";
			}
			cout << endl;
			system("PAUSE");*/
			IndiReEvaluate(&tmpNeighbor, thisProb);

			/*double profit1 = tmpNeighbor.profit;
			IndiEvaluate(&tmpNeighbor, thisProb);
			if (tmpNeighbor.profit != profit1)
			{
				cout << "2-opt, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
			}*/

			if (tmpNeighbor.profit > neighbor->profit)
			{
				IndiCopy(neighbor, &tmpNeighbor);
				nextMove->headCity = indi->tour[i];
				nextMove->tailCity = indi->tour[j];
				nextMove->headPos = i;
				nextMove->tailPos = j;
				nextMove->moveProfit = tmpNeighbor.profit;
			}

			if (neighbor->profit > indi->profit)
			{
				imp = true;
				break;
			}
		}

		if (imp == true)
			break;
	}
}

// the 2-opt operator for tour, p1 < p2
void TourTwoOpt(individual *indi, int p1, int p2, problem *thisProb)
{
	long long int oldLinkDist = indi->cityNextDist[indi->tour[p1-1]]+indi->cityNextDist[indi->tour[p2]];
	reverse(indi->tour.begin()+p1, indi->tour.begin()+p2+1);

	// update the positions of each city in the tour
	for (vector<int>::size_type i = p1; i <= p2; i++)
	{
		indi->posInTour[indi->tour[i]] = (int)i;
	}

	// update the tour-related properties: cityBackDist, cityNextDist, tourLength;
	indi->cityNextDist[indi->tour[p1-1]] = CeilEuclDist(thisProb->cities[indi->tour[p1-1]], thisProb->cities[indi->tour[p1]]);
	for (vector<int>::size_type i = p1; i != p2; i++)
	{
		indi->cityNextDist[indi->tour[i]] = indi->cityNextDist[indi->tour[i+1]]; // for symmetric TSP
	}
	if (p2 == indi->tour.size()-1)
	{
		indi->cityNextDist[indi->tour[p2]] = CeilEuclDist(thisProb->cities[indi->tour[p2]], thisProb->cities[1]);
	}
	else
	{
		indi->cityNextDist[indi->tour[p2]] = CeilEuclDist(thisProb->cities[indi->tour[p2]], thisProb->cities[indi->tour[p2+1]]);
	}

	long long int accuDist = 0; // accumulated distance
	if (p2 < indi->tour.size()-1)
	{
		accuDist = indi->cityBackDist[indi->tour[p2+1]];
	}

	for (vector<int>::size_type i = p2; i != 0; i--) // ignore the starting city 1
	{
		accuDist += indi->cityNextDist[indi->tour[i]];
		indi->cityBackDist[indi->tour[i]] = accuDist;
		//cout << i << " " << indi->tour[i] << " " << indi->tour[i+1] << " " << accuDist << " " << CeilEuclDist(thisProb->cities[indi->tour[i]], thisProb->cities[indi->tour[i+1]]) << endl;
	}
	indi->tourLength += indi->cityNextDist[indi->tour[p1-1]]+indi->cityNextDist[indi->tour[p2]]-oldLinkDist;
}

void GetBestSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, individual *indi, problem *thisProb)
{
	IndiCopy(neighbor, indi);
	individual tmpNeighbor;
	nextMove->moveProfit = 0; // no move yet

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		if (indi->pickPlan[i] == 0 && thisProb->items[i].weight > thisProb->capacity-indi->itemWeight) // violate the capacity
			continue;

		IndiCopy(&tmpNeighbor, indi);
		int fromStatus = tmpNeighbor.pickPlan[i];
		PickPlanSingleFlip(&tmpNeighbor, i, thisProb); // flip item i
		int toStatus = tmpNeighbor.pickPlan[i];
		IndiReEvaluate(&tmpNeighbor, thisProb);

		/*double profit1 = tmpNeighbor.profit;
		IndiEvaluate(&tmpNeighbor, thisProb);
		if (tmpNeighbor.profit != profit1)
		{
			cout << "single flip, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
		}*/

		if (tmpNeighbor.profit > neighbor->profit)
		{
			IndiCopy(neighbor, &tmpNeighbor);
			nextMove->item = i;
			nextMove->fromStatus = fromStatus;
			nextMove->toStatus = toStatus;
			nextMove->moveProfit = tmpNeighbor.profit;
		}
	}
}

void GetBestGainSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, vector<double> & itemGainEmptyTour, vector<double> & itemGainExpectedTour, individual *indi, problem *thisProb)
{
	IndiCopy(neighbor, indi);
	singleFlipMove tmpMove;
	nextMove->moveProfit = -INF; // no move yet

	//for (vector<double>::size_type i = 1; i < itemDeltaProfit.size(); i++)
	//{
	//	cout << itemDeltaProfit[i] << " ";
	//}
	//cout << endl;
	//system("pause");

	// filter the items that need to be taken into account
	vector<bool> needFlip(thisProb->numItems+1, false);

	vector<double> itemDeltaTime(thisProb->numItems+1);
	vector<double> itemGainTour(thisProb->numItems+1);
	//GetItemGainTour(itemGainTour, itemDeltaTime, itemGainExpectedTour, indi, thisProb);

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		if (indi->pickPlan[i] == 0) // from unpicked to picked
		{
			if ((thisProb->items[i].weight > thisProb->capacity-indi->itemWeight) // violate the capacity
				|| (itemGainExpectedTour[i] < 0)) // negative gain, never pick
				continue;
		}

		tmpMove.item = i;
		tmpMove.moveDeltaTime = itemDeltaTime[i];
		tmpMove.moveProfit = itemGainTour[i];

		//cout << tmpMove.moveProfit << endl;

		if (tmpMove.moveProfit > nextMove->moveProfit)
			*nextMove = tmpMove;
	}

	//individual tmpNeighbor;
	//IndiCopy(&tmpNeighbor, indi);
	//int fromStatus = tmpNeighbor.pickPlan[nextMove->item];
	//PickPlanSingleFlip(&tmpNeighbor, nextMove->item, thisProb);
	//int toStatus = tmpNeighbor.pickPlan[nextMove->item];
	//nextMove->fromStatus = fromStatus;
	//nextMove->toStatus = toStatus;
	//IndiReEvaluate(&tmpNeighbor, thisProb);

	//cout << "flip " << nextMove->item << " at pos " << indi->posInTour[thisProb->items[nextMove->item].inCity] << " from " << nextMove->fromStatus << " to " << nextMove->toStatus << ", delta profit = " << nextMove->moveProfit << endl;

	//cout << "profit1 = " << indi->profit << ", profit2 = " << tmpNeighbor.profit << endl;

	//system("pause");

	if (nextMove->moveProfit > 0)
	{
		nextMove->fromStatus = indi->pickPlan[nextMove->item];
		PickPlanSingleFlip(neighbor, nextMove->item, thisProb);
		nextMove->toStatus = neighbor->pickPlan[nextMove->item];
		neighbor->tourTime += nextMove->moveDeltaTime;
		neighbor->profit += nextMove->moveProfit;
	}

	//if (tmpNeighbor.profit > neighbor->profit)
	//{
	//	IndiCopy(neighbor, &tmpNeighbor);
	//}
}


void GetBestGainSingleFlipCoreNeighbor(individual *neighbor, singleFlipMove *nextMove, vector<int> & coreItemList, vector<double> & itemGainExpectedTour, individual *indi, problem *thisProb)
{
	IndiCopy(neighbor, indi);
	singleFlipMove tmpMove;
	nextMove->moveProfit = -INF; // no move yet

	//for (vector<double>::size_type i = 1; i < itemDeltaProfit.size(); i++)
	//{
	//	cout << itemDeltaProfit[i] << " ";
	//}
	//cout << endl;
	//system("pause");

	vector<double> itemDeltaTime(thisProb->numItems+1);
	vector<double> itemGainTour(thisProb->numItems+1);
	GetItemGainTour(itemGainTour, itemDeltaTime, coreItemList, indi, thisProb);

	for (vector<int>::iterator it = coreItemList.begin(); it != coreItemList.end(); ++it)
	{
		if (indi->pickPlan[*it] == 0) // from unpicked to picked
		{
			if (thisProb->items[*it].weight > thisProb->capacity-indi->itemWeight) // violate the capacity
				continue;
		}

		tmpMove.item = *it;
		tmpMove.moveDeltaTime = itemDeltaTime[*it];
		tmpMove.moveProfit = itemGainTour[*it];

		//cout << tmpMove.moveProfit << endl;

		if (tmpMove.moveProfit > nextMove->moveProfit)
			*nextMove = tmpMove;
	}

	//individual tmpNeighbor;
	//IndiCopy(&tmpNeighbor, indi);
	//int fromStatus = tmpNeighbor.pickPlan[nextMove->item];
	//PickPlanSingleFlip(&tmpNeighbor, nextMove->item, thisProb);
	//int toStatus = tmpNeighbor.pickPlan[nextMove->item];
	//nextMove->fromStatus = fromStatus;
	//nextMove->toStatus = toStatus;
	//IndiReEvaluate(&tmpNeighbor, thisProb);

	//cout << "flip " << nextMove->item << " at pos " << indi->posInTour[thisProb->items[nextMove->item].inCity] << " from " << nextMove->fromStatus << " to " << nextMove->toStatus << ", delta profit = " << nextMove->moveProfit << endl;

	//cout << "profit1 = " << indi->profit << ", profit2 = " << tmpNeighbor.profit << endl;

	//system("pause");

	if (nextMove->moveProfit > 0)
	{
		nextMove->fromStatus = indi->pickPlan[nextMove->item];
		PickPlanSingleFlip(neighbor, nextMove->item, thisProb);
		nextMove->toStatus = neighbor->pickPlan[nextMove->item];
		neighbor->tourTime += nextMove->moveDeltaTime;
		neighbor->profit += nextMove->moveProfit;
	}

	//if (tmpNeighbor.profit > neighbor->profit)
	//{
	//	IndiCopy(neighbor, &tmpNeighbor);
	//}
}


void GetFirstImpSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, individual *indi, problem *thisProb)
{
	bool imp = false;
	IndiCopy(neighbor, indi);
	individual tmpNeighbor;
	nextMove->moveProfit = -INF; // no move yet
	for (int i = 1; i <= thisProb->numItems; i++)
	{
		if (indi->pickPlan[i] == 0 && thisProb->items[i].weight > thisProb->capacity-indi->itemWeight) // violate the capacity
			continue;

		IndiCopy(&tmpNeighbor, indi);
		int fromStatus = indi->pickPlan[i];
		PickPlanSingleFlip(&tmpNeighbor, i, thisProb); // flip item i
		int toStatus = indi->pickPlan[i];
		IndiReEvaluate(&tmpNeighbor, thisProb);

		/*double profit1 = tmpNeighbor.profit;
		IndiEvaluate(&tmpNeighbor, thisProb);
		if (tmpNeighbor.profit != profit1)
		{
			cout << "single flip, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
		}*/

		if (tmpNeighbor.profit > neighbor->profit)
		{
			IndiCopy(neighbor, &tmpNeighbor);
			nextMove->item = i;
			nextMove->fromStatus = fromStatus;
			nextMove->toStatus = toStatus;
			nextMove->moveProfit = tmpNeighbor.profit;
		}

		if (neighbor->profit > indi->profit)
		{
			imp = true;
			break;
		}
	}
}

void PickPlanSingleFlip(individual *indi, int k, problem *thisProb)
{
	if (indi->pickPlan[k] == 0) // not picked
	{
		indi->pickPlan[k] = thisProb->items[k].inCity;

		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k]] += thisProb->items[k].profit;
		indi->cityWeight[indi->pickPlan[k]] += thisProb->items[k].weight;
		indi->itemProfit += thisProb->items[k].profit;
		indi->itemWeight += thisProb->items[k].weight;

		RepairPickplan(indi, thisProb);
	}
	else // picked, remove it, no need to repair
	{
		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k]] -= thisProb->items[k].profit;
		indi->cityWeight[indi->pickPlan[k]] -= thisProb->items[k].weight;
		indi->itemProfit -= thisProb->items[k].profit;
		indi->itemWeight -= thisProb->items[k].weight;

		indi->pickPlan[k] = 0;
	}
}

void GetBestExchangeNeighbor(individual *neighbor, exchangeMove *nextMove, individual *indi, problem *thisProb)
{
	IndiCopy(neighbor, indi);
	individual tmpNeighbor;
	nextMove->moveProfit = -INF; // no move yet
	//cout << "start" << endl;
	for (int i = 1; i < thisProb->numItems; i++)
	{
		for (int j = i+1; j <= thisProb->numItems; j++)
		{
			if (indi->pickPlan[i] == 0 && indi->pickPlan[j] == 0) // both not picked
				continue;

			if (indi->pickPlan[i] > 0 && indi->pickPlan[j] > 0) // both picked
				continue;

			if (indi->pickPlan[i] == 0 && thisProb->items[i].weight-thisProb->items[j].weight > thisProb->capacity-indi->itemWeight)
				continue;

			if (indi->pickPlan[j] == 0 && thisProb->items[j].weight-thisProb->items[i].weight > thisProb->capacity-indi->itemWeight)
				continue;

			IndiCopy(&tmpNeighbor, indi);

			//cout << i << " " << tmpNeighbor.pickPlan[i] << " " << j << " " << tmpNeighbor.pickPlan[j] << endl;
			int fromStatus1 = indi->pickPlan[i];
			int fromStatus2 = indi->pickPlan[j];
			PickPlanExchange(&tmpNeighbor, i, j, thisProb);
			int toStatus1 = indi->pickPlan[i];
			int toStatus2 = indi->pickPlan[j];
			//cout << i << " " << tmpNeighbor.pickPlan[i] << " " << j << " " << tmpNeighbor.pickPlan[j] << endl;
			//system("PAUSE");

			IndiReEvaluate(&tmpNeighbor, thisProb);

			/*double profit1 = tmpNeighbor.profit;
			IndiEvaluate(&tmpNeighbor, thisProb);
			if (tmpNeighbor.profit != profit1)
			{
				cout << "exchange, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
			}*/

			if (tmpNeighbor.profit > neighbor->profit)
			{
				IndiCopy(neighbor, &tmpNeighbor);
				nextMove->item1 = i;
				nextMove->fromStatus1 = fromStatus1;
				nextMove->toStatus1 = toStatus1;
				nextMove->item2 = j;
				nextMove->fromStatus2 = fromStatus2;
				nextMove->toStatus2 = toStatus2;
				nextMove->moveProfit = tmpNeighbor.profit;
			}
		}
	}
	//cout << "finish" << endl;
}

void GetFirstImpExchangeNeighbor(individual *neighbor, exchangeMove *nextMove, individual *indi, problem *thisProb)
{
	bool imp = false;
	IndiCopy(neighbor, indi);
	individual tmpNeighbor;
	nextMove->moveProfit = -INF; // no move yet
	//cout << "start" << endl;
	for (int i = 1; i < thisProb->numItems; i++)
	{
		for (int j = i+1; j <= thisProb->numItems; j++)
		{
			if (indi->pickPlan[i] == 0 && indi->pickPlan[j] == 0) // both not picked
				continue;

			if (indi->pickPlan[i] > 0 && indi->pickPlan[j] > 0) // both picked
				continue;

			if (indi->pickPlan[i] == 0 && thisProb->items[i].weight-thisProb->items[j].weight > thisProb->capacity-indi->itemWeight)
				continue;

			if (indi->pickPlan[j] == 0 && thisProb->items[j].weight-thisProb->items[i].weight > thisProb->capacity-indi->itemWeight)
				continue;

			IndiCopy(&tmpNeighbor, indi);

			//cout << i << " " << tmpNeighbor.pickPlan[i] << " " << j << " " << tmpNeighbor.pickPlan[j] << endl;
			int fromStatus1 = indi->pickPlan[i];
			int fromStatus2 = indi->pickPlan[j];
			PickPlanExchange(&tmpNeighbor, i, j, thisProb);
			int toStatus1 = indi->pickPlan[i];
			int toStatus2 = indi->pickPlan[j];
			//cout << i << " " << tmpNeighbor.pickPlan[i] << " " << j << " " << tmpNeighbor.pickPlan[j] << endl;
			//system("PAUSE");

			IndiReEvaluate(&tmpNeighbor, thisProb);

			/*double profit1 = tmpNeighbor.profit;
			IndiEvaluate(&tmpNeighbor, thisProb);
			if (tmpNeighbor.profit != profit1)
			{
				cout << "exchange, profit1 = " << profit1 << ", profit2 = " << tmpNeighbor.profit << endl;
			}*/

			if (tmpNeighbor.profit > neighbor->profit)
			{
				IndiCopy(neighbor, &tmpNeighbor);
				nextMove->item1 = i;
				nextMove->fromStatus1 = fromStatus1;
				nextMove->toStatus1 = toStatus1;
				nextMove->item2 = j;
				nextMove->fromStatus2 = fromStatus2;
				nextMove->toStatus2 = toStatus2;
				nextMove->moveProfit = tmpNeighbor.profit;
			}

			if (neighbor->profit > indi->profit)
			{
				imp = true;
				break;
			}
		}

		if (imp == true)
			break;
	}
	//cout << "finish" << endl;
}

void PickPlanExchange(individual *indi, int k1, int k2, problem *thisProb)
{
	if (indi->pickPlan[k1] == 0)
	{
		indi->pickPlan[k1] = thisProb->items[k1].inCity;

		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k1]] += thisProb->items[k1].profit;
		indi->cityWeight[indi->pickPlan[k1]] += thisProb->items[k1].weight;
		indi->itemProfit += thisProb->items[k1].profit;
		indi->itemWeight += thisProb->items[k1].weight;
	}
	else
	{
		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k1]] -= thisProb->items[k1].profit;
		indi->cityWeight[indi->pickPlan[k1]] -= thisProb->items[k1].weight;
		indi->itemProfit -= thisProb->items[k1].profit;
		indi->itemWeight -= thisProb->items[k1].weight;

		indi->pickPlan[k1] = 0;
	}

	if (indi->pickPlan[k2] == 0)
	{
		indi->pickPlan[k2] = thisProb->items[k2].inCity;

		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k2]] += thisProb->items[k2].profit;
		indi->cityWeight[indi->pickPlan[k2]] += thisProb->items[k2].weight;
		indi->itemProfit += thisProb->items[k2].profit;
		indi->itemWeight += thisProb->items[k2].weight;
	}
	else
	{
		// update the item-related properties: cityProfit, cityWeight, itemProfit, itemWeight;
		indi->cityProfit[indi->pickPlan[k2]] -= thisProb->items[k2].profit;
		indi->cityWeight[indi->pickPlan[k2]] -= thisProb->items[k2].weight;
		indi->itemProfit -= thisProb->items[k2].profit;
		indi->itemWeight -= thisProb->items[k2].weight;

		indi->pickPlan[k2] = 0;
	}

	RepairPickplan(indi, thisProb);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetItemDeltaProfit(vector<double> & itemDeltaProfit, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// calculate the accumulated weight of each city
	vector<int> accuWeight(thisProb->numCities+1, 0);
	for (int i = 1; i < indi->tour.size() ; i++) // the first city (indi->tour[0] = 1) in the tour has accumulated weight of 0
	{
		accuWeight[indi->tour[i]] = accuWeight[indi->tour[i-1]]+indi->cityWeight[indi->tour[i]];
		//cout << "accu weight of " << indi->tour[i] << " = " << accuWeight[indi->tour[i]] << endl;
	}

	//// calculate the w0 of each city in the tour
	//vector<int> w0(thisProb->numCities+1, 0);
	//w0[indi->tour.back()] = thisProb->capacity; // the carried weight of the last element must be the capacity (full tour)
	//for (int i = thisProb->numCities-2; i >= 0 ; i--) // the last city in the tour has accumulated weight of 0
	//{
	//	w0[indi->tour[i]] = w0[indi->tour[i+1]]-thisProb->cities[indi->tour[i+1]].totalWeight;
	//	//cout << "w0 of " << indi->tour[i] << " = " << w0[indi->tour[i]] << endl;
	//	if (w0[indi->tour[i]] < 0)
	//	{
	//		w0[indi->tour[i]] = 0;
	//		break;
	//	}
	//}

	//system("pause");

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		//// the position of this item
		//int itemPos = indi->posInTour[thisProb->items[i].inCity];

		//// compute the time without this item
		//double time1 = 0;
		//// compute the time with this item
		//double time2 = 0;
		//for (int j = itemPos; j <= thisProb->numCities-1; j++)
		//{
		//	int w = w0[indi->tour[j]]-thisProb->items[i].weight;
		//	if (w < 0)
		//		w = 0;

		//	time1 += (1.0*indi->cityNextDist[thisProb->items[i].inCity])/(thisProb->maxSpeed-gamma*w);
		//	time2 += (1.0*indi->cityNextDist[thisProb->items[i].inCity])/(thisProb->maxSpeed-gamma*(w+thisProb->items[i].weight));
		//}

		//double deltaTime = time2-time1;

		//cout << "i = " << i << endl;

		double deltaTime;

		if (indi->pickPlan[i] == 0) // not picked
		{
			double enumerator = gamma*indi->cityBackDist[thisProb->items[i].inCity]*thisProb->items[i].weight;
			double denominator1 = thisProb->maxSpeed-gamma*accuWeight[thisProb->items[i].inCity];
			double denominator2 = thisProb->maxSpeed-gamma*(accuWeight[thisProb->items[i].inCity]+thisProb->items[i].weight);
			deltaTime = enumerator/(denominator1*denominator2);
			itemDeltaProfit[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;
		}
		else // picked
		{
			double enumerator = gamma*indi->cityBackDist[thisProb->items[i].inCity]*thisProb->items[i].weight;
			double denominator1 = thisProb->maxSpeed-gamma*accuWeight[thisProb->items[i].inCity];
			double denominator2 = thisProb->maxSpeed-gamma*(accuWeight[thisProb->items[i].inCity]-thisProb->items[i].weight);
			deltaTime = enumerator/(denominator1*denominator2);
			itemDeltaProfit[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;
		}

		//cout << enumerator << " " << denominator1 << " " << denominator2 << endl;

		//cout << i << ": citypos = " << indi->posInTour[thisProb->items[i].inCity] << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemDeltaProfit[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}


void GetItemGainEmptyTour(vector<double> & itemGain, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	//// calculate the w0 of each city in the tour
	//vector<int> w0(thisProb->numCities+1, 0);
	//w0[indi->tour.back()] = thisProb->capacity; // the carried weight of the last element must be the capacity (full tour)
	//for (int i = thisProb->numCities-2; i >= 0 ; i--) // the last city in the tour has accumulated weight of 0
	//{
	//	w0[indi->tour[i]] = w0[indi->tour[i+1]]-thisProb->cities[indi->tour[i+1]].totalWeight;
	//	//cout << "w0 of " << indi->tour[i] << " = " << w0[indi->tour[i]] << endl;
	//	if (w0[indi->tour[i]] < 0)
	//	{
	//		w0[indi->tour[i]] = 0;
	//		break;
	//	}
	//}

	//system("pause");

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		//// the position of this item
		//int itemPos = indi->posInTour[thisProb->items[i].inCity];

		//// compute the time without this item
		//double time1 = 0;
		//// compute the time with this item
		//double time2 = 0;
		//for (int j = itemPos; j <= thisProb->numCities-1; j++)
		//{
		//	int w = w0[indi->tour[j]]-thisProb->items[i].weight;
		//	if (w < 0)
		//		w = 0;

		//	time1 += (1.0*indi->cityNextDist[thisProb->items[i].inCity])/(thisProb->maxSpeed-gamma*w);
		//	time2 += (1.0*indi->cityNextDist[thisProb->items[i].inCity])/(thisProb->maxSpeed-gamma*(w+thisProb->items[i].weight));
		//}

		//double deltaTime = time2-time1;

		//cout << "i = " << i << endl;

		long double enumerator = gamma*indi->cityBackDist[thisProb->items[i].inCity]*thisProb->items[i].weight;
		long double denominator1 = thisProb->maxSpeed;
		long double denominator2 = thisProb->maxSpeed-gamma*thisProb->items[i].weight;
		double deltaTime = enumerator/(denominator1*denominator2);
		itemGain[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;

		//cout << enumerator << " " << denominator1 << " " << denominator2 << endl;

		//cout << i << ": citypos = " << indi->posInTour[thisProb->items[i].inCity] << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemDeltaProfit[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}


void GetItemGainFullTour(vector<double> & itemGain, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// calculate the w0 of each city in the tour
	vector<int> w0(thisProb->numCities+1, 0);
	w0[indi->tour.back()] = thisProb->capacity; // the carried weight of the last element must be the capacity (full tour)
	for (int i = thisProb->numCities-2; i >= 0 ; i--) // the last city in the tour has accumulated weight of 0
	{
		w0[indi->tour[i]] = w0[indi->tour[i+1]]-thisProb->cities[indi->tour[i+1]].totalWeight;
		//cout << "w0 of " << indi->tour[i] << " = " << w0[indi->tour[i]] << endl;
		if (w0[indi->tour[i]] < 0)
		{
			w0[indi->tour[i]] = 0;
			break;
		}
	}

	//system("pause");

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		// the position of this item
		int itemPos = indi->posInTour[thisProb->items[i].inCity];

		// compute the time without this item
		double time1 = 0;
		// compute the time with this item
		double time2 = 0;
		for (int j = itemPos; j <= thisProb->numCities-1; j++)
		{
			int w = w0[indi->tour[j]]-thisProb->items[i].weight;
			if (w < 0)
				w = 0;

			time1 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*w);
			time2 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*(w+thisProb->items[i].weight));
		}

		double deltaTime = time2-time1;

		itemGain[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;

		//cout << i << ": citypos = " << itemPos << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemGain[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}

void GetItemGainExpectedTour(vector<double> & itemGain, int totalWeight, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// calculate the w0 of each city in the tour
	vector<int> w0(thisProb->numCities+1, 0);
	w0[indi->tour.back()] = totalWeight;
	for (int i = thisProb->numCities-2; i >= 0 ; i--)
	{
		w0[indi->tour[i]] = w0[indi->tour[i+1]]-thisProb->cities[indi->tour[i+1]].totalWeight;
		//cout << "w0 of " << indi->tour[i] << " = " << w0[indi->tour[i]] << endl;
		if (w0[indi->tour[i]] < 0)
		{
			w0[indi->tour[i]] = 0;
			break;
		}
	}

	//PrintIntVec(w0);
	//system("pause");

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		// the position of this item
		int itemPos = indi->posInTour[thisProb->items[i].inCity];

		// compute the time without this item
		double time1 = 0;
		// compute the time with this item
		double time2 = 0;

		for (int j = itemPos; j < thisProb->numCities; j++)
		{
			int w = w0[indi->tour[j]]-thisProb->items[i].weight;
			if (w < 0)
				w = 0;

			time1 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*w);
			time2 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*(w+thisProb->items[i].weight));
		}

		double deltaTime = time2-time1;

		itemGain[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;

		//cout << i << ": citypos = " << itemPos << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemGain[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}



void GetItemGainWorstTour(vector<double> & itemGain, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// calculate the w0 (worst case) of each city in the tour
	vector<int> w0(thisProb->numCities+1, thisProb->capacity);
	w0[indi->tour.front()] = 0; // the first city 1 has no item
	for (int i = 1; i < thisProb->numCities; i++)
	{
		w0[indi->tour[i]] = w0[indi->tour[i-1]]+thisProb->cities[indi->tour[i+1]].totalWeight;
		//cout << "w0 of " << indi->tour[i] << " = " << w0[indi->tour[i]] << endl;
		if (w0[indi->tour[i]] > thisProb->capacity)
		{
			w0[indi->tour[i]] = thisProb->capacity;
			break;
		}
	}

	//PrintIntVec(w0);
	//system("pause");

	for (int i = 1; i <= thisProb->numItems; i++)
	{
		// the position of this item
		int itemPos = indi->posInTour[thisProb->items[i].inCity];

		// compute the time without this item
		double time1 = 0;
		// compute the time with this item
		double time2 = 0;

		for (int j = itemPos; j < thisProb->numCities; j++)
		{
			int w = w0[indi->tour[j]]-thisProb->items[i].weight;
			if (w < 0)
				w = 0;

			time1 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*w);
			time2 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*(w+thisProb->items[i].weight));
		}

		double deltaTime = time2-time1;

		itemGain[i] = thisProb->items[i].profit-thisProb->rent*deltaTime;

		//cout << i << ": citypos = " << itemPos << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemGain[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}

void GetItemGainTour(vector<double> & itemGain, vector<double> & itemDeltaTime, vector<int> & coreItemList, individual *indi, problem *thisProb)
{
	//PrintIntVec(indi->tour);

	double gamma = (thisProb->maxSpeed-thisProb->minSpeed)/thisProb->capacity;

	// calculate the accumulated weight of each city
	vector<int> accuWeight(thisProb->numCities+1, 0);
	for (int i = 1; i < indi->tour.size() ; i++) // the first city (indi->tour[0] = 1) in the tour has accumulated weight of 0
	{
		accuWeight[indi->tour[i]] = accuWeight[indi->tour[i-1]]+indi->cityWeight[indi->tour[i]];
		//cout << "accu weight of " << indi->tour[i] << " = " << accuWeight[indi->tour[i]] << endl;
	}

	for (vector<int>::iterator it = coreItemList.begin(); it != coreItemList.end(); ++it)
	{
		//cout << i << ": " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << indi->cityBackDist[thisProb->items[i].inCity] << endl;
		//system("pause");

		// the position of this item
		int itemPos = indi->posInTour[thisProb->items[*it].inCity];

		// compute the time without this item
		double time1 = 0;
		// compute the time with this item
		double time2 = 0;
		if (indi->pickPlan[*it] == 0) // not picked
		{
			for (int j = itemPos; j <= thisProb->numCities-1; j++)
			{
				int w = accuWeight[indi->tour[j]];

				time1 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*w);
				time2 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*(w+thisProb->items[*it].weight));
			}
			itemDeltaTime[*it] = time2-time1;
			itemGain[*it] = thisProb->items[*it].profit-thisProb->rent*itemDeltaTime[*it];
		}
		else // picked
		{
			for (int j = itemPos; j <= thisProb->numCities-1; j++)
			{
				int w = accuWeight[indi->tour[j]];

				time1 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*w);
				time2 += (1.0*indi->cityNextDist[indi->tour[j]])/(thisProb->maxSpeed-gamma*(w-thisProb->items[*it].weight));
			}
			itemDeltaTime[*it] = time2-time1;
			itemGain[*it] = -thisProb->items[*it].profit-thisProb->rent*itemDeltaTime[*it];
		}



		//cout << i << ": citypos = " << indi->posInTour[thisProb->items[i].inCity] << ", backdist = " << indi->cityBackDist[thisProb->items[i].inCity] <<
		//	", delta time = " << deltaTime << ", delta profit = " << itemDeltaProfit[i] << endl;
		//system("pause");
	}

	//for (int i = 1; i <= thisProb->numItems; i++)
	//{
	//	if (itemInTour[i])
	//	{
	//		cout << i << " ";
	//	}
	//}
	//cout << endl;
	//system("pause");
}




void OutputRes(individual *indi, char *outFileName)
{
	ofstream outfile;
	outfile.open(outFileName);
	outfile << "[";
	for (int i = 0; i < indi->tour.size()-1; i++)
	{
		outfile << indi->tour[i] << ",";
	}
	outfile << indi->tour.back() << "]" << endl;
	outfile << "[";
	// find the first item
	int firstItem;
	for (firstItem = 1; firstItem < indi->pickPlan.size(); firstItem++)
	{
		if (indi->pickPlan[firstItem] > 0)
		{
			outfile << firstItem;
			break;
		}
	}
	for (int i = firstItem+1; i < indi->pickPlan.size(); i++)
	{
		if (indi->pickPlan[i] > 0)
		{
			outfile << "," << i;
		}
	}
	outfile << "]" << endl;
	outfile.close();
}


void OutputLog(individual *indi, char *logFileName)
{
	clock_t currT = clock();
	double duration = (double)(currT-startT)/CLOCKS_PER_SEC;

	ofstream outfile;
	outfile.open(logFileName, fstream::app);
	outfile << indi->tourLength << " " << indi->itemWeight << " " << indi->itemProfit << " " << indi->profit << " " << duration << endl;
	outfile.close();
}

void OutputFinal(individual *indi, char *resFileName)
{
	ofstream outfile;
	outfile.open(resFileName);
	outfile << indi->profit << endl;
	outfile.close();
}
