#ifndef OPERATOR_H
#define OPERATOR_H

using namespace std;
#include <iostream>
#include <cstring>
#include <algorithm> // for sort
#include <vector>
#include <list>
#include <cstdlib>
#include <time.h>

#include "parameters.h"
#include "problem.h"
#include "city.h"
#include "item.h"
#include "individual.h"
#include "initialization.h"
#include "sampling.h"

extern clock_t startT;

// Randomly select parents
void RandSelectParents(individual *parent1, individual *parent2, vector<individual> & pop, int popsize);

// Tournament parent selection
void TournamentSelectParents(individual *parent1, individual *parent2, vector<individual> & pop, int popsize);

// Ordered crossover for the tour
void TourOXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb);

// The modified edge recombination crossover for the tour, based on the method of ("A modified edge recombination operator for the travelling salesman problem")
void TourERXOver(individual *xchild, individual *parent1, individual *parent2, problem *thisProb);
typedef struct edgeList
{
	list<int> neighborList;
} edgeList;

// Single point crossover for the picking plan
void PickPlanSPXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb);

// Repair the picking plan in the case of weight violation
void RepairPickplan(individual *indi, problem *thisProb);

// Uniform crossover for the picking plan
void PickPlanUniXover(individual *xchild, individual *parent1, individual *parent2, problem *thisProb);

typedef struct tourTwoOptMove
{
	int headCity;
	int tailCity;
	int headPos;
	int tailPos;
	double moveProfit;
} tourTwoOptMove;

// Get the best 2-opt neighbor
void GetBestTwoOptNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb);

// Get the best 2-opt neighbor according to TSP
void GetBestTwoOptTSPNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb);

// Get the first improved 2-opt neighbor
void GetFirstImpTwoOptNeighbor(individual *neighbor, tourTwoOptMove *nextMove, individual *indi, problem *thisProb);

// 2-opt operator for tour
void TourTwoOpt(individual *indi, int p1, int p2, problem *thisProb);

typedef struct singleFlipMove
{
	int item;
	int fromStatus;
	int toStatus;
	double moveDeltaTime;
	double moveProfit;
} singleFlipMove;

// Get the best single flip neighbor
void GetBestSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, individual *indi, problem *thisProb);

void GetBestGainSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, vector<double> & itemGainEmptyTour, vector<double> & itemGainExpectedTour, individual *indi, problem *thisProb);

// get the best gain single flip neighbor from the core item list
void GetBestGainSingleFlipCoreNeighbor(individual *neighbor, singleFlipMove *nextMove, vector<int> & coreItemList, vector<double> & itemGainExpectedTour, individual *indi, problem *thisProb);

// compare the gain of item1 with item2
int GainCmp(int item1, int item2, vector<double> & itemGainEmptyTour, individual *indi, problem *thisProb);

// Get the first improved single flip neighbor
void GetFirstImpSingleFlipNeighbor(individual *neighbor, singleFlipMove *nextMove, individual *indi, problem *thisProb);

// Single flip operator for picking plan
void PickPlanSingleFlip(individual *indi, int k, problem *thisProb);

typedef struct exchangeMove
{
	int item1;
	int fromStatus1;
	int toStatus1;
	int item2;
	int fromStatus2;
	int toStatus2;
	double moveProfit;
} exchangeMove;

// Get the best exchange neighbor
void GetBestExchangeNeighbor(individual *neighbor, exchangeMove *nextMove, individual *indi, problem *thisProb);

// Get the first improved exchange neighbor
void GetFirstImpExchangeNeighbor(individual *neighbor, exchangeMove *nextMove, individual *indi, problem *thisProb);

// Exchange operator for picking plan
void PickPlanExchange(individual *indi, int k1, int k2, problem *thisProb);

void GetItemDeltaProfit(vector<double> & itemDeltaProfit, individual *indi, problem *thisProb);

// Get the gain of each item in an empty tour
void GetItemGainEmptyTour(vector<double> & itemGain, individual *indi, problem *thisProb);

// Get the gain of each item in a full tour
void GetItemGainFullTour(vector<double> & itemGain, individual *indi, problem *thisProb);

// Get the gain of each item in an expected tour (with totalWeight)
void GetItemGainExpectedTour(vector<double> & itemGain, int totalWeight, individual *indi, problem *thisProb);

// Get the gain of each itme in the worst tour (full weight, pick items as early as possible)
void GetItemGainWorstTour(vector<double> & itemGain, individual *indi, problem *thisProb);

// Get the gain of each item in the actual tour
void GetItemGainTour(vector<double> & itemGain, vector<double> & itemDeltaTime, vector<int> & coreItemList, individual *indi, problem *thisProb);



///////////////////////////////////////////////////////////////////////////////////////////////////
// output the results into the output file
void OutputRes(individual *indi, char *outFileName);

// output the log
void OutputLog(individual *indi, char *logFileName);

// output the results
void OutputFinal(individual *indi, char *resFileName);

#endif