
// Parameters of problem
#define INF 2100000000
#define MAX_NUM_CITIES 34000 // maximal number of cities
#define MAX_NUM_ITEMS 340000  // maximal number of items
#define MAX_NUM_INSTANCES 10 // maximal number of instances

// Parameters of experiments
#define MAX_RUN_NUM 10 // maximal number of runs of the algorithm
#define RUN_BEGIN_ID 1 // beginning id of the run
#define RUN_END_ID 1 // end id of the run
#define INSTANCE_BEGIN_ID 1 // begin id of the instances
#define INSTANCE_END_ID 9 // end id of the instances
#define MAX_RUNTIME 600 // the maximal runtime (sec)

// Parameters of algorithm
#define NN_SIZE 5 // number of nearest neighbors for each city
#define MAX_INIT_TRIALS 100 // maximal initialization trials to generate identical individuals

// Parameter for MA
#define MA_POPSIZE 30 // MA population size
#define MA_MAX_GEN 500 // number of generations
#define MA_LS_PROB 0.2 // probability of local search for MA