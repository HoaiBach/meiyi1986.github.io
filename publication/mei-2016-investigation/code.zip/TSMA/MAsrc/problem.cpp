
#include "problem.h"

void ProblemRead(problem *thisProb, char *filename)
{
	ifstream file(filename);
	if (file.is_open())
	{
		string tmpString;
		while (1)
		{
			file >> tmpString;
			//cout << tmpString << endl;
			if (tmpString == "DIMENSION:")
			{
				file >> tmpString;
				thisProb->numCities = atoi(tmpString.c_str());
				//cout << "number of cities = " << thisProb->numCities << endl;
			}
			else if (tmpString == "ITEMS:")
			{
				file >> tmpString;
				thisProb->numItems = atoi(tmpString.c_str());
				//cout << "number of items = " << thisProb->numItems << endl;
			}
			else if (tmpString == "KNAPSACK:")
			{
				file >> tmpString;
				thisProb->capacity = atof(tmpString.c_str());
				//cout << "capacity = " << thisProb->capacity << endl;
			}
			else if (tmpString == "MIN")
			{
				file >> tmpString;
				file >> tmpString;
				thisProb->minSpeed = atof(tmpString.c_str());
				//cout << "minSpeed = " << thisProb->minSpeed << endl;
			}
			else if (tmpString == "MAX")
			{
				file >> tmpString;
				file >> tmpString;
				thisProb->maxSpeed = atof(tmpString.c_str());
				//cout << "maxSpeed = " << thisProb->maxSpeed << endl;
			}
			else if (tmpString == "RATIO:")
			{
				file >> tmpString;
				thisProb->rent = atof(tmpString.c_str());
				//cout << "rent ratio = " << thisProb->rent << endl;
			}
			else if (tmpString == "Y):") // start enumerating all the cities
			{
				thisProb->cities.resize(thisProb->numCities+1); // skip 0
				for (vector<city>::size_type i = 1; i != thisProb->cities.size(); i++)
				{
					thisProb->cities[i].index = (int)i;
					file >> tmpString; // index
					file >> tmpString;
					thisProb->cities[i].xcord = atof(tmpString.c_str());
					file >> tmpString;
					thisProb->cities[i].ycord = atof(tmpString.c_str());
					//cout << "coordinate of city " << i << " is " << thisProb->cities[i].xcord << " " << thisProb->cities[i].ycord << endl;
					thisProb->cities[i].totalProfit = 0;
					thisProb->cities[i].totalWeight = 0;
				}
			}
			else if (tmpString == "NUMBER):") // start enumerating all the items
			{
				thisProb->items.resize(thisProb->numItems+1); // skip 0
				for (vector<item>::size_type i = 1; i != thisProb->items.size(); i++)
				{
					file >> tmpString; // index
					file >> tmpString;
					thisProb->items[i].profit = atof(tmpString.c_str());
					file >> tmpString;
					thisProb->items[i].weight = atof(tmpString.c_str());
					file >> tmpString;
					thisProb->items[i].inCity = atoi(tmpString.c_str());
					//cout << "item " << i << " " << thisProb->items[i].profit << " " << thisProb->items[i].weight << " " << thisProb->items[i].inCity << endl;
					thisProb->cities[thisProb->items[i].inCity].totalProfit += thisProb->items[i].profit;
					thisProb->cities[thisProb->items[i].inCity].totalWeight += thisProb->items[i].weight;
				}
				break;
			}
		}
	}

	file.close();

	// calculate the ratio of each city
	for (vector<city>::size_type i = 1; i != thisProb->cities.size(); i++)
	{
		thisProb->cities[i].wpRatio = 1.0*thisProb->cities[i].totalProfit/thisProb->cities[i].totalWeight;
		//cout << i << ": " << thisProb->cities[i].totalProfit << "/" << thisProb->cities[i].totalWeight << " = " << thisProb->cities[i].wpRatio << endl;
	}

	/*thisProb->distMtx.resize(thisProb->numCities+1);
	for (int i = 1; i <= thisProb->numCities; i++)
	{
		thisProb->distMtx[i].resize(thisProb->numCities+1);
		for (int j = i+1; j <= thisProb->numCities; j++)
		{
			thisProb->distMtx[i][j] = CeilEuclDist(thisProb->cities[i], thisProb->cities[j]);
		}
	}*/
}

char* itoa(int value, char* result, int base)
{
	// check that the base if valid
	if (base < 2 || base > 36) { *result = '\0'; return result; }
	
	char* ptr = result, *ptr1 = result, tmp_char;
	int tmp_value;
	
	do {
		tmp_value = value;
		value /= base;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
	} while ( value );
	
	// Apply negative sign
	if (tmp_value < 0) *ptr++ = '-';
	*ptr-- = '\0';
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}