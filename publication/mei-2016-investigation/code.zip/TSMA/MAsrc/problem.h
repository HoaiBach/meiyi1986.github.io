
#ifndef PROBLEM_H
#define PROBLEM_H

using namespace std;
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdlib>

#include "parameters.h"
#include "city.h"
#include "item.h"

typedef struct problem
{
	int numCities; // number of cities
	int numItems; // number of items
	double capacity; // capacity of the knapsack
	double maxSpeed; // maximal speed
	double minSpeed; // minimal speed
	double rent; // the rent ratio of the knapsack (per time unit)
	vector<city> cities;
	vector<item> items;
	vector< vector<int> > distMtx;
} problem;

// Read the problem
void ProblemRead(problem *thisProb, char *filename);

char* itoa(int value, char* result, int base);

#endif