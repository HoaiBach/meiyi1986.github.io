
#include "sampling.h"

void RandPerm(vector<int> rpVec, int num)
{
	rpVec.resize(num);

	for(int i = 0; i < num; i++)
		rpVec[i] = i;

	for(int i = 1; i < num-1; i++)
	{
		int c = RandChoose(1, num-i);
		int t = rpVec[i]; 
		rpVec[i] = rpVec[i+c]; 
		rpVec[i+c] = t;	/* swap */
	}
}

int RandChoose(int LB, int UB)
{
	int k = LB + rand() / (RAND_MAX / (UB - LB + 1) + 1);

	return k;
}