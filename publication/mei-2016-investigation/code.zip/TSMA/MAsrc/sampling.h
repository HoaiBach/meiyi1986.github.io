
#ifndef SAMPLING_H
#define SAMPLING_H

using namespace std;
#include <iostream>
#include <cstring>
#include <vector>
#include <cstdlib>

// random permutation from 1 to num
void RandPerm(vector<int> rpVec, int num);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// randomly choose a number between LB and UB
int RandChoose(int LB, int UB);

#endif