#!/bin/csh
# WARNING - YOU MUST ENSURE EOL IS IN UNIX FORMAT

# Set folder for executable 1
# set ex1 = ~/HDrive/Exp/TTP-Algo/Competition2014/MA/Code/Code

# Set the directory of MA source code to compile
set MADir = MAsrc

cd $MADir
echo "start compiling..."
g++ city.cpp delaunay2D.cpp individual.cpp initialization.cpp MA.cpp main.cpp MST.cpp operators.cpp problem.cpp sampling.cpp -O3 -o a

# copy the compiled file out
cd ..
mv $MADir/a a
echo "Finish compiling..."
