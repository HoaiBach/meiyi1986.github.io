
instance = {
    'brd14051_n140500';
    'd15112_n151110';
    'd18512_n185110';
    'pla33810_n338090';
    'rl11849_n118480';
    'usa13509_n135080';
    };

type = {
    '_bounded-strongly-corr_05.ttp.profit';
    '_uncorr_05.ttp.profit';
    '_uncorr-similar-weights_05.ttp.profit';
    };

numOfInstances = length(instance);
numOfTypes = length(type);
numOfRuns = 30;

meanVec = zeros(numOfInstances, numOfTypes);
stdVec = zeros(numOfInstances, numOfTypes);

for i = 1:numOfInstances
    for j = 1:numOfTypes
        resVec = zeros(numOfRuns, 1);
        for k = 1:numOfRuns
            fileName = [instance{i} '/' instance{i} type{j} num2str(k) '.txt'];
            resVec(k) = load(fileName);
        end
        meanVec(i,j) = mean(resVec);
        stdVec(i,j) = std(resVec);
    end
end
