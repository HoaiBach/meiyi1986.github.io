#!/bin/csh
# WARNING - YOU MUST ENSURE EOL IS IN UNIX FORMAT

@ algo_runs = 30

@ runID = 0
while($runID < $algo_runs)
	@ runID = $runID + 1

	@ start = `date +"%s"`

	# Set folder for executable 1
	# set ex1 = ~/HDrive/Yi
	# Set folder for executable 2
	set ex2 = concorde/LINKERN
	set input_folder = input
	set input_file = $1
	set output_folder = output

	@ concorde_runs = 10

	# set input_prefix = `echo $1|cut -d"_" -f1`
	# echo "Start running Linkern on input file "$input_prefix
	@ count = 1
	while($count <= $concorde_runs)
		echo "Run No "$count
		$ex2/linkern -Q -o $input_file.concordeout$count $input_folder/$input_file
		@ count = $count + 1
	end

	@ end = `date +"%s"`

	@ diff = $end - $start

	echo "The first part of the program has runned for "$diff" seconds."

	##################################NOT SURE ABOUT FOLLOWING##########
	# chmod a+x $ex1/a.exe
	./a $input_file $diff $concorde_runs $runID

	@ count = 1
	while($count <= $concorde_runs)
		#echo "Delete temp output files: No "$count
		rm -f $input_file.concordeout$count
		@ count = $count + 1
	end

	@ end = `date +"%s"`

	@ diff = $end - $start

	echo "The entire program has runned for "$diff" seconds."
end
